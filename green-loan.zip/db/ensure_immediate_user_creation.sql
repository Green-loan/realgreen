-- Drop existing triggers and functions to recreate them
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
DROP FUNCTION IF EXISTS public.handle_new_user();

-- Create function to immediately create user record when auth.users is created
-- This will run regardless of verification status
CREATE OR REPLACE FUNCTION public.handle_new_user() 
RETURNS TRIGGER AS $$
BEGIN
  -- Insert into public.users immediately
  INSERT INTO public.users (
    id, 
    email, 
    full_name, 
    role_id,
    is_verified,
    is_active
  )
  VALUES (
    NEW.id, 
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'full_name', 'New User'),
    COALESCE((NEW.raw_user_meta_data->>'role_id')::integer, 1),
    FALSE, -- Set as unverified initially
    TRUE   -- Set as active immediately
  );
  
  -- Insert into public.profiles immediately
  INSERT INTO public.profiles (
    id, 
    user_id, 
    full_name,
    credit_score,
    total_loans,
    active_loans,
    total_invested,
    stokvel_contribution
  )
  VALUES (
    NEW.id,
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'full_name', 'New User'),
    720,
    0,
    0,
    'R 0',
    'R 0'
  );
  
  -- Insert into public.user_settings immediately
  INSERT INTO public.user_settings (
    user_id,
    notification_preferences,
    theme,
    language
  )
  VALUES (
    NEW.id,
    '{"email": true, "push": true, "sms": false}',
    'system',
    'en'
  );
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger to call function on new user creation
-- This will fire for ALL new users, even unconfirmed ones
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Update the users table to ensure it can accept unverified users
ALTER TABLE IF EXISTS public.users 
  ALTER COLUMN is_verified SET DEFAULT FALSE;

