-- Create a function to ensure users have the correct role_id
CREATE OR REPLACE FUNCTION public.ensure_user_role()
RETURNS TRIGGER AS $$
BEGIN
  -- If role_id is not set, default to 1 (regular user)
  IF NEW.raw_user_meta_data->>'role_id' IS NULL THEN
    NEW.raw_user_meta_data := 
      jsonb_set(
        COALESCE(NEW.raw_user_meta_data, '{}'::jsonb),
        '{role_id}',
        '1'::jsonb
      );
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create a trigger to apply this function before insert
DROP TRIGGER IF EXISTS ensure_user_role_trigger ON auth.users;
CREATE TRIGGER ensure_user_role_trigger
BEFORE INSERT ON auth.users
FOR EACH ROW
EXECUTE FUNCTION public.ensure_user_role();

-- Create a trigger to ensure profiles have the correct role_id
CREATE OR REPLACE FUNCTION public.sync_profile_role()
RETURNS TRIGGER AS $$
BEGIN
  -- Set role_id to 1 (regular user) if not specified
  IF NEW.role_id IS NULL THEN
    NEW.role_id := 1;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create a trigger to apply this function before insert or update
DROP TRIGGER IF EXISTS sync_profile_role_trigger ON public.profiles;
CREATE TRIGGER sync_profile_role_trigger
BEFORE INSERT OR UPDATE ON public.profiles
FOR EACH ROW
EXECUTE FUNCTION public.sync_profile_role();

