-- Enable UUID extension if not already enabled
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Create roles table if it doesn't exist
CREATE TABLE IF NOT EXISTS roles (
  id SERIAL PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  description TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Insert default roles if they don't exist
INSERT INTO roles (id, name, description) 
VALUES 
  (1, 'user', 'Regular user with standard permissions'),
  (2, 'admin', 'Administrator with full access')
ON CONFLICT (id) DO NOTHING;

-- Create user_profiles table if it doesn't exist
CREATE TABLE IF NOT EXISTS user_profiles (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL UNIQUE,
  full_name VARCHAR(255),
  email VARCHAR(255) NOT NULL,
  phone VARCHAR(50),
  role_id INTEGER DEFAULT 1,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Add foreign key if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'user_profiles_user_id_fkey'
  ) THEN
    ALTER TABLE user_profiles 
    ADD CONSTRAINT user_profiles_user_id_fkey 
    FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'user_profiles_role_id_fkey'
  ) THEN
    ALTER TABLE user_profiles 
    ADD CONSTRAINT user_profiles_role_id_fkey 
    FOREIGN KEY (role_id) REFERENCES roles(id);
  END IF;
END
$$;

-- Enable RLS on the table
ALTER TABLE user_profiles ENABLE ROW LEVEL SECURITY;

-- Drop existing policies to recreate them
DROP POLICY IF EXISTS "Allow insert for authenticated users" ON user_profiles;
DROP POLICY IF EXISTS "Allow select for users" ON user_profiles;
DROP POLICY IF EXISTS "Allow update for users" ON user_profiles;

-- Create policies
CREATE POLICY "Allow insert for authenticated users" 
ON user_profiles FOR INSERT 
TO authenticated 
WITH CHECK (true);

CREATE POLICY "Allow select for users" 
ON user_profiles FOR SELECT 
TO authenticated 
USING (auth.uid() = user_id OR 
       EXISTS (SELECT 1 FROM user_profiles WHERE user_id = auth.uid() AND role_id = 2));

CREATE POLICY "Allow update for users" 
ON user_profiles FOR UPDATE 
TO authenticated 
USING (auth.uid() = user_id OR 
       EXISTS (SELECT 1 FROM user_profiles WHERE user_id = auth.uid() AND role_id = 2));

