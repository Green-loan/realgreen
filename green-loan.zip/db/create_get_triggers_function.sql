-- Function to get triggers in a schema
CREATE OR REPLACE FUNCTION public.get_triggers(schema_name text)
RETURNS TABLE (
  trigger_name text,
  table_name text,
  event_manipulation text,
  action_statement text
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    trigger_name::text,
    event_object_table::text,
    event_manipulation::text,
    action_statement::text
  FROM information_schema.triggers
  WHERE trigger_schema = schema_name;
END;
$$ LANGUAGE plpgsql;

