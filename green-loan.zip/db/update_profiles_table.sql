-- Update profiles table to include additional fields
ALTER TABLE IF EXISTS profiles 
ADD COLUMN IF NOT EXISTS first_name TEXT,
ADD COLUMN IF NOT EXISTS last_name TEXT,
ADD COLUMN IF NOT EXISTS avatar_url TEXT,
ADD COLUMN IF NOT EXISTS credit_score INTEGER DEFAULT 720,
ADD COLUMN IF NOT EXISTS total_loans INTEGER DEFAULT 0,
ADD COLUMN IF NOT EXISTS active_loans INTEGER DEFAULT 0,
ADD COLUMN IF NOT EXISTS total_invested TEXT DEFAULT 'R 0',
ADD COLUMN IF NOT EXISTS stokvel_contribution TEXT DEFAULT 'R 0',
ADD COLUMN IF NOT EXISTS next_payment_date TEXT,
ADD COLUMN IF NOT EXISTS next_payment_amount TEXT;

-- Create a function to split full_name into first_name and last_name if they're NULL
CREATE OR REPLACE FUNCTION update_name_parts() RETURNS TRIGGER AS $$
BEGIN
  IF NEW.first_name IS NULL AND NEW.full_name IS NOT NULL THEN
    NEW.first_name := split_part(NEW.full_name, ' ', 1);
    NEW.last_name := substring(NEW.full_name from position(' ' in NEW.full_name) + 1);
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create a trigger to automatically update first_name and last_name when a profile is inserted or updated
DROP TRIGGER IF EXISTS update_name_parts_trigger ON profiles;
CREATE TRIGGER update_name_parts_trigger
BEFORE INSERT OR UPDATE ON profiles
FOR EACH ROW
EXECUTE FUNCTION update_name_parts();

