-- Create a trigger to automatically set up default values for new users
CREATE OR REPLACE FUNCTION public.handle_new_user() 
RETURNS TRIGGER AS $$
BEGIN
  -- Insert a row into public.profiles
  INSERT INTO public.profiles (id, user_id, full_name, avatar_url, credit_score, total_loans, active_loans, total_invested, stokvel_contribution, role_id)
  VALUES (
    NEW.id, 
    NEW.id, 
    NEW.raw_user_meta_data->>'full_name', 
    NEW.raw_user_meta_data->>'avatar_url',
    720, -- Default credit score
    0,   -- Default total loans
    0,   -- Default active loans
    'R 0', -- Default total invested
    'R 0', -- Default stokvel contribution
    1     -- Default role_id (1)
  );
  
  -- Insert default user settings
  INSERT INTO public.user_settings (user_id, notification_preferences, theme, language)
  VALUES (
    NEW.id,
    '{"email": true, "push": true, "sms": false}',
    'system',
    'en'
  );
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Drop the trigger if it exists
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;

-- Create the trigger
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

