-- Create roles table if it doesn't exist
CREATE TABLE IF NOT EXISTS roles (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT
);

-- Insert default roles if they don't exist
INSERT INTO roles (id, name, description)
VALUES 
  (1, 'user', 'Regular user')
ON CONFLICT (id) DO NOTHING;

INSERT INTO roles (id, name, description)
VALUES 
  (2, 'admin', 'Administrator')
ON CONFLICT (id) DO NOTHING;

-- Create users table if it doesn't exist
CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT,
  role_id INTEGER NOT NULL DEFAULT 1 REFERENCES roles(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create index on email for faster lookups
CREATE INDEX IF NOT EXISTS users_email_idx ON users(email);

-- Create index on role_id for faster role-based queries
CREATE INDEX IF NOT EXISTS users_role_id_idx ON users(role_id);

-- Enable Row Level Security
ALTER TABLE users ENABLE ROW LEVEL SECURITY;

-- Create policies for users table
-- Allow users to view their own data
CREATE POLICY IF NOT EXISTS "Users can view their own data" 
  ON users FOR SELECT 
  USING (auth.uid() = id);

-- Allow users to update their own data
CREATE POLICY IF NOT EXISTS "Users can update their own data" 
  ON users FOR UPDATE 
  USING (auth.uid() = id);

-- Allow authenticated users to insert their own data
CREATE POLICY IF NOT EXISTS "Users can insert their own data" 
  ON users FOR INSERT 
  WITH CHECK (auth.uid() = id);

-- Allow service role to access all data
CREATE POLICY IF NOT EXISTS "Service role can do anything" 
  ON users 
  USING (auth.role() = 'service_role');

-- Create a function to automatically create a user profile on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.users (id, full_name, email, role_id)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'full_name', ''),
    NEW.email,
    1  -- Default role_id is 1 (regular user)
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create a trigger to call the function on user creation
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

