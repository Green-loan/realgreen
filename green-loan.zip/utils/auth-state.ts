// Simple authentication state manager
type User = {
  id: string
  email: string
  last_sign_in_at?: string
}

export const saveAuthState = (user: User) => {
  if (typeof window !== "undefined") {
    localStorage.setItem("auth_user", JSON.stringify(user))
  }
}

export const getAuthState = (): User | null => {
  if (typeof window !== "undefined") {
    const userStr = localStorage.getItem("auth_user")
    if (userStr) {
      try {
        return JSON.parse(userStr)
      } catch (e) {
        return null
      }
    }
  }
  return null
}

export const clearAuthState = () => {
  if (typeof window !== "undefined") {
    localStorage.removeItem("auth_user")
  }
}

export const isAuthenticated = (): boolean => {
  return !!getAuthState()
}

