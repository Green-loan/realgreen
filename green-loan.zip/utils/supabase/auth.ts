import { createClientComponentClient } from "@supabase/auth-helpers-nextjs"

// Supabase connection details
const SUPABASE_URL = "https://xoyowuxrolooejyaukrx.supabase.co"
const SUPABASE_ANON_KEY =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InhveW93dXhyb2xvb2VqeWF1a3J4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDI2NDcyMjEsImV4cCI6MjA1ODIyMzIyMX0.LBXBGwd-qOKo_539xrZMpzRaUkKGdGTx4IXN2OvXnYw"

export const createClient = () => {
  return createClientComponentClient({
    supabaseUrl: SUPABASE_URL,
    supabaseKey: SUPABASE_ANON_KEY,
  })
}

