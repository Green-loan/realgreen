import { createBrowserClient } from "@supabase/ssr"

// Hardcoded values as a fallback (not ideal but ensures functionality)
const FALLBACK_SUPABASE_URL = "https://xyzcompanyid.supabase.co"
const FALLBACK_SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."

export const createClient = () =>
  createBrowserClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!)

