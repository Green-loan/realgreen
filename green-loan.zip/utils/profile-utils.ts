export interface UserProfile {
  id: string
  first_name?: string
  last_name?: string
  full_name?: string
  email?: string
  avatar_url?: string
  credit_score?: number
  total_loans?: number
  active_loans?: number
  total_invested?: string
  stokvel_contribution?: string
  next_payment_date?: string
  next_payment_amount?: string
  created_at?: string
  updated_at?: string
}

export function formatProfileData(profileData: any, userData: any): UserProfile {
  // Extract first and last name from full_name if they don't exist
  let firstName = profileData?.first_name
  let lastName = profileData?.last_name

  if (!firstName && profileData?.full_name) {
    const nameParts = profileData.full_name.split(" ")
    firstName = nameParts[0]
    lastName = nameParts.slice(1).join(" ")
  }

  return {
    id: profileData?.id || userData?.id,
    first_name: firstName || "",
    last_name: lastName || "",
    full_name: profileData?.full_name || `${firstName || ""} ${lastName || ""}`.trim(),
    email: profileData?.email || userData?.email,
    avatar_url: profileData?.avatar_url,
    credit_score: profileData?.credit_score || 720,
    total_loans: profileData?.total_loans || 0,
    active_loans: profileData?.active_loans || 0,
    total_invested: profileData?.total_invested || "R 0",
    stokvel_contribution: profileData?.stokvel_contribution || "R 0",
    next_payment_date: profileData?.next_payment_date || "-",
    next_payment_amount: profileData?.next_payment_amount || "R 0",
    created_at: profileData?.created_at || userData?.created_at,
    updated_at: profileData?.updated_at,
  }
}

