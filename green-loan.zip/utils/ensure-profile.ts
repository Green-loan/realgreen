import { createClientComponentClient } from "@supabase/auth-helpers-nextjs"

export async function ensureUserProfile(userId: string, userData: any) {
  const supabase = createClientComponentClient()

  // Check if profile exists
  const { data: existingProfile } = await supabase.from("profiles").select("*").eq("id", userId).single()

  if (existingProfile) {
    console.log("Profile already exists:", existingProfile)
    return existingProfile
  }

  console.log("Creating new profile for user:", userId)

  // Get user metadata
  const fullName = userData?.user_metadata?.full_name || userData?.user_metadata?.name || "New User"

  // Create profile
  const { data: profile, error: profileError } = await supabase
    .from("profiles")
    .insert({
      id: userId,
      user_id: userId,
      full_name: fullName,
      email: userData?.email,
      role_id: 1,
      credit_score: 720,
      total_loans: 0,
      active_loans: 0,
      total_invested: "R 0",
      stokvel_contribution: "R 0",
    })
    .select()

  if (profileError) {
    console.error("Error creating profile:", profileError)

    // Try the API endpoint as fallback
    try {
      const response = await fetch("/api/auth/create-profile", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          userId,
          fullName,
        }),
      })

      if (response.ok) {
        const data = await response.json()
        console.log("Profile created via API:", data)
        return data.profile
      } else {
        console.error("API failed to create profile:", await response.json())
      }
    } catch (apiError) {
      console.error("Error calling API:", apiError)
    }

    return null
  }

  // Create user settings
  const { error: settingsError } = await supabase.from("user_settings").insert({
    user_id: userId,
    notification_preferences: {
      email: true,
      push: true,
      sms: false,
    },
    theme: "system",
    language: "en",
  })

  if (settingsError) {
    console.error("Error creating settings:", settingsError)
  }

  return profile
}

