import { createClient } from "@/utils/supabase/server"
import { cookies } from "next/headers"

export async function ensureUserAccount(userId: string, email: string, fullNames?: string) {
  try {
    const cookieStore = cookies()
    const supabase = createClient(cookieStore)

    // Check if user account exists
    const { data: existingAccount, error: checkError } = await supabase
      .from("users_account")
      .select("id")
      .eq("id", userId)
      .single()

    if (checkError || !existingAccount) {
      console.log("User account not found, creating...")

      // Create user account
      const { error: insertError } = await supabase.from("users_account").insert({
        id: userId,
        email: email,
        full_names: fullNames || "New User",
        role: 1,
        confirmed: false,
        created_at: new Date().toISOString(),
      })

      if (insertError) {
        console.error("Error creating user account:", insertError)

        // Try with minimal fields
        const { error: minimalError } = await supabase.from("users_account").insert({
          id: userId,
          email: email,
          full_names: fullNames || "New User",
          role: 1,
        })

        if (minimalError) {
          console.error("Error creating minimal user account:", minimalError)
          return false
        }
      }

      return true
    }

    return true
  } catch (error) {
    console.error("Error ensuring user account:", error)
    return false
  }
}

