import { createClientComponentClient } from "@supabase/auth-helpers-nextjs"

export async function ensureUserExists(userId: string, userData: any) {
  const supabase = createClientComponentClient()

  if (!userId) {
    console.error("No user ID provided to ensureUserExists")
    return null
  }

  // Check if user exists in users table
  const { data: existingUser, error: checkError } = await supabase.from("users").select("*").eq("id", userId).single()

  if (!checkError && existingUser) {
    console.log("User already exists:", existingUser)
    return existingUser
  }

  console.log("User not found in users table, creating...")

  // Get user details
  const email = userData?.email || "unknown@example.com"
  const fullName = userData?.user_metadata?.full_name || userData?.user_metadata?.name || "New User"

  // Insert into users table
  const { data: user, error: userError } = await supabase
    .from("users")
    .insert({
      id: userId,
      email: email,
      full_name: fullName,
      role_id: 1,
      is_verified: false,
      is_active: true,
    })
    .select()

  if (userError) {
    console.error("Error creating user:", userError)

    // Try the API as fallback
    try {
      const response = await fetch("/api/auth/create-user", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          userId,
          email,
          fullName,
          roleId: 1,
        }),
      })

      if (response.ok) {
        const data = await response.json()
        console.log("User created via API:", data)
        return data.user
      }
    } catch (apiError) {
      console.error("Error calling API:", apiError)
    }

    return null
  }

  return user
}

