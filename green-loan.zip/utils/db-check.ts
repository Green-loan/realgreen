import { createClientComponentClient } from "@supabase/auth-helpers-nextjs"

export async function checkDatabaseSetup() {
  const supabase = createClientComponentClient()

  try {
    // Check if roles table exists and has data
    const { data: roles, error: rolesError } = await supabase.from("roles").select("id, name")

    if (rolesError) {
      console.error("Error checking roles table:", rolesError)
      return {
        success: false,
        message: "Could not verify roles table",
        error: rolesError,
      }
    }

    if (!roles || roles.length === 0) {
      return {
        success: false,
        message: "Roles table exists but has no data",
        roles,
      }
    }

    // Check if user_profiles table exists
    const { data: userProfiles, error: profilesError } = await supabase.from("user_profiles").select("id").limit(1)

    if (profilesError && profilesError.code !== "PGRST116") {
      // PGRST116 means no rows found, which is fine
      console.error("Error checking user_profiles table:", profilesError)
      return {
        success: false,
        message: "Could not verify user_profiles table",
        error: profilesError,
      }
    }

    return {
      success: true,
      message: "Database setup verified",
      roles,
    }
  } catch (error) {
    console.error("Error checking database setup:", error)
    return {
      success: false,
      message: "Error checking database setup",
      error,
    }
  }
}

