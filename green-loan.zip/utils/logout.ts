import { clearAuthState } from "./auth-state"

export const logout = () => {
  // Clear auth state
  clearAuthState()

  // Redirect to login page
  window.location.href = "/login"
}

