"use client"

import { motion } from "framer-motion"
import { ThreeDPhotoCarousel } from "@/components/ui/3d-carousel"

export function LandingTestimonials() {
  return (
    <section id="testimonials" className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">What Our Customers Say</h2>
            <p className="text-xl text-foreground/70 max-w-2xl mx-auto">
              Hear from people who have transformed their projects with GreenLoan financing.
            </p>
          </motion.div>
        </div>

        <div className="max-w-5xl mx-auto">
          <ThreeDPhotoCarousel />
        </div>
      </div>
    </section>
  )
}

