import { CheckCircle } from "lucide-react"

export function FeaturesSection() {
  return (
    <section className="py-20 bg-gradient-to-b from-white to-gray-50 dark:from-gray-900 dark:to-gray-950">
      <div className="container px-4 md:px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">Why Choose Green Fina</h2>
          <p className="mt-4 text-lg text-gray-500 dark:text-gray-400 max-w-3xl mx-auto">
            Our green loan program offers unique benefits that help you save money while saving the planet.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mt-12">
          {features.map((feature, index) => (
            <div
              key={index}
              className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 transition-all duration-200 hover:shadow-lg border border-gray-100 dark:border-gray-700"
            >
              <div className="h-12 w-12 flex items-center justify-center rounded-full bg-green-100 dark:bg-green-900 mb-4">
                <feature.icon className="h-6 w-6 text-green-600 dark:text-green-400" />
              </div>
              <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
              <p className="text-gray-500 dark:text-gray-400">{feature.description}</p>
              <ul className="mt-4 space-y-2">
                {feature.benefits.map((benefit, idx) => (
                  <li key={idx} className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                    <span className="text-gray-600 dark:text-gray-300">{benefit}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

const features = [
  {
    title: "Lower Interest Rates",
    description: "Enjoy competitive interest rates for environmentally friendly home improvements.",
    icon: (props: any) => (
      <svg
        xmlns="http://www.w3.org/2000/svg"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        {...props}
      >
        <path d="M2 20h.01m4 0h.01m4 0h.01m4 0h.01m4 0h.01M5 14v6m7-6v6m7-6v6M5 4v3m7-3v3m7-3v3m-7 3V4M3 7h18M3 11h18" />
      </svg>
    ),
    benefits: [
      "Rates up to 1% lower than traditional loans",
      "Flexible repayment terms from 5-20 years",
      "No prepayment penalties",
    ],
  },
  {
    title: "Environmental Impact",
    description: "Make a positive impact on the environment while improving your home.",
    icon: (props: any) => (
      <svg
        xmlns="http://www.w3.org/2000/svg"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        {...props}
      >
        <path d="M2 22c1.25-1.25 2.5-2.5 3.5-2.5 1.5 0 1.5 2.5 3 2.5s1.5-2.5 3-2.5 1.5 2.5 3 2.5 1.5-2.5 3-2.5 1.5 2.5 3 2.5 1.5-2.5 3-2.5 1.5 2.5 3 2.5 1.5-2.5 3-2.5 1.5 2.5 3 2.5 1.5-2.5 3-2.5 1.5 2.5 3 2.5 1.5-2.5 3-2.5" />
        <path d="M4 18a2 2 0 1 1 4 0c0 .5-.5 2-2 2s-2-1.5-2-2z" />
        <path d="M12 18a2 2 0 1 1 4 0c0 .5-.5 2-2 2s-2-1.5-2-2z" />
        <path d="M20 18a2 2 0 1 1 4 0c0 .5-.5 2-2 2s-2-1.5-2-2z" />
      </svg>
    ),
    benefits: [
      "Reduce your carbon footprint",
      "Support sustainable building practices",
      "Contribute to a greener future",
    ],
  },
  {
    title: "Energy Savings",
    description: "Invest in energy-efficient upgrades that pay for themselves over time.",
    icon: (props: any) => (
      <svg
        xmlns="http://www.w3.org/2000/svg"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        {...props}
      >
        <path d="M12 2v8" />
        <path d="m4.93 10.93 1.41 1.41" />
        <path d="M2 18h2" />
        <path d="M20 18h2" />
        <path d="m19.07 10.93-1.41 1.41" />
        <path d="M22 22H2" />
        <path d="m8 6 4-4 4 4" />
        <path d="M16 18a4 4 0 0 0-8 0" />
      </svg>
    ),
    benefits: [
      "Lower monthly utility bills",
      "Increase your home's energy efficiency",
      "Qualify for additional tax incentives",
    ],
  },
]

