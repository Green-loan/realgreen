"use client"
import { WorldMap } from "@/components/ui/world-map"
import { motion } from "framer-motion"

export function GlobalImpactMap() {
  return (
    <div className="py-12 bg-transparent w-full">
      <div className="max-w-5xl mx-auto text-center">
        <p className="font-bold text-xl md:text-3xl dark:text-white text-black">
          Global{" "}
          <span className="text-teal-500">
            {"Impact".split("").map((word, idx) => (
              <motion.span
                key={idx}
                className="inline-block"
                initial={{ x: -10, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ duration: 0.5, delay: idx * 0.04 }}
              >
                {word}
              </motion.span>
            ))}
          </span>
        </p>
        <p className="text-sm md:text-base text-neutral-500 max-w-xl mx-auto py-3">
          Our green financing solutions are making a difference across the globe. See how GreenLoan is connecting
          communities and funding sustainable initiatives in Africa and beyond.
        </p>
      </div>
      <div className="max-w-4xl mx-auto">
        <WorldMap
          lineColor="#10b981" // teal-500
          dots={[
            {
              start: {
                lat: -33.9249,
                lng: 18.4241,
              }, // Cape Town
              end: {
                lat: -26.2041,
                lng: 28.0473,
              }, // Johannesburg
            },
            {
              start: { lat: -26.2041, lng: 28.0473 }, // Johannesburg
              end: { lat: -1.2921, lng: 36.8219 }, // Nairobi, Kenya
            },
            {
              start: { lat: -1.2921, lng: 36.8219 }, // Nairobi
              end: { lat: 9.082, lng: 8.6753 }, // Nigeria
            },
            {
              start: { lat: 9.082, lng: 8.6753 }, // Nigeria
              end: { lat: 14.7167, lng: -17.4677 }, // Dakar, Senegal
            },
            {
              start: { lat: -26.2041, lng: 28.0473 }, // Johannesburg
              end: { lat: 51.5074, lng: -0.1278 }, // London
            },
            {
              start: { lat: -1.2921, lng: 36.8219 }, // Nairobi
              end: { lat: 40.7128, lng: -74.006 }, // New York
            },
            {
              start: { lat: -33.9249, lng: 18.4241 }, // Cape Town
              end: { lat: -15.7975, lng: -47.8919 }, // Brazil (Brasília)
            },
          ]}
        />
      </div>
    </div>
  )
}

