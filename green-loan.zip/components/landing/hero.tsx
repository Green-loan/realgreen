"use client"

import { Button } from "@/components/ui/button"
import Link from "next/link"
import { motion } from "framer-motion"

export function LandingHero() {
  return (
    <section className="relative pt-32 pb-20 md:pt-40 md:pb-32 overflow-hidden">
      {/* Background elements */}
      <div className="absolute inset-0 -z-10">
        <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-green-500/10 rounded-full blur-3xl" />
        <div className="absolute bottom-1/3 right-1/3 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl" />
      </div>

      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center">
          <div className="md:w-1/2 md:pr-12">
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-6">
                <span className="bg-clip-text text-transparent bg-gradient-to-r from-green-400 to-emerald-600">
                  Sustainable Financing
                </span>{" "}
                for a Greener Future
              </h1>
              <p className="text-xl text-foreground/80 mb-8 max-w-lg">
                GreenLoan provides eco-friendly financial solutions that help you invest in sustainable projects while
                making a positive impact on the planet.
              </p>

              <div className="flex flex-col sm:flex-row gap-4">
                <Button
                  asChild
                  size="lg"
                  className="bg-gradient-to-r from-green-400 to-emerald-600 hover:from-green-500 hover:to-emerald-700"
                >
                  <Link href="/apply">Apply for a Loan</Link>
                </Button>
                <Button asChild size="lg" variant="outline">
                  <Link href="/#features">Learn More</Link>
                </Button>
              </div>

              <div className="mt-8 flex items-center space-x-4">
                <div className="flex -space-x-2">
                  {[1, 2, 3, 4].map((i) => (
                    <div
                      key={i}
                      className={`w-10 h-10 rounded-full border-2 border-background bg-gradient-to-br from-green-${i * 100} to-emerald-${i * 100}`}
                    />
                  ))}
                </div>
                <p className="text-sm text-foreground/70">
                  Trusted by <span className="font-bold">2,000+</span> eco-conscious customers
                </p>
              </div>
            </motion.div>
          </div>

          <div className="md:w-1/2 mt-12 md:mt-0">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="relative"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-green-400/20 to-emerald-600/20 rounded-2xl blur-xl" />
              <div className="relative bg-background/50 backdrop-blur-sm border border-border/50 rounded-2xl p-6 shadow-xl">
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 rounded-full bg-red-500" />
                    <div className="w-3 h-3 rounded-full bg-yellow-500" />
                    <div className="w-3 h-3 rounded-full bg-green-500" />
                  </div>
                  <div className="text-xs text-foreground/50">greenloan.app</div>
                </div>

                <div className="space-y-4">
                  <div className="h-12 bg-foreground/5 rounded-lg animate-pulse" />
                  <div className="h-24 bg-foreground/5 rounded-lg animate-pulse" />
                  <div className="grid grid-cols-2 gap-4">
                    <div className="h-12 bg-foreground/5 rounded-lg animate-pulse" />
                    <div className="h-12 bg-green-500/20 rounded-lg animate-pulse" />
                  </div>
                  <div className="h-8 w-1/2 mx-auto bg-gradient-to-r from-green-400 to-emerald-600 rounded-lg animate-pulse" />
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  )
}

