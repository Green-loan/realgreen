"use client"

import { Clock, BarChart, MessageSquare, Percent } from "lucide-react"
import { GreenSparkles } from "./green-sparkles"

const features = [
  {
    icon: Percent,
    title: "39.99% Interest Rate",
    description:
      "Our loans come with a fixed 39.99% interest rate. We believe in complete transparency about our loan terms.",
  },
  {
    icon: Clock,
    title: "Quick Approval Process",
    description: "Get your loan approved in as little as 24 hours with our streamlined application process.",
  },
  {
    icon: BarChart,
    title: "Transparent Tracking",
    description: "Monitor your loan status, payments, and environmental impact through our intuitive dashboard.",
  },
  {
    icon: MessageSquare,
    title: "Dedicated Support",
    description: "Our team of experts is always available to answer your questions and provide guidance.",
  },
]

export function LandingFeatures() {
  return (
    <section id="features" className="py-20 bg-background/50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <GreenSparkles />
          <p className="text-xl text-foreground/70 max-w-2xl mx-auto mt-4">
            Our platform offers loans with a fixed 39.99% interest rate, providing you with clear and straightforward
            financing options.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div
              key={index}
              className="bg-background/50 backdrop-blur-sm border border-border/50 rounded-xl p-6 hover:border-teal-500/30 transition-all duration-300"
            >
              <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-teal-500/20 to-blue-600/20 flex items-center justify-center mb-4">
                <feature.icon className="w-6 h-6 text-teal-500" />
              </div>

              <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
              <p className="text-foreground/70">{feature.description}</p>

              <div className="w-0 h-1 bg-gradient-to-r from-teal-500 to-blue-600 mt-4 rounded-full w-full" />
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

