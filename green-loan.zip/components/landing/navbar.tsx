"use client"

import { NavBarDemo } from "@/components/navbar-demo"

export function LandingNavbar() {
  return (
    <header className="fixed top-0 left-0 right-0 z-50 transition-all duration-300 bg-background/50 backdrop-blur-lg">
      <div className="container mx-auto px-4 py-3">
        <NavBarDemo />
      </div>
    </header>
  )
}

