"use client"

import { useState, useRef, useEffect } from "react"
import { Canvas, useFrame } from "@react-three/fiber"
import { Html, Environment, PerspectiveCamera } from "@react-three/drei"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { PauseIcon, PlayIcon, RotateCwIcon, RotateCcwIcon } from "lucide-react"
import type { Group } from "three"
import { cn } from "@/lib/utils"

// Member type to define the expected properties
type StokvelMember = {
  id: string
  name: string
  position: number
  profileImage?: string
  payoutDate: string
  amountPaid: number
  paymentSpeedRating: "Fast" | "Average" | "Slow"
  amountToReceive: number
}

// Props for the Member Card component
interface MemberCardProps {
  member: StokvelMember
  index: number
  active: boolean
  totalMembers: number
}

// The individual member card that will be positioned in 3D space
const MemberCard = ({ member, index, active, totalMembers }: MemberCardProps) => {
  const group = useRef<Group>(null!)
  const radius = 5
  const angle = (index / totalMembers) * Math.PI * 2
  const x = Math.sin(angle) * radius
  const z = Math.cos(angle) * radius

  // Get rating color based on payment speed
  const getRatingColor = (rating: string) => {
    switch (rating) {
      case "Fast":
        return "bg-green-500"
      case "Average":
        return "bg-yellow-500"
      case "Slow":
        return "bg-red-500"
      default:
        return "bg-slate-500"
    }
  }

  useEffect(() => {
    if (group.current) {
      group.current.position.set(x, 0, z)
      group.current.rotation.y = -angle + Math.PI
    }
  }, [x, z, angle])

  return (
    <group ref={group}>
      <Html transform distanceFactor={10} position={[0, 0, 0.1]} rotation-y={Math.PI}>
        <div
          className={cn(
            "w-64 bg-card shadow-xl rounded-xl overflow-hidden transition-all duration-300 transform",
            active ? "scale-110 ring-2 ring-primary" : "scale-100 opacity-70",
          )}
        >
          <div className="relative h-20 bg-gradient-to-r from-primary/20 to-primary/40">
            <div className="absolute -bottom-10 left-4">
              <Avatar className="h-20 w-20 border-4 border-background">
                <AvatarImage src={member.profileImage || `/placeholder.svg?height=80&width=80`} alt={member.name} />
                <AvatarFallback className="text-2xl">{member.name.charAt(0)}</AvatarFallback>
              </Avatar>
            </div>
            <div className="absolute top-2 right-2">
              <Badge variant="secondary">Position #{member.position}</Badge>
            </div>
          </div>

          <div className="pt-12 p-4">
            <h3 className="font-bold text-lg mb-1">{member.name}</h3>
            <div className="grid grid-cols-2 gap-2 text-sm">
              <div className="space-y-2">
                <p className="text-muted-foreground">Payout:</p>
                <p className="text-muted-foreground">Paid:</p>
                <p className="text-muted-foreground">Speed:</p>
                <p className="text-muted-foreground">To Receive:</p>
              </div>
              <div className="space-y-2">
                <p>{member.payoutDate}</p>
                <p>R{member.amountPaid.toLocaleString()}</p>
                <p>
                  <span
                    className={`inline-block w-2 h-2 rounded-full mr-1 ${getRatingColor(member.paymentSpeedRating)}`}
                  ></span>{" "}
                  {member.paymentSpeedRating}
                </p>
                <p className="font-semibold">R{member.amountToReceive.toLocaleString()}</p>
              </div>
            </div>
          </div>
        </div>
      </Html>
    </group>
  )
}

// The rotating carousel
const RotatingCarousel = ({
  members,
  activeIndex,
  setActiveIndex,
}: {
  members: StokvelMember[]
  activeIndex: number
  setActiveIndex: (index: number) => void
}) => {
  const groupRef = useRef<Group>(null!)
  const [autoRotate, setAutoRotate] = useState(true)
  const rotationSpeed = 0.003

  // Handle the rotation of the carousel
  useFrame(() => {
    if (groupRef.current && autoRotate) {
      groupRef.current.rotation.y += rotationSpeed

      // Calculate which member is at the front based on rotation
      const angle = groupRef.current.rotation.y % (Math.PI * 2)
      const segmentSize = (Math.PI * 2) / members.length
      const frontIndex = Math.round(angle / segmentSize) % members.length

      if (frontIndex !== activeIndex) {
        setActiveIndex(frontIndex)
      }
    }
  })

  return (
    <group ref={groupRef}>
      {members.map((member, index) => (
        <MemberCard
          key={member.id}
          member={member}
          index={index}
          active={index === activeIndex}
          totalMembers={members.length}
        />
      ))}
    </group>
  )
}

// Main component for the 3D Carousel
export function Stokvel3DCarousel({ members }: { members: StokvelMember[] }) {
  const [activeIndex, setActiveIndex] = useState(0)
  const [autoRotate, setAutoRotate] = useState(true)

  const handlePrevMember = () => {
    setAutoRotate(false)
    setActiveIndex((prev) => (prev - 1 + members.length) % members.length)
  }

  const handleNextMember = () => {
    setAutoRotate(false)
    setActiveIndex((prev) => (prev + 1) % members.length)
  }

  const toggleRotation = () => {
    setAutoRotate((prev) => !prev)
  }

  return (
    <div className="relative w-full h-[500px]">
      <Canvas shadows>
        <PerspectiveCamera makeDefault position={[0, 0, 10]} fov={50} />
        <ambientLight intensity={0.5} />
        <pointLight position={[10, 10, 10]} intensity={1} />
        <RotatingCarousel members={members} activeIndex={activeIndex} setActiveIndex={setActiveIndex} />
        <Environment preset="apartment" />
      </Canvas>

      {/* Controls */}
      <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex gap-3">
        <Button variant="outline" size="icon" onClick={handlePrevMember}>
          <RotateCcwIcon className="h-4 w-4" />
        </Button>
        <Button variant="outline" size="icon" onClick={toggleRotation}>
          {autoRotate ? <PauseIcon className="h-4 w-4" /> : <PlayIcon className="h-4 w-4" />}
        </Button>
        <Button variant="outline" size="icon" onClick={handleNextMember}>
          <RotateCwIcon className="h-4 w-4" />
        </Button>
      </div>

      {/* Active member name */}
      <div className="absolute top-4 left-1/2 transform -translate-x-1/2 bg-background/80 backdrop-blur-sm px-4 py-2 rounded-full">
        <p className="text-sm font-medium">
          Currently viewing: <span className="font-bold">{members[activeIndex]?.name}</span>
        </p>
      </div>
    </div>
  )
}

