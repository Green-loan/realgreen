"use client"

import { memo, useEffect, useLayoutEffect, useState } from "react"
import { AnimatePresence, motion, useAnimation, useMotionValue, useTransform } from "framer-motion"
import { Star } from "lucide-react"

export const useIsomorphicLayoutEffect = typeof window !== "undefined" ? useLayoutEffect : useEffect

type UseMediaQueryOptions = {
  defaultValue?: boolean
  initializeWithValue?: boolean
}

const IS_SERVER = typeof window === "undefined"

export function useMediaQuery(
  query: string,
  { defaultValue = false, initializeWithValue = true }: UseMediaQueryOptions = {},
): boolean {
  const getMatches = (query: string): boolean => {
    if (IS_SERVER) {
      return defaultValue
    }
    return window.matchMedia(query).matches
  }

  const [matches, setMatches] = useState<boolean>(() => {
    if (initializeWithValue) {
      return getMatches(query)
    }
    return defaultValue
  })

  const handleChange = () => {
    setMatches(getMatches(query))
  }

  useIsomorphicLayoutEffect(() => {
    const matchMedia = window.matchMedia(query)
    handleChange()

    matchMedia.addEventListener("change", handleChange)

    return () => {
      matchMedia.removeEventListener("change", handleChange)
    }
  }, [query])

  return matches
}

// User review data
const reviews = [
  {
    id: 1,
    name: "Sarah Johnson",
    role: "Solar Panel Installer",
    avatar: "/placeholder.svg?height=200&width=200",
    rating: 5,
    review:
      "GreenLoan helped me finance my business expansion with favorable terms. Their process was smooth and the AI verification made approval much faster than traditional banks.",
  },
  {
    id: 2,
    name: "Michael Chen",
    role: "Homeowner",
    avatar: "/placeholder.svg?height=200&width=200",
    rating: 5,
    review:
      "I used GreenLoan to finance my home solar installation. Not only did I get a great rate, but the dashboard makes it easy to track my environmental impact.",
  },
  {
    id: 3,
    name: "Aisha Patel",
    role: "Sustainable Fashion Entrepreneur",
    avatar: "/placeholder.svg?height=200&width=200",
    rating: 4,
    review:
      "As a small business owner focused on sustainability, finding the right financing was crucial. GreenLoan understood my vision and provided the support I needed to grow.",
  },
  {
    id: 4,
    name: "David Rodriguez",
    role: "Electric Vehicle Dealer",
    avatar: "/placeholder.svg?height=200&width=200",
    rating: 5,
    review:
      "The notification system keeps me informed about payment schedules, and their customer service team is always responsive and helpful. Highly recommended!",
  },
  {
    id: 5,
    name: "Emma Wilson",
    role: "Green Building Architect",
    avatar: "/placeholder.svg?height=200&width=200",
    rating: 4,
    review:
      "GreenLoan's financing options allowed my clients to pursue more ambitious sustainable building projects. The application process was straightforward and efficient.",
  },
]

const duration = 0.15
const transition = { duration, ease: [0.32, 0.72, 0, 1] }
const transitionOverlay = { duration: 0.5, ease: [0.32, 0.72, 0, 1] }

const Carousel = memo(
  ({
    handleClick,
    controls,
    isCarouselActive,
    rotationDirection,
    autoRotate,
  }: {
    handleClick: (review: (typeof reviews)[0], index: number) => void
    controls: any
    isCarouselActive: boolean
    rotationDirection: 1 | -1
    autoRotate: boolean
  }) => {
    const isScreenSizeSm = useMediaQuery("(max-width: 640px)")
    const cylinderWidth = isScreenSizeSm ? 1100 : 1800
    const faceCount = reviews.length
    const faceWidth = cylinderWidth / faceCount
    const radius = cylinderWidth / (2 * Math.PI)
    const rotation = useMotionValue(0)
    const transform = useTransform(rotation, (value) => `rotate3d(0, 1, 0, ${value}deg)`)

    // Auto rotation effect - make it rotate faster (0.2 -> 0.4)
    useEffect(() => {
      if (autoRotate && isCarouselActive) {
        const interval = setInterval(() => {
          rotation.set(rotation.get() + 0.4 * rotationDirection)
        }, 20)
        return () => clearInterval(interval)
      }
    }, [autoRotate, isCarouselActive, rotation, rotationDirection])

    return (
      <div
        className="flex h-full items-center justify-center"
        style={{
          perspective: "1000px",
          transformStyle: "preserve-3d",
          willChange: "transform",
        }}
      >
        <motion.div
          drag={isCarouselActive ? "x" : false}
          className="relative flex h-full origin-center cursor-grab justify-center active:cursor-grabbing"
          style={{
            transform,
            rotateY: rotation,
            width: cylinderWidth,
            transformStyle: "preserve-3d",
          }}
          onDrag={(_, info) =>
            isCarouselActive && rotation.set(rotation.get() + info.offset.x * 0.05 * rotationDirection)
          }
          onDragEnd={(_, info) =>
            isCarouselActive &&
            controls.start({
              rotateY: rotation.get() + info.velocity.x * 0.05 * rotationDirection,
              transition: {
                type: "spring",
                stiffness: 100,
                damping: 30,
                mass: 0.1,
              },
            })
          }
          animate={controls}
        >
          {reviews.map((review, i) => (
            <motion.div
              key={`review-${review.id}`}
              className="absolute flex h-full origin-center items-center justify-center"
              style={{
                width: `${faceWidth}px`,
                transform: `rotateY(${i * (360 / faceCount)}deg) translateZ(${radius}px)`,
              }}
              onClick={() => handleClick(review, i)}
            >
              <motion.div
                layoutId={`review-card-${review.id}`}
                className="w-72 rounded-xl bg-background/80 backdrop-blur-sm border border-border/50 p-6 shadow-lg overflow-hidden"
                initial={{ opacity: 0.8 }}
                whileHover={{ opacity: 1 }}
                transition={transition}
              >
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 rounded-full overflow-hidden mr-4 bg-gradient-to-br from-green-400/20 to-emerald-600/20">
                    <img
                      src={review.avatar || "/placeholder.svg"}
                      alt={review.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div>
                    <h4 className="font-semibold">{review.name}</h4>
                    <p className="text-sm text-foreground/70">{review.role}</p>
                  </div>
                </div>
                <div className="flex mb-3">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star
                      key={i}
                      size={16}
                      className={i < review.rating ? "text-yellow-500 fill-yellow-500" : "text-foreground/30"}
                    />
                  ))}
                </div>
                <p className="text-sm line-clamp-4">{review.review}</p>
              </motion.div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    )
  },
)

function ThreeDPhotoCarousel() {
  const [activeReview, setActiveReview] = useState<(typeof reviews)[0] | null>(null)
  const [isCarouselActive, setIsCarouselActive] = useState(true)
  const [rotationDirection, setRotationDirection] = useState<1 | -1>(1)
  const [autoRotate, setAutoRotate] = useState(true)
  const controls = useAnimation()

  const handleClick = (review: (typeof reviews)[0]) => {
    setActiveReview(review)
    setIsCarouselActive(false)
    controls.stop()
  }

  const handleClose = () => {
    setActiveReview(null)
    setIsCarouselActive(true)
  }

  const toggleDirection = () => {
    setRotationDirection((prev) => (prev === 1 ? -1 : 1))
  }

  const toggleAutoRotate = () => {
    setAutoRotate((prev) => !prev)
  }

  return (
    <div className="relative">
      <div className="absolute top-4 right-4 z-10 flex gap-2">
        <button
          onClick={toggleDirection}
          className="px-3 py-1 rounded-full bg-background/80 backdrop-blur-sm border border-border/50 text-sm"
        >
          {rotationDirection === 1 ? "→" : "←"} Direction
        </button>
        <button
          onClick={toggleAutoRotate}
          className="px-3 py-1 rounded-full bg-background/80 backdrop-blur-sm border border-border/50 text-sm"
        >
          {autoRotate ? "Pause" : "Auto-rotate"}
        </button>
      </div>

      <AnimatePresence mode="sync">
        {activeReview && (
          <motion.div
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0 }}
            layoutId={`review-container-${activeReview.id}`}
            layout="position"
            onClick={handleClose}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4 md:p-12"
            style={{ willChange: "opacity" }}
            transition={transitionOverlay}
          >
            <motion.div
              layoutId={`review-card-${activeReview.id}`}
              className="w-full max-w-md rounded-xl bg-background border border-border/50 p-8 shadow-xl"
              onClick={(e) => e.stopPropagation()}
              initial={{ scale: 0.5 }}
              animate={{ scale: 1 }}
              transition={{
                delay: 0.2,
                duration: 0.5,
                ease: [0.25, 0.1, 0.25, 1],
              }}
            >
              <div className="flex items-center mb-6">
                <div className="w-16 h-16 rounded-full overflow-hidden mr-4 bg-gradient-to-br from-green-400/20 to-emerald-600/20">
                  <img
                    src={activeReview.avatar || "/placeholder.svg"}
                    alt={activeReview.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div>
                  <h3 className="text-xl font-semibold">{activeReview.name}</h3>
                  <p className="text-foreground/70">{activeReview.role}</p>
                </div>
              </div>
              <div className="flex mb-4">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star
                    key={i}
                    size={20}
                    className={i < activeReview.rating ? "text-yellow-500 fill-yellow-500" : "text-foreground/30"}
                  />
                ))}
              </div>
              <p className="text-foreground/90">{activeReview.review}</p>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="relative h-[500px] w-full overflow-hidden">
        <Carousel
          handleClick={handleClick}
          controls={controls}
          isCarouselActive={isCarouselActive}
          rotationDirection={rotationDirection}
          autoRotate={autoRotate}
        />
      </div>
    </div>
  )
}

export { ThreeDPhotoCarousel }

