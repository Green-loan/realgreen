"use client"

import type React from "react"

import { motion, AnimatePresence, useInView } from "framer-motion"
import { Circle, ArrowRight, Eye, EyeOff, Loader2 } from "lucide-react"
import { useState, useRef } from "react"
import { cn } from "@/lib/utils"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/components/ui/use-toast"
import { useRouter } from "next/navigation"
import { VerificationCodePopup } from "@/components/auth/verification-code-popup"
import { useSupabase } from "@/components/supabase-provider"

function ElegantShape({
  className,
  delay = 0,
  width = 400,
  height = 100,
  rotate = 0,
  gradient = "from-white/[0.08]",
  inView = false,
}: {
  className?: string
  delay?: number
  width?: number
  height?: number
  rotate?: number
  gradient?: string
  inView?: boolean
}) {
  return (
    <motion.div
      initial={{
        opacity: 0,
        y: -150,
        rotate: rotate - 15,
      }}
      animate={
        inView
          ? {
              opacity: 1,
              y: 0,
              rotate: rotate,
            }
          : {
              opacity: 0,
              y: -150,
              rotate: rotate - 15,
            }
      }
      transition={{
        duration: 2.4,
        delay,
        ease: [0.23, 0.86, 0.39, 0.96],
        opacity: { duration: 1.2 },
      }}
      className={cn("absolute", className)}
    >
      <motion.div
        animate={{
          y: [0, 15, 0],
        }}
        transition={{
          duration: 12,
          repeat: Number.POSITIVE_INFINITY,
          ease: "easeInOut",
        }}
        style={{
          width,
          height,
        }}
        className="relative"
      >
        <div
          className={cn(
            "absolute inset-0 rounded-full",
            "bg-gradient-to-r to-transparent",
            gradient,
            "backdrop-blur-[2px] border-2 border-white/[0.15] dark:border-white/[0.15] border-black/[0.05] light:border-black/[0.05]",
            "shadow-[0_8px_32px_0_rgba(255,255,255,0.1)] dark:shadow-[0_8px_32px_0_rgba(255,255,255,0.1)] light:shadow-[0_8px_32px_0_rgba(0,0,0,0.05)]",
            "after:absolute after:inset-0 after:rounded-full",
            "after:bg-[radial-gradient(circle_at_50%_50%,rgba(255,255,255,0.2),transparent_70%)] dark:after:bg-[radial-gradient(circle_at_50%_50%,rgba(255,255,255,0.2),transparent_70%)] light:after:bg-[radial-gradient(circle_at_50%_50%,rgba(0,0,0,0.05),transparent_70%)]",
          )}
        />
      </motion.div>
    </motion.div>
  )
}

function AuthForm() {
  const [activeTab, setActiveTab] = useState<"signin" | "signup">("signin")
  const [isLoading, setIsLoading] = useState(false)
  const [showPassword, setShowPassword] = useState(false)
  const { supabase } = useSupabase()
  const { toast } = useToast()
  const router = useRouter()
  const [error, setError] = useState<string | null>(null)
  const [showVerification, setShowVerification] = useState(false)
  const [verificationEmail, setVerificationEmail] = useState("")

  const [signinData, setSigninData] = useState({
    email: "",
    password: "",
  })

  const [signupData, setSignupData] = useState({
    email: "",
    password: "",
    fullName: "",
    phone: "",
  })

  const handleSigninChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSigninData({
      ...signinData,
      [e.target.name]: e.target.value,
    })
  }

  const handleSignupChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSignupData({
      ...signupData,
      [e.target.name]: e.target.value,
    })
  }

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      if (!supabase) {
        throw new Error("Authentication service is not available")
      }

      const { error } = await supabase.auth.signInWithPassword({
        email: signinData.email,
        password: signinData.password,
      })

      if (error) {
        throw error
      }

      toast({
        title: "Login successful!",
        description: "Welcome back to GreenLoan.",
      })

      router.push("/dashboard")
    } catch (error: any) {
      console.error("Login error:", error)

      let errorMessage = "Login failed"

      if (error.message?.includes("Invalid login credentials")) {
        errorMessage = "Invalid email or password."
      } else if (error.message) {
        errorMessage = error.message
      }

      toast({
        variant: "destructive",
        title: "Login failed",
        description: errorMessage,
      })
    } finally {
      setIsLoading(false)
    }
  }

  // Completely bypass Supabase for registration in development/demo mode
  const handleRegister = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setIsLoading(true)
    setError("")

    try {
      // Validate required fields
      if (!signupData.email || !signupData.password || !signupData.fullName) {
        setError("Please fill in all required fields")
        setIsLoading(false)
        return
      }

      // Validate email format
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
      if (!emailRegex.test(signupData.email)) {
        setError("Please enter a valid email address")
        setIsLoading(false)
        return
      }

      // Validate password strength
      if (signupData.password.length < 6) {
        setError("Password must be at least 6 characters long")
        setIsLoading(false)
        return
      }

      if (!supabase) {
        throw new Error("Authentication service is not available")
      }

      // Register the user with Supabase
      const { data, error } = await supabase.auth.signUp({
        email: signupData.email,
        password: signupData.password,
        options: {
          data: {
            full_name: signupData.fullName,
            phone: signupData.phone || "",
          },
          emailRedirectTo: `${window.location.origin}/auth/callback`,
        },
      })

      if (error) {
        throw error
      }

      // If user was created successfully but we need to ensure profile exists
      if (data?.user) {
        try {
          // Try to manually create the profile if the trigger didn't work
          const { error: profileError } = await supabase.from("profiles").upsert(
            {
              id: data.user.id,
              full_name: signupData.fullName,
              email: signupData.email,
              phone: signupData.phone || "",
              updated_at: new Date().toISOString(),
            },
            { onConflict: "id" },
          )

          if (profileError) {
            console.warn("Profile creation fallback failed:", profileError)
            // Continue anyway since the user was created
          }
        } catch (profileErr) {
          console.warn("Profile creation fallback error:", profileErr)
          // Continue anyway since the user was created
        }
      }

      // Show success message
      toast({
        title: "Registration successful!",
        description: "Please check your email for verification instructions.",
      })

      // Open verification popup
      setVerificationEmail(signupData.email)
      setShowVerification(true)

      // Clear form
      setSignupData({
        email: "",
        password: "",
        fullName: "",
        phone: "",
      })
    } catch (err: any) {
      console.error("Error in registration:", err)

      // Provide more user-friendly error messages
      let errorMsg = "An error occurred. Please try again."

      if (err.message?.includes("Database error")) {
        errorMsg = "Account created but profile setup failed. Please contact support."
      } else if (err.message?.includes("already registered")) {
        errorMsg = "This email is already registered. Please sign in instead."
      } else if (err.message) {
        errorMsg = err.message
      }

      setError(errorMsg)

      toast({
        variant: "destructive",
        title: "Registration failed",
        description: errorMsg,
      })
    } finally {
      setIsLoading(false)
    }
  }

  // Rest of the component remains the same
  return (
    <Card className="border-border/30 bg-background/30 backdrop-blur-sm overflow-hidden w-full max-w-md shadow-xl border-teal-600/20 bg-gradient-to-br from-teal-600/5 to-blue-600/10">
      <Tabs
        defaultValue={activeTab}
        onValueChange={(value) => setActiveTab(value as "signin" | "signup")}
        className="w-full"
      >
        <TabsList className="grid w-full grid-cols-2 rounded-none bg-transparent">
          <TabsTrigger
            value="signin"
            className="rounded-none data-[state=active]:bg-teal-600/10 data-[state=active]:text-teal-500 transition-all duration-300"
          >
            Sign In
          </TabsTrigger>
          <TabsTrigger
            value="signup"
            className="rounded-none data-[state=active]:bg-teal-600/10 data-[state=active]:text-teal-500 transition-all duration-300"
          >
            Sign Up
          </TabsTrigger>
        </TabsList>

        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, x: activeTab === "signin" ? -20 : 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: activeTab === "signin" ? 20 : -20 }}
            transition={{ duration: 0.3 }}
          >
            <TabsContent value="signin" className="p-6 mt-0">
              <form onSubmit={handleLogin} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="signin-email">Email</Label>
                  <Input
                    id="signin-email"
                    name="email"
                    type="email"
                    value={signinData.email}
                    onChange={handleSigninChange}
                    required
                    className="bg-background/30 border-teal-600/20 focus:border-teal-500/50"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="signin-password">Password</Label>
                  <div className="relative">
                    <Input
                      id="signin-password"
                      name="password"
                      type={showPassword ? "text" : "password"}
                      value={signinData.password}
                      onChange={handleSigninChange}
                      required
                      className="bg-background/30 border-teal-600/20 focus:border-teal-500/50 pr-10"
                    />
                    <button
                      type="button"
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-foreground/60"
                      onClick={() => setShowPassword(!showPassword)}
                    >
                      {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                    </button>
                  </div>
                </div>

                <Button
                  type="submit"
                  className="w-full bg-gradient-to-r from-teal-500 to-blue-600 hover:from-teal-600 hover:to-blue-700"
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Signing in...
                    </>
                  ) : (
                    "Sign In"
                  )}
                </Button>

                <div className="relative my-4">
                  <div className="absolute inset-0 flex items-center">
                    <div className="w-full border-t border-border/30"></div>
                  </div>
                  <div className="relative flex justify-center text-xs">
                    <span className="bg-background/30 px-2 text-foreground/60">Or continue with</span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <Button variant="outline" type="button" className="bg-background/30 border-teal-600/20">
                    <svg className="mr-2 h-4 w-4" viewBox="0 0 24 24">
                      <path
                        d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                        fill="#4285F4"
                      />
                      <path
                        d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                        fill="#34A853"
                      />
                      <path
                        d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
                        fill="#FBBC05"
                      />
                      <path
                        d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                        fill="#EA4335"
                      />
                    </svg>
                    Google
                  </Button>
                  <Button variant="outline" type="button" className="bg-background/30 border-teal-600/20">
                    <svg className="mr-2 h-4 w-4" fill="#1877F2" viewBox="0 0 24 24">
                      <path d="M9.19795 21.5H13.198V13.4901H16.8021L17.198 9.50977H13.198V7.5C13.198 6.94772 13.6457 6.5 14.198 6.5H17.198V2.5H14.198C11.4365 2.5 9.19795 4.73858 9.19795 7.5V9.50977H7.19795L6.80206 13.4901H9.19795V21.5Z" />
                    </svg>
                    Facebook
                  </Button>
                </div>
              </form>
            </TabsContent>

            <TabsContent value="signup" className="p-6 mt-0">
              <form onSubmit={handleRegister} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="signup-fullName">Full Name</Label>
                  <Input
                    id="signup-fullName"
                    name="fullName"
                    value={signupData.fullName}
                    onChange={handleSignupChange}
                    required
                    className="bg-background/30 border-teal-600/20 focus:border-teal-500/50"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="signup-email">Email</Label>
                  <Input
                    id="signup-email"
                    name="email"
                    type="email"
                    value={signupData.email}
                    onChange={handleSignupChange}
                    required
                    className="bg-background/30 border-teal-600/20 focus:border-teal-500/50"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="signup-phone">Phone Number</Label>
                  <Input
                    id="signup-phone"
                    name="phone"
                    type="tel"
                    value={signupData.phone}
                    onChange={handleSignupChange}
                    required
                    className="bg-background/30 border-teal-600/20 focus:border-teal-500/50"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="signup-password">Password</Label>
                  <div className="relative">
                    <Input
                      id="signup-password"
                      name="password"
                      type={showPassword ? "text" : "password"}
                      value={signupData.password}
                      onChange={handleSignupChange}
                      required
                      minLength={6}
                      className="bg-background/30 border-teal-600/20 focus:border-teal-500/50 pr-10"
                    />
                    <button
                      type="button"
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-foreground/60"
                      onClick={() => setShowPassword(!showPassword)}
                    >
                      {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                    </button>
                  </div>
                </div>

                {error && (
                  <div className="text-sm text-red-500 p-2 bg-red-50 border border-red-200 rounded">{error}</div>
                )}

                <Button
                  type="submit"
                  className="w-full bg-gradient-to-r from-teal-500 to-blue-600 hover:from-teal-600 hover:to-blue-700"
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Creating account...
                    </>
                  ) : (
                    "Sign Up"
                  )}
                </Button>

                <div className="relative my-4">
                  <div className="absolute inset-0 flex items-center">
                    <div className="w-full border-t border-border/30"></div>
                  </div>
                  <div className="relative flex justify-center text-xs">
                    <span className="bg-background/30 px-2 text-foreground/60">Or continue with</span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <Button variant="outline" type="button" className="bg-background/30 border-teal-600/20">
                    <svg className="mr-2 h-4 w-4" viewBox="0 0 24 24">
                      <path
                        d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                        fill="#4285F4"
                      />
                      <path
                        d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                        fill="#34A853"
                      />
                      <path
                        d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
                        fill="#FBBC05"
                      />
                      <path
                        d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                        fill="#EA4335"
                      />
                    </svg>
                    Google
                  </Button>
                  <Button variant="outline" type="button" className="bg-background/30 border-teal-600/20">
                    <svg className="mr-2 h-4 w-4" fill="#1877F2" viewBox="0 0 24 24">
                      <path d="M9.19795 21.5H13.198V13.4901H16.8021L17.198 9.50977H13.198V7.5C13.198 6.94772 13.6457 6.5 14.198 6.5H17.198V2.5H14.198C11.4365 2.5 9.19795 4.73858 9.19795 7.5V9.50977H7.19795L6.80206 13.4901H9.19795V21.5Z" />
                    </svg>
                    Facebook
                  </Button>
                </div>
              </form>
            </TabsContent>
          </motion.div>
        </AnimatePresence>
      </Tabs>
      <VerificationCodePopup
        isOpen={showVerification}
        onClose={() => setShowVerification(false)}
        email={verificationEmail}
      />
    </Card>
  )
}

function HeroGeometric({
  badge = "",
  title1 = "Elevate Your Digital Vision",
  title2 = "Crafting Exceptional Websites",
}: {
  badge?: string
  title1?: string
  title2?: string
}) {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: false, amount: 0.3 })

  const fadeUpVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: (i: number) => ({
      opacity: 1,
      y: 0,
      transition: {
        duration: 1,
        delay: 0.5 + i * 0.2,
        ease: [0.25, 0.4, 0.25, 1],
      },
    }),
  }

  return (
    <div
      ref={ref}
      className="relative min-h-screen w-full flex items-center justify-center overflow-hidden bg-background"
    >
      <div className="absolute inset-0 bg-gradient-to-br from-teal-600/[0.05] via-transparent to-blue-600/[0.05] blur-3xl dark:from-teal-600/[0.05] dark:to-blue-600/[0.05] light:from-teal-600/[0.02] light:to-blue-600/[0.02]" />

      <div className="absolute inset-0 overflow-hidden">
        <ElegantShape
          delay={0.3}
          width={600}
          height={140}
          rotate={12}
          gradient="from-teal-600/[0.15] dark:from-teal-600/[0.15] light:from-teal-600/[0.08]"
          className="left-[-10%] md:left-[-5%] top-[15%] md:top-[20%]"
          inView={isInView}
        />

        <ElegantShape
          delay={0.5}
          width={500}
          height={120}
          rotate={-15}
          gradient="from-blue-600/[0.15] dark:from-blue-600/[0.15] light:from-blue-600/[0.08]"
          className="right-[-5%] md:right-[0%] top-[70%] md:top-[75%]"
          inView={isInView}
        />

        <ElegantShape
          delay={0.4}
          width={300}
          height={80}
          rotate={-8}
          gradient="from-teal-600/[0.15] dark:from-teal-600/[0.15] light:from-teal-600/[0.08]"
          className="left-[5%] md:left-[10%] bottom-[5%] md:bottom-[10%]"
          inView={isInView}
        />

        <ElegantShape
          delay={0.6}
          width={200}
          height={60}
          rotate={20}
          gradient="from-blue-600/[0.15] dark:from-blue-600/[0.15] light:from-blue-600/[0.08]"
          className="right-[15%] md:right-[20%] top-[10%] md:top-[15%]"
          inView={isInView}
        />

        <ElegantShape
          delay={0.7}
          lay={0.7}
          width={150}
          height={40}
          rotate={-25}
          gradient="from-teal-600/[0.15] dark:from-teal-600/[0.15] light:from-teal-600/[0.08]"
          className="left-[20%] md:left-[25%] top-[5%] md:top-[10%]"
          inView={isInView}
        />
      </div>

      <div className="relative z-10 container mx-auto px-4 md:px-6 pt-32 md:pt-40">
        <div className="flex flex-col lg:flex-row items-center justify-between gap-12">
          {/* Left Column - Hero Content */}
          <div className="w-full lg:w-1/2">
            <div className="max-w-xl">
              {badge && (
                <motion.div
                  custom={0}
                  variants={fadeUpVariants}
                  initial="hidden"
                  animate={isInView ? "visible" : "hidden"}
                  className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/[0.03] dark:bg-white/[0.03] light:bg-black/[0.03] border border-white/[0.08] dark:border-white/[0.08] light:border-black/[0.08] mb-8 md:mb-12"
                >
                  <Circle className="h-2 w-2 fill-green-500/80" />
                  <span className="text-sm text-foreground/60 tracking-wide">{badge}</span>
                </motion.div>
              )}

              <motion.div
                custom={1}
                variants={fadeUpVariants}
                initial="hidden"
                animate={isInView ? "visible" : "hidden"}
              >
                <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold mb-6 md:mb-8 tracking-tight">
                  <span className="bg-clip-text text-transparent bg-gradient-to-b from-foreground to-foreground/80 dark:from-white dark:to-white/80 light:from-black light:to-black/80">
                    {title1}
                  </span>
                  <br />
                  <span
                    className={cn(
                      "bg-clip-text text-transparent bg-gradient-to-r from-teal-500 via-foreground/90 to-blue-600 dark:from-teal-400 dark:via-white/90 dark:to-blue-400 light:from-teal-600 light:via-black/90 light:to-blue-700",
                    )}
                  >
                    {title2}
                  </span>
                </h1>
              </motion.div>

              <motion.div
                custom={2}
                variants={fadeUpVariants}
                initial="hidden"
                animate={isInView ? "visible" : "hidden"}
                className="mt-4"
              >
                <p className="text-base sm:text-lg text-foreground/40 mb-8 leading-relaxed font-light tracking-wide">
                  Financing solutions with a fixed 39.99% interest rate. Apply today and get approved quickly for your
                  loan needs.
                </p>

                <Button
                  asChild
                  size="lg"
                  className="bg-gradient-to-r from-teal-500 to-blue-600 hover:from-teal-600 hover:to-blue-700"
                >
                  <Link href="/apply">
                    Apply Now
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Link>
                </Button>
              </motion.div>
            </div>
          </div>

          {/* Right Column - Auth Form */}
          <motion.div
            custom={3}
            variants={fadeUpVariants}
            initial="hidden"
            animate={isInView ? "visible" : "hidden"}
            className="w-full lg:w-1/2 flex justify-center"
          >
            <div className="relative">
              <div className="absolute -inset-1 bg-teal-500/20 rounded-xl blur-xl"></div>
              <AuthForm />
            </div>
          </motion.div>
        </div>
      </div>

      <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-background/80 pointer-events-none" />
    </div>
  )
}

// HeroGeometric component remains the same

export { HeroGeometric }

export function ShapeLandingHero() {
  const router = useRouter()

  const handleLoginRedirect = () => {
    router.push("/login")
  }

  return (
    <section className="w-full py-12 md:py-24 lg:py-32 xl:py-48 bg-black">
      <div className="container px-4 md:px-6">
        <div className="grid gap-6 lg:grid-cols-[1fr_400px] lg:gap-12 xl:grid-cols-[1fr_600px]">
          <div className="flex flex-col justify-center space-y-4">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold tracking-tighter text-white sm:text-5xl xl:text-6xl/none">
                Welcome to Green Finance
              </h1>
              <p className="max-w-[600px] text-gray-300 md:text-xl">
                Empowering sustainable development through innovative financial solutions. Join us in building a greener
                future.
              </p>
            </div>
            <div className="flex flex-col gap-2 min-[400px]:flex-row">
              <Button onClick={handleLoginRedirect} className="bg-green-600 hover:bg-green-700">
                Get Started
              </Button>
              <Button variant="outline" className="border-green-600 text-green-600 hover:bg-green-950">
                Learn More
              </Button>
            </div>
          </div>
          <div className="flex items-center justify-center">{/* 3D Robot Scene would go here */}</div>
        </div>
      </div>
    </section>
  )
}

