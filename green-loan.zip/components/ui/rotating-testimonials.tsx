"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Card, CardContent } from "@/components/ui/card"

interface Testimonial {
  id: number
  name: string
  role: string
  company: string
  content: string
  avatar: string
}

const testimonials: Testimonial[] = [
  {
    id: 1,
    name: "Sarah Johnson",
    role: "CFO",
    company: "EcoTech Solutions",
    content:
      "Green Fina helped us secure funding for our solar panel installation project. The process was seamless and the rates were competitive.",
    avatar: "/placeholder.svg?height=40&width=40",
  },
  {
    id: 2,
    name: "Michael Chen",
    role: "Sustainability Director",
    company: "Urban Greening Initiative",
    content:
      "Thanks to Green Fina, we were able to finance our community garden project. Their team understood our vision from day one.",
    avatar: "/placeholder.svg?height=40&width=40",
  },
  {
    id: 3,
    name: "Priya Patel",
    role: "CEO",
    company: "Renewable Energy Partners",
    content:
      "The green loan we secured through this platform enabled us to expand our wind farm operations. Excellent service and support throughout.",
    avatar: "/placeholder.svg?height=40&width=40",
  },
  {
    id: 4,
    name: "David Rodriguez",
    role: "Project Manager",
    company: "Sustainable Housing Co-op",
    content:
      "We couldn't have completed our eco-friendly housing development without Green Fina's financing solutions. Truly a game-changer.",
    avatar: "/placeholder.svg?height=40&width=40",
  },
  {
    id: 5,
    name: "Emma Wilson",
    role: "Operations Director",
    company: "Clean Water Initiative",
    content:
      "Green Fina understood our mission and provided the perfect financing solution for our water purification project. Highly recommended!",
    avatar: "/placeholder.svg?height=40&width=40",
  },
  {
    id: 6,
    name: "James Thompson",
    role: "Finance Manager",
    company: "Green Building Associates",
    content:
      "The application process was straightforward and the team was incredibly helpful. Our LEED-certified building project is now fully funded.",
    avatar: "/placeholder.svg?height=40&width=40",
  },
  {
    id: 7,
    name: "Olivia Martinez",
    role: "Community Organizer",
    company: "Urban Farms Collective",
    content:
      "Green Fina's financing enabled us to transform vacant lots into productive urban farms. Their commitment to sustainability is unmatched.",
    avatar: "/placeholder.svg?height=40&width=40",
  },
  {
    id: 8,
    name: "Robert Kim",
    role: "Chief Innovation Officer",
    company: "EcoTech Innovations",
    content:
      "As a green tech startup, finding the right financing was crucial. Green Fina delivered exactly what we needed to bring our product to market.",
    avatar: "/placeholder.svg?height=40&width=40",
  },
]

export function RotatingTestimonials() {
  const [activeIndex, setActiveIndex] = useState(0)

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveIndex((current) => (current + 1) % testimonials.length)
    }, 5000)
    return () => clearInterval(interval)
  }, [])

  return (
    <div className="relative h-[600px] w-full overflow-hidden py-10">
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
        <h2 className="text-3xl font-bold text-center mb-8 text-primary">What Our Clients Say</h2>
        <div className="relative h-[400px] w-[400px] md:h-[500px] md:w-[500px]">
          {testimonials.map((testimonial, index) => {
            // Calculate position in the circle
            const angle = (index * (360 / testimonials.length) + activeIndex * (360 / testimonials.length)) % 360
            const radian = (angle * Math.PI) / 180
            const radius = 200 // Increased radius for larger circle

            const x = radius * Math.cos(radian)
            const y = radius * Math.sin(radian)

            // Calculate z-index based on y position (cards in front should appear on top)
            const zIndex = Math.round(50 - y)

            // Calculate scale based on y position (cards in front should be larger)
            const scale = 0.8 + (y + radius) / (radius * 3)

            return (
              <motion.div
                key={testimonial.id}
                className="absolute top-1/2 left-1/2 w-[280px]"
                animate={{
                  x: x,
                  y: y,
                  scale: scale,
                  zIndex: zIndex,
                  transition: { duration: 0.8, ease: "easeInOut" },
                }}
                initial={false}
              >
                <Card className="bg-white shadow-lg border-0" style={{ opacity: 0.95 }}>
                  <CardContent className="p-6">
                    <div className="flex items-center gap-4 mb-4">
                      <Avatar>
                        <AvatarImage src={testimonial.avatar} alt={testimonial.name} />
                        <AvatarFallback>{testimonial.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-semibold text-foreground">{testimonial.name}</p>
                        <p className="text-sm text-muted-foreground">
                          {testimonial.role}, {testimonial.company}
                        </p>
                      </div>
                    </div>
                    <p className="text-foreground font-medium">{testimonial.content}</p>
                  </CardContent>
                </Card>
              </motion.div>
            )
          })}
        </div>
      </div>
    </div>
  )
}

