import { Icons } from "@/components/icons"

interface LoadingScreenProps {
  isLoading: boolean
  message?: string
}

export function LoadingScreen({ isLoading, message = "Loading..." }: LoadingScreenProps) {
  if (!isLoading) return null

  return (
    <div className="fixed inset-0 flex flex-col items-center justify-center bg-white bg-opacity-90 z-50">
      <div className="flex flex-col items-center justify-center space-y-4">
        <div className="relative">
          <div className="h-16 w-16 rounded-full border-4 border-t-green-500 border-r-transparent border-b-transparent border-l-transparent animate-spin"></div>
          <div className="absolute inset-0 flex items-center justify-center">
            <Icons.leaf className="h-8 w-8 text-green-500" />
          </div>
        </div>
        <p className="text-lg font-medium text-gray-700">{message}</p>
      </div>
    </div>
  )
}

