import Link from "next/link"

import { siteConfig } from "@/config/site"
import { cn } from "@/lib/utils"
import { Icons } from "@/components/icons"
import { buttonVariants } from "@/components/ui/button"

interface MainNavProps {
  className?: string
}

export function MainNav({ className }: MainNavProps) {
  const navigationItems = [
    { title: "Dashboard", href: "/dashboard" },
    { title: "About", href: "/about" },
    { title: "Blog", href: siteConfig.links.twitter, external: true },
    { title: "Documentation", href: siteConfig.links.docs, external: true },
  ]

  return (
    <nav className={cn("flex items-center space-x-6", className)}>
      <Link href="/" className="flex items-center space-x-2">
        <Icons.logo className="h-6 w-6" aria-hidden="true" />
        <span className="hidden font-bold sm:inline-block">{siteConfig.name}</span>
      </Link>
      <ul className="flex gap-6">
        {navigationItems.map((item) => (
          <li key={item.title}>
            <Link
              href={item.href}
              className={buttonVariants({ variant: "ghost", size: "sm" })}
              target={item.external ? "_blank" : undefined}
              rel={item.external ? "noreferrer" : undefined}
            >
              {item.title}
            </Link>
          </li>
        ))}
      </ul>
    </nav>
  )
}

