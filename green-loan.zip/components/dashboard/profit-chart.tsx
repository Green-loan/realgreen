"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function ProfitChart() {
  const [timeframe, setTimeframe] = useState("this-week")

  // Mock data for the chart
  const chartData = {
    days: ["Sat", "Sun", "Mon", "Tue", "Wed", "Thu", "Fri"],
    sales: [40, 35, 10, 0, 0, 0, 0],
    revenue: [60, 45, 15, 10, 0, 0, 0],
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-md font-medium">Profit this week</CardTitle>
        <Select value={timeframe} onValueChange={setTimeframe}>
          <SelectTrigger className="w-[120px] h-8">
            <SelectValue placeholder="Select timeframe" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="this-week">This Week</SelectItem>
            <SelectItem value="last-week">Last Week</SelectItem>
            <SelectItem value="this-month">This Month</SelectItem>
          </SelectContent>
        </Select>
      </CardHeader>
      <CardContent>
        <div className="flex items-center gap-4 mb-4">
          <div className="flex items-center gap-1">
            <div className="h-3 w-3 rounded-full bg-indigo-500"></div>
            <span className="text-sm">Sales</span>
          </div>
          <div className="flex items-center gap-1">
            <div className="h-3 w-3 rounded-full bg-cyan-400"></div>
            <span className="text-sm">Revenue</span>
          </div>
        </div>

        <div className="h-[200px] relative mt-4">
          {/* Y-axis labels */}
          <div className="absolute left-0 top-0 h-full flex flex-col justify-between text-xs text-muted-foreground">
            <span>100</span>
            <span>80</span>
            <span>60</span>
            <span>40</span>
            <span>20</span>
            <span>0</span>
          </div>

          {/* Chart area */}
          <div className="ml-8 h-full flex items-end justify-between">
            {chartData.days.map((day, index) => (
              <div key={index} className="flex flex-col items-center gap-1 w-full">
                <div className="relative h-[180px] w-8">
                  {/* Sales bar */}
                  {chartData.sales[index] > 0 && (
                    <div
                      className="absolute bottom-0 w-full bg-indigo-500 rounded-t"
                      style={{ height: `${chartData.sales[index] * 1.8}px` }}
                    ></div>
                  )}

                  {/* Revenue bar */}
                  {chartData.revenue[index] > 0 && (
                    <div
                      className="absolute bottom-0 w-full bg-cyan-400 rounded-t ml-4"
                      style={{ height: `${chartData.revenue[index] * 1.8}px` }}
                    ></div>
                  )}
                </div>
                <span className="text-xs text-muted-foreground">{day}</span>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

