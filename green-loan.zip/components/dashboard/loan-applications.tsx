"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"

// Mock data for loan applications
const loanApplications = [
  {
    id: "LOAN-2023-001",
    amount: "R 25,000",
    purpose: "Solar Panel Installation",
    status: "approved",
    date: "2023-05-15",
    paymentStatus: "current",
    nextPayment: "2023-06-15",
    remainingAmount: "R 22,500",
  },
  {
    id: "LOAN-2023-002",
    amount: "R 15,000",
    purpose: "Energy Efficient Appliances",
    status: "processing",
    date: "2023-05-28",
    paymentStatus: "pending",
    nextPayment: "N/A",
    remainingAmount: "R 15,000",
  },
  {
    id: "LOAN-2022-045",
    amount: "R 30,000",
    purpose: "Home Insulation",
    status: "completed",
    date: "2022-11-10",
    paymentStatus: "paid",
    nextPayment: "N/A",
    remainingAmount: "R 0",
  },
]

export function LoanApplications() {
  return (
    <div className="space-y-4">
      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle>Your Loan Applications</CardTitle>
          <CardDescription className="text-gray-400">View and manage all your green loan applications</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow className="border-gray-700">
                <TableHead className="text-gray-400">Loan ID</TableHead>
                <TableHead className="text-gray-400">Amount</TableHead>
                <TableHead className="text-gray-400">Purpose</TableHead>
                <TableHead className="text-gray-400">Status</TableHead>
                <TableHead className="text-gray-400">Application Date</TableHead>
                <TableHead className="text-gray-400">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loanApplications.map((loan) => (
                <TableRow key={loan.id} className="border-gray-700">
                  <TableCell className="font-medium">{loan.id}</TableCell>
                  <TableCell>{loan.amount}</TableCell>
                  <TableCell>{loan.purpose}</TableCell>
                  <TableCell>
                    <Badge
                      variant={
                        loan.status === "approved"
                          ? "default"
                          : loan.status === "processing"
                            ? "outline"
                            : loan.status === "completed"
                              ? "secondary"
                              : "default"
                      }
                      className={
                        loan.status === "approved"
                          ? "bg-green-900/20 text-green-500 border-green-800"
                          : loan.status === "processing"
                            ? "bg-blue-900/20 text-blue-500 border-blue-800"
                            : "bg-gray-900/20 text-gray-400 border-gray-800"
                      }
                    >
                      {loan.status}
                    </Badge>
                  </TableCell>
                  <TableCell>{loan.date}</TableCell>
                  <TableCell>
                    <Button variant="outline" size="sm" className="border-gray-700 hover:bg-gray-700">
                      View Details
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle>Payment Schedule</CardTitle>
          <CardDescription className="text-gray-400">Your upcoming loan payments</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow className="border-gray-700">
                <TableHead className="text-gray-400">Loan ID</TableHead>
                <TableHead className="text-gray-400">Payment Status</TableHead>
                <TableHead className="text-gray-400">Next Payment</TableHead>
                <TableHead className="text-gray-400">Remaining Amount</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loanApplications.map((loan) => (
                <TableRow key={loan.id} className="border-gray-700">
                  <TableCell className="font-medium">{loan.id}</TableCell>
                  <TableCell>
                    <Badge
                      variant={
                        loan.paymentStatus === "current"
                          ? "default"
                          : loan.paymentStatus === "pending"
                            ? "outline"
                            : loan.paymentStatus === "paid"
                              ? "secondary"
                              : "default"
                      }
                      className={
                        loan.paymentStatus === "current"
                          ? "bg-green-900/20 text-green-500 border-green-800"
                          : loan.paymentStatus === "pending"
                            ? "bg-yellow-900/20 text-yellow-500 border-yellow-800"
                            : "bg-gray-900/20 text-gray-400 border-gray-800"
                      }
                    >
                      {loan.paymentStatus}
                    </Badge>
                  </TableCell>
                  <TableCell>{loan.nextPayment}</TableCell>
                  <TableCell>{loan.remainingAmount}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}

