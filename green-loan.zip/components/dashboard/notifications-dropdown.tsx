"use client"

import { useState } from "react"
import Link from "next/link"
import { Bell } from "lucide-react"
import { AnimatePresence, motion } from "framer-motion"
import { cn } from "@/lib/utils"

// Sample notification data
const notifications = [
  {
    id: 1,
    title: "Loan Application Approved",
    description: "Your loan application #12345 has been approved.",
    time: "2 hours ago",
    read: false,
    type: "success",
  },
  {
    id: 2,
    title: "Payment Reminder",
    description: "Your loan payment of R 1,500 is due in 3 days.",
    time: "1 day ago",
    read: false,
    type: "warning",
  },
  {
    id: 3,
    title: "Stokvel Contribution",
    description: "You've received R 6,000 from the Stokvel group.",
    time: "2 days ago",
    read: true,
    type: "info",
  },
  {
    id: 4,
    title: "New Investment Opportunity",
    description: "Check out our new green investment options with 8% returns.",
    time: "3 days ago",
    read: true,
    type: "info",
  },
  {
    id: 5,
    title: "Document Verification",
    description: "Your ID document has been successfully verified.",
    time: "1 week ago",
    read: true,
    type: "success",
  },
]

export function NotificationsDropdown() {
  const [isOpen, setIsOpen] = useState(false)
  const [notificationData, setNotificationData] = useState(notifications)

  const unreadCount = notificationData.filter((n) => !n.read).length

  const toggleDropdown = () => {
    setIsOpen(!isOpen)
  }

  const markAllAsRead = () => {
    setNotificationData(notificationData.map((n) => ({ ...n, read: true })))
  }

  const getTypeStyles = (type: string) => {
    switch (type) {
      case "success":
        return "bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400"
      case "warning":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-400"
      case "error":
        return "bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400"
      default:
        return "bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-400"
    }
  }

  return (
    <div className="relative">
      <button
        onClick={toggleDropdown}
        className="relative p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
        aria-label="Notifications"
      >
        <Bell className="h-6 w-6" />
        {unreadCount > 0 && (
          <span className="absolute top-1 right-1 flex h-4 w-4 items-center justify-center rounded-full bg-red-500 text-[10px] font-bold text-white">
            {unreadCount}
          </span>
        )}
      </button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 10 }}
            transition={{ duration: 0.2 }}
            className="absolute right-0 mt-2 w-80 sm:w-96 overflow-hidden rounded-lg border border-gray-200 bg-white shadow-lg dark:border-gray-800 dark:bg-gray-950 z-50"
          >
            <div className="flex items-center justify-between border-b border-gray-200 px-4 py-3 dark:border-gray-800">
              <h3 className="font-semibold">Notifications</h3>
              <div className="flex gap-2">
                <button
                  onClick={markAllAsRead}
                  className="text-xs text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300"
                >
                  Mark all as read
                </button>
              </div>
            </div>

            <div className="max-h-[60vh] overflow-y-auto">
              {notificationData.length > 0 ? (
                <div className="divide-y divide-gray-200 dark:divide-gray-800">
                  {notificationData.map((notification) => (
                    <div
                      key={notification.id}
                      className={cn(
                        "flex gap-3 px-4 py-3 hover:bg-gray-50 dark:hover:bg-gray-900/50 transition-colors",
                        !notification.read && "bg-blue-50 dark:bg-blue-900/10",
                      )}
                    >
                      <div
                        className={cn(
                          "mt-1 h-2 w-2 flex-shrink-0 rounded-full",
                          notification.read ? "bg-gray-300 dark:bg-gray-700" : "bg-blue-500",
                        )}
                      />
                      <div className="flex-1 space-y-1">
                        <div className="flex items-center justify-between gap-2">
                          <p className="font-medium">{notification.title}</p>
                          <span className="text-xs text-gray-500 dark:text-gray-400">{notification.time}</span>
                        </div>
                        <p className="text-sm text-gray-600 dark:text-gray-300">{notification.description}</p>
                        <div className="pt-1">
                          <span
                            className={cn(
                              "inline-block rounded-full px-2 py-0.5 text-xs font-medium",
                              getTypeStyles(notification.type),
                            )}
                          >
                            {notification.type.charAt(0).toUpperCase() + notification.type.slice(1)}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center py-8">
                  <p className="text-gray-500 dark:text-gray-400">No notifications</p>
                </div>
              )}
            </div>

            <div className="border-t border-gray-200 p-2 dark:border-gray-800">
              <Link
                href="/dashboard/notifications"
                className="block rounded-md px-4 py-2 text-center text-sm font-medium text-blue-600 hover:bg-blue-50 dark:text-blue-400 dark:hover:bg-blue-900/20"
                onClick={() => setIsOpen(false)}
              >
                View all notifications
              </Link>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

