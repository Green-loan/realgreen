"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { useSupabase } from "@/components/supabase-provider"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import {
  ChevronLeft,
  LayoutDashboard,
  FileText,
  CreditCard,
  Bell,
  Settings,
  Users,
  BarChart,
  CheckCircle,
  AlertCircle,
  LogOut,
  Home,
} from "lucide-react"
import { useIsMobile } from "@/hooks/use-mobile"

export function DashboardSidebar() {
  const pathname = usePathname()
  const { user, supabase } = useSupabase()
  const [isAdmin, setIsAdmin] = useState(false)
  const [collapsed, setCollapsed] = useState(false)
  const isMobile = useIsMobile()
  const [open, setOpen] = useState(!isMobile)

  // Check if this is an admin route
  const isAdminRoute = pathname.includes("/dashboard/admin")

  useEffect(() => {
    const checkUserRole = async () => {
      if (user) {
        const { data, error } = await supabase.from("profiles").select("role").eq("id", user.id).single()

        if (!error && data) {
          setIsAdmin(data.role === "admin")
        }
      } else if (isAdminRoute) {
        // If we're on an admin route but not logged in, we'll still show admin nav
        setIsAdmin(true)
      }
    }

    checkUserRole()
  }, [user, supabase, isAdminRoute])

  useEffect(() => {
    setOpen(!isMobile)
  }, [isMobile])

  const userNavItems = [
    {
      title: "Dashboard",
      href: "/dashboard",
      icon: LayoutDashboard,
    },
    {
      title: "My Applications",
      href: "/dashboard/applications",
      icon: FileText,
    },
    {
      title: "Payments",
      href: "/dashboard/payments",
      icon: CreditCard,
    },
    {
      title: "Notifications",
      href: "/dashboard/notifications",
      icon: Bell,
    },
    {
      title: "Settings",
      href: "/dashboard/settings",
      icon: Settings,
    },
  ]

  const adminNavItems = [
    {
      title: "Dashboard",
      href: "/dashboard",
      icon: LayoutDashboard,
    },
    {
      title: "Applications",
      href: "/dashboard/admin/applications",
      icon: FileText,
    },
    {
      title: "Users",
      href: "/dashboard/admin/users",
      icon: Users,
    },
    {
      title: "Revenue",
      href: "/dashboard/admin/revenue",
      icon: BarChart,
    },
    {
      title: "Approvals",
      href: "/dashboard/admin/approvals",
      icon: CheckCircle,
    },
    {
      title: "Notifications",
      href: "/dashboard/admin/notifications",
      icon: Bell,
    },
    {
      title: "Risk Management",
      href: "/dashboard/admin/risk",
      icon: AlertCircle,
    },
    {
      title: "Settings",
      href: "/dashboard/admin/settings",
      icon: Settings,
    },
  ]

  const navItems = isAdmin ? adminNavItems : userNavItems

  const handleSignOut = async () => {
    if (user) {
      await supabase.auth.signOut()
    }
    window.location.href = "/"
  }

  if (!open) {
    return (
      <div className="fixed inset-y-0 left-0 z-50 flex w-14 flex-col border-r border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="flex h-14 items-center justify-center border-b border-border/40">
          <Button variant="ghost" size="icon" className="h-9 w-9" onClick={() => setOpen(true)}>
            <ChevronLeft className="h-5 w-5" />
            <span className="sr-only">Toggle Sidebar</span>
          </Button>
        </div>
        <nav className="flex flex-1 flex-col gap-1 p-2">
          {navItems.map((item) => (
            <Button
              key={item.href}
              asChild
              variant="ghost"
              size="icon"
              className={cn("h-9 w-9", pathname === item.href && "bg-accent text-accent-foreground")}
            >
              <Link href={item.href}>
                <item.icon className="h-5 w-5" />
                <span className="sr-only">{item.title}</span>
              </Link>
            </Button>
          ))}
        </nav>
        <div className="flex flex-col gap-1 p-2 border-t border-border/40">
          <Button variant="ghost" size="icon" className="h-9 w-9" onClick={handleSignOut}>
            {user ? (
              <>
                <LogOut className="h-5 w-5" />
                <span className="sr-only">Sign Out</span>
              </>
            ) : (
              <>
                <Home className="h-5 w-5" />
                <span className="sr-only">Home</span>
              </>
            )}
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div
      className={cn(
        "fixed inset-y-0 left-0 z-50 flex flex-col border-r border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 transition-all duration-300",
        collapsed ? "w-14" : "w-64",
      )}
    >
      <div className="flex h-14 items-center justify-between border-b border-border/40 px-3">
        {!collapsed && (
          <div className="flex items-center gap-2">
            <div className="h-6 w-6 rounded-full bg-gradient-to-br from-green-400 to-emerald-600" />
            <span className="font-semibold text-lg">GreenLoan</span>
          </div>
        )}
        <Button
          variant="ghost"
          size="icon"
          className="h-9 w-9 ml-auto"
          onClick={() => {
            if (isMobile) {
              setOpen(false)
            } else {
              setCollapsed(!collapsed)
            }
          }}
        >
          <ChevronLeft className={cn("h-5 w-5", collapsed && "rotate-180")} />
          <span className="sr-only">Toggle Sidebar</span>
        </Button>
      </div>
      <ScrollArea className="flex-1">
        <nav className="flex flex-col gap-1 p-2">
          {navItems.map((item) => (
            <Button
              key={item.href}
              asChild
              variant="ghost"
              size={collapsed ? "icon" : "default"}
              className={cn(
                collapsed ? "h-9 w-9 p-0" : "justify-start",
                pathname === item.href && "bg-accent text-accent-foreground",
              )}
            >
              <Link href={item.href}>
                <item.icon className={cn("h-5 w-5", !collapsed && "mr-2")} />
                {!collapsed && <span>{item.title}</span>}
              </Link>
            </Button>
          ))}
        </nav>
      </ScrollArea>
      <div className="flex flex-col gap-1 p-2 border-t border-border/40">
        <Button
          variant="ghost"
          size={collapsed ? "icon" : "default"}
          className={cn(collapsed ? "h-9 w-9 p-0" : "justify-start")}
          onClick={handleSignOut}
        >
          {user ? (
            <>
              <LogOut className={cn("h-5 w-5", !collapsed && "mr-2")} />
              {!collapsed && <span>Sign Out</span>}
            </>
          ) : (
            <>
              <Home className={cn("h-5 w-5", !collapsed && "mr-2")} />
              {!collapsed && <span>Back to Home</span>}
            </>
          )}
        </Button>
      </div>
    </div>
  )
}

