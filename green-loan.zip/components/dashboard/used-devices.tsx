"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function UsedDevices() {
  const [timeframe, setTimeframe] = useState("monthly")

  // Mock data for the chart
  const deviceData = [
    { name: "Mobile", percentage: 65, color: "bg-indigo-500" },
    { name: "Desktop", percentage: 25, color: "bg-cyan-400" },
    { name: "Tablet", percentage: 10, color: "bg-emerald-500" },
  ]

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-md font-medium">Used Devices</CardTitle>
        <Select value={timeframe} onValueChange={setTimeframe}>
          <SelectTrigger className="w-[120px] h-8">
            <SelectValue placeholder="Select timeframe" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="weekly">Weekly</SelectItem>
            <SelectItem value="monthly">Monthly</SelectItem>
            <SelectItem value="yearly">Yearly</SelectItem>
          </SelectContent>
        </Select>
      </CardHeader>
      <CardContent className="flex flex-col md:flex-row items-center justify-between">
        <div className="relative w-40 h-40">
          <svg viewBox="0 0 100 100" className="w-full h-full">
            {deviceData.map((device, index) => {
              // Calculate the start and end angles for each segment
              const startAngle =
                index === 0 ? 0 : deviceData.slice(0, index).reduce((sum, d) => sum + d.percentage, 0) * 3.6

              const endAngle = startAngle + device.percentage * 3.6

              // Convert angles to radians
              const startRad = ((startAngle - 90) * Math.PI) / 180
              const endRad = ((endAngle - 90) * Math.PI) / 180

              // Calculate the SVG arc path
              const x1 = 50 + 40 * Math.cos(startRad)
              const y1 = 50 + 40 * Math.sin(startRad)
              const x2 = 50 + 40 * Math.cos(endRad)
              const y2 = 50 + 40 * Math.sin(endRad)

              const largeArcFlag = device.percentage > 50 ? 1 : 0

              const pathData = [`M 50 50`, `L ${x1} ${y1}`, `A 40 40 0 ${largeArcFlag} 1 ${x2} ${y2}`, `Z`].join(" ")

              return <path key={device.name} d={pathData} className={device.color} />
            })}
            <circle cx="50" cy="50" r="25" className="fill-background" />
          </svg>
        </div>

        <div className="mt-6 md:mt-0">
          {deviceData.map((device, index) => (
            <div key={index} className="flex items-center gap-2 mb-3">
              <div className={`h-3 w-3 rounded-full ${device.color}`}></div>
              <span className="text-sm">{device.name}</span>
              <span className="text-sm font-medium">{device.percentage}%</span>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}

