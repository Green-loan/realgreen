"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function PaymentsOverview() {
  const [timeframe, setTimeframe] = useState("monthly")

  // Mock data for the chart
  const chartData = {
    labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
    values: [10, 15, 18, 14, 22, 25, 28, 30, 28, 32, 35, 40],
  }

  // Calculate the highest value for scaling
  const maxValue = Math.max(...chartData.values)

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-md font-medium">Payments Overview</CardTitle>
        <Select value={timeframe} onValueChange={setTimeframe}>
          <SelectTrigger className="w-[120px] h-8">
            <SelectValue placeholder="Select timeframe" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="weekly">Weekly</SelectItem>
            <SelectItem value="monthly">Monthly</SelectItem>
            <SelectItem value="yearly">Yearly</SelectItem>
          </SelectContent>
        </Select>
      </CardHeader>
      <CardContent>
        <div className="h-[200px] w-full relative mt-4">
          {/* Y-axis labels */}
          <div className="absolute left-0 top-0 h-full flex flex-col justify-between text-xs text-muted-foreground">
            <span>100</span>
            <span>80</span>
            <span>60</span>
            <span>40</span>
            <span>20</span>
            <span>0</span>
          </div>

          {/* Chart area */}
          <div className="ml-8 h-full relative">
            {/* Line chart */}
            <svg
              className="w-full h-full"
              viewBox={`0 0 ${chartData.labels.length * 50} 200`}
              preserveAspectRatio="none"
            >
              <path
                d={`M 0 ${200 - (chartData.values[0] / maxValue) * 180} ${chartData.values
                  .map((value, index) => `L ${index * 50} ${200 - (value / maxValue) * 180}`)
                  .join(" ")}`}
                fill="none"
                stroke="hsl(var(--primary))"
                strokeWidth="2"
              />
            </svg>

            {/* X-axis labels */}
            <div className="absolute bottom-[-20px] w-full flex justify-between text-xs text-muted-foreground">
              {chartData.labels.map((label, index) => (
                <span
                  key={index}
                  style={{
                    position: "absolute",
                    left: `${(index / (chartData.labels.length - 1)) * 100}%`,
                    transform: "translateX(-50%)",
                  }}
                >
                  {label}
                </span>
              ))}
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4 mt-8 pt-4 border-t">
          <div>
            <p className="text-sm text-muted-foreground">Received Amount</p>
            <p className="text-xl font-bold mt-1">R580.00</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Due Amount</p>
            <p className="text-xl font-bold mt-1">R628.00</p>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

