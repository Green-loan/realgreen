"use client"

import { Eye, DollarSign, Package, Users } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

export default function MetricCards() {
  const metrics = [
    {
      title: "Total Views",
      value: "3.5K",
      change: "+0.43%",
      isPositive: true,
      icon: Eye,
      iconBg: "bg-emerald-500",
    },
    {
      title: "Total Profit",
      value: "R4.2K",
      change: "+4.35%",
      isPositive: true,
      icon: DollarSign,
      iconBg: "bg-orange-500",
    },
    {
      title: "Total Loans",
      value: "3.5K",
      change: "+2.59%",
      isPositive: true,
      icon: Package,
      iconBg: "bg-indigo-500",
    },
    {
      title: "Total Users",
      value: "3.5K",
      change: "-0.95%",
      isPositive: false,
      icon: Users,
      iconBg: "bg-cyan-500",
    },
  ]

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
      {metrics.map((metric, index) => (
        <Card key={index}>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">{metric.title}</p>
                <h3 className="text-2xl font-bold mt-1">{metric.value}</h3>
                <p
                  className={`text-xs mt-1 flex items-center ${metric.isPositive ? "text-emerald-500" : "text-red-500"}`}
                >
                  {metric.change}
                </p>
              </div>
              <div className={`${metric.iconBg} h-12 w-12 rounded-full flex items-center justify-center`}>
                <metric.icon className="h-6 w-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}

