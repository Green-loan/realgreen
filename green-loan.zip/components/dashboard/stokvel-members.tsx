"use client"

import { useState, useEffect, useCallback } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  Star,
  Calendar,
  DollarSign,
  User,
  CreditCard,
  Clock,
  ArrowRight,
  ChevronLeft,
  ChevronRight,
} from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"

// Mock data for stokvel members with enhanced details
const stokvelMembers = [
  {
    id: 1,
    name: "John Doe",
    position: 1,
    accountName: "John Doe",
    accountNumber: "1234567890",
    bank: "First National Bank",
    contributionAmount: "R 500",
    totalContributed: "R 3,000",
    nextContribution: "2023-06-15",
    payoutDate: "2023-07-01",
    payoutAmount: "R 6,000",
    status: "current",
    paymentSpeed: 5, // 5 stars - very quick
    isCurrentRecipient: true,
  },
  {
    id: 2,
    name: "Jane Smith",
    position: 2,
    accountName: "Jane Smith",
    accountNumber: "2345678901",
    bank: "Standard Bank",
    contributionAmount: "R 500",
    totalContributed: "R 3,000",
    nextContribution: "2023-06-15",
    payoutDate: "2023-08-01",
    payoutAmount: "R 6,000",
    status: "current",
    paymentSpeed: 4, // 4 stars - quick
    isCurrentRecipient: false,
  },
  {
    id: 3,
    name: "Michael Johnson",
    position: 3,
    accountName: "Michael Johnson",
    accountNumber: "3456789012",
    bank: "Nedbank",
    contributionAmount: "R 500",
    totalContributed: "R 3,000",
    nextContribution: "2023-06-15",
    payoutDate: "2023-09-01",
    payoutAmount: "R 6,000",
    status: "current",
    paymentSpeed: 5, // 5 stars - very quick
    isCurrentRecipient: false,
  },
  {
    id: 4,
    name: "Sarah Williams",
    position: 4,
    accountName: "Sarah Williams",
    accountNumber: "4567890123",
    bank: "ABSA",
    contributionAmount: "R 500",
    totalContributed: "R 2,500",
    nextContribution: "2023-06-15",
    payoutDate: "2023-10-01",
    payoutAmount: "R 6,000",
    status: "late",
    paymentSpeed: 2, // 2 stars - slow
    isCurrentRecipient: false,
  },
  {
    id: 5,
    name: "David Brown",
    position: 5,
    accountName: "David Brown",
    accountNumber: "5678901234",
    bank: "Capitec",
    contributionAmount: "R 500",
    totalContributed: "R 3,000",
    nextContribution: "2023-06-15",
    payoutDate: "2023-11-01",
    payoutAmount: "R 6,000",
    status: "current",
    paymentSpeed: 3, // 3 stars - average
    isCurrentRecipient: false,
  },
  {
    id: 6,
    name: "Emily Davis",
    position: 6,
    accountName: "Emily Davis",
    accountNumber: "6789012345",
    bank: "Discovery Bank",
    contributionAmount: "R 500",
    totalContributed: "R 3,000",
    nextContribution: "2023-06-15",
    payoutDate: "2023-12-01",
    payoutAmount: "R 6,000",
    status: "current",
    paymentSpeed: 4, // 4 stars - quick
    isCurrentRecipient: false,
  },
]

// Mock data for stokvel details
const stokvelDetails = {
  name: "Green Finance Stokvel",
  members: 12,
  totalFunds: "R 12,500",
  monthlyContribution: "R 500",
  nextPayout: "2023-07-01",
  cycleProgress: 65,
}

export function StokvelMembers() {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [isPaused, setIsPaused] = useState(false)

  // Function to handle next slide
  const nextSlide = useCallback(() => {
    setCurrentIndex((prevIndex) => (prevIndex === stokvelMembers.length - 1 ? 0 : prevIndex + 1))
  }, [])

  // Function to handle previous slide
  const prevSlide = useCallback(() => {
    setCurrentIndex((prevIndex) => (prevIndex === 0 ? stokvelMembers.length - 1 : prevIndex - 1))
  }, [])

  // Auto-rotate effect
  useEffect(() => {
    if (!isPaused) {
      const interval = setInterval(() => {
        nextSlide()
      }, 5000) // Change slide every 5 seconds

      return () => clearInterval(interval)
    }
  }, [isPaused, nextSlide])

  // Function to render stars based on payment speed
  const renderStars = (speed: number) => {
    return Array(5)
      .fill(0)
      .map((_, i) => (
        <Star key={i} className={cn("h-4 w-4", i < speed ? "text-yellow-400 fill-yellow-400" : "text-gray-300")} />
      ))
  }

  // Calculate visible indices for the carousel
  const getVisibleIndices = () => {
    const indices = []
    // Show 3 cards on desktop, 1 on mobile
    const numVisible = typeof window !== "undefined" && window.innerWidth >= 768 ? 3 : 1

    for (let i = 0; i < numVisible; i++) {
      const index = (currentIndex + i) % stokvelMembers.length
      indices.push(index)
    }

    return indices
  }

  return (
    <div className="space-y-8">
      <Card>
        <CardHeader>
          <CardTitle>Stokvel Overview</CardTitle>
          <CardDescription>Your rotating savings club details</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            <div>
              <h3 className="text-sm font-medium">Stokvel Name</h3>
              <p className="text-lg font-bold">{stokvelDetails.name}</p>
            </div>
            <div>
              <h3 className="text-sm font-medium">Total Members</h3>
              <p className="text-lg font-bold">{stokvelDetails.members}</p>
            </div>
            <div>
              <h3 className="text-sm font-medium">Total Funds</h3>
              <p className="text-lg font-bold">{stokvelDetails.totalFunds}</p>
            </div>
            <div>
              <h3 className="text-sm font-medium">Monthly Contribution</h3>
              <p className="text-lg font-bold">{stokvelDetails.monthlyContribution}</p>
            </div>
            <div>
              <h3 className="text-sm font-medium">Next Payout</h3>
              <p className="text-lg font-bold">{stokvelDetails.nextPayout}</p>
            </div>
            <div>
              <h3 className="text-sm font-medium">Cycle Progress</h3>
              <div className="mt-2">
                <Progress value={stokvelDetails.cycleProgress} className="h-2" />
                <p className="mt-1 text-xs text-muted-foreground">
                  {stokvelDetails.cycleProgress}% through current cycle
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Member Rotation</CardTitle>
          <CardDescription>Current rotation order and payout schedule</CardDescription>
        </CardHeader>
        <CardContent>
          <div
            className="relative overflow-hidden py-4"
            onMouseEnter={() => setIsPaused(true)}
            onMouseLeave={() => setIsPaused(false)}
          >
            {/* Carousel navigation */}
            <div className="absolute top-1/2 left-0 z-10 -translate-y-1/2">
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 rounded-full bg-background/80 backdrop-blur-sm"
                onClick={prevSlide}
                aria-label="Previous member"
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
            </div>
            <div className="absolute top-1/2 right-0 z-10 -translate-y-1/2">
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 rounded-full bg-background/80 backdrop-blur-sm"
                onClick={nextSlide}
                aria-label="Next member"
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>

            {/* Carousel indicators */}
            <div className="absolute bottom-2 left-0 right-0 z-10 flex justify-center gap-1">
              {stokvelMembers.map((_, index) => (
                <button
                  key={index}
                  className={cn(
                    "h-1.5 rounded-full transition-all",
                    currentIndex === index ? "w-6 bg-primary" : "w-1.5 bg-primary/30",
                  )}
                  onClick={() => setCurrentIndex(index)}
                  aria-label={`Go to slide ${index + 1}`}
                />
              ))}
            </div>

            {/* Carousel content */}
            <div className="relative h-[500px] mx-auto max-w-4xl">
              <AnimatePresence initial={false} mode="wait">
                {stokvelMembers.map((member, index) => (
                  <motion.div
                    key={member.id}
                    className={cn(
                      "absolute top-0 left-0 right-0 mx-auto w-full max-w-md",
                      index !== currentIndex && "pointer-events-none",
                    )}
                    initial={{ opacity: 0, x: index > currentIndex ? 100 : -100 }}
                    animate={{
                      opacity: index === currentIndex ? 1 : 0,
                      x: index === currentIndex ? 0 : index > currentIndex ? 100 : -100,
                      scale: index === currentIndex ? 1 : 0.9,
                    }}
                    exit={{ opacity: 0, x: index < currentIndex ? -100 : 100 }}
                    transition={{ duration: 0.5 }}
                  >
                    <Card
                      className={cn(
                        "h-full border-2",
                        member.isCurrentRecipient
                          ? "border-green-500 bg-green-50 dark:bg-green-900/20"
                          : member.status === "late"
                            ? "border-red-300 bg-red-50 dark:bg-red-900/20"
                            : "border-gray-200 dark:border-gray-800",
                      )}
                    >
                      <CardHeader className="relative pb-2">
                        <div className="absolute top-4 right-4">
                          <Badge
                            variant={
                              member.isCurrentRecipient
                                ? "success"
                                : member.status === "late"
                                  ? "destructive"
                                  : "outline"
                            }
                            className="rounded-full px-3"
                          >
                            {member.isCurrentRecipient
                              ? "Current Recipient"
                              : member.status === "late"
                                ? "Payment Late"
                                : `Position ${member.position}`}
                          </Badge>
                        </div>
                        <CardTitle className="flex items-center gap-2">
                          <span className="flex items-center justify-center w-8 h-8 rounded-full bg-primary text-primary-foreground">
                            {member.position}
                          </span>
                          {member.name}
                        </CardTitle>
                        <CardDescription>
                          <div className="flex items-center gap-1 mt-1">{renderStars(member.paymentSpeed)}</div>
                        </CardDescription>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="grid grid-cols-2 gap-3">
                          <div className="space-y-1">
                            <p className="text-xs text-muted-foreground flex items-center">
                              <DollarSign className="h-3 w-3 mr-1" />
                              Monthly Contribution
                            </p>
                            <p className="font-medium">{member.contributionAmount}</p>
                          </div>
                          <div className="space-y-1">
                            <p className="text-xs text-muted-foreground flex items-center">
                              <DollarSign className="h-3 w-3 mr-1" />
                              Total Contributed
                            </p>
                            <p className="font-medium">{member.totalContributed}</p>
                          </div>
                        </div>

                        <div className="space-y-1">
                          <p className="text-xs text-muted-foreground flex items-center">
                            <Calendar className="h-3 w-3 mr-1" />
                            Payout Date
                          </p>
                          <p className="font-medium">{member.payoutDate}</p>
                        </div>

                        <div className="space-y-1">
                          <p className="text-xs text-muted-foreground flex items-center">
                            <DollarSign className="h-3 w-3 mr-1" />
                            Payout Amount
                          </p>
                          <p className="text-lg font-bold">{member.payoutAmount}</p>
                        </div>

                        <div className="pt-2 border-t">
                          <p className="text-xs font-medium mb-2">Banking Details</p>
                          <div className="space-y-2">
                            <div className="flex items-start gap-2">
                              <User className="h-3 w-3 mt-0.5 text-muted-foreground" />
                              <div>
                                <p className="text-xs text-muted-foreground">Account Name</p>
                                <p className="text-sm">{member.accountName}</p>
                              </div>
                            </div>
                            <div className="flex items-start gap-2">
                              <CreditCard className="h-3 w-3 mt-0.5 text-muted-foreground" />
                              <div>
                                <p className="text-xs text-muted-foreground">Account Number</p>
                                <p className="text-sm">{member.accountNumber}</p>
                              </div>
                            </div>
                            <div className="flex items-start gap-2">
                              <Clock className="h-3 w-3 mt-0.5 text-muted-foreground" />
                              <div>
                                <p className="text-xs text-muted-foreground">Bank</p>
                                <p className="text-sm">{member.bank}</p>
                              </div>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                      <CardFooter className="pt-0">
                        {member.isCurrentRecipient && (
                          <Badge className="w-full justify-center py-2 bg-green-500 hover:bg-green-600">
                            Current Payment Due
                          </Badge>
                        )}
                        {!member.isCurrentRecipient && member.position === 2 && (
                          <Badge variant="outline" className="w-full justify-center py-2">
                            Next in Rotation <ArrowRight className="ml-2 h-3 w-3" />
                          </Badge>
                        )}
                      </CardFooter>
                    </Card>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

