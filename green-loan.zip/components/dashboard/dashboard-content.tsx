"use client"

import { useState } from "react"
import { createClient } from "@/utils/supabase/client"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

export default function DashboardContent({ profile }: { profile: any }) {
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const supabase = createClient()

  // Handle sign out
  const handleSignOut = async () => {
    setLoading(true)
    try {
      const { error } = await supabase.auth.signOut()
      if (error) throw error
      // The middleware will handle the redirect to login
    } catch (error) {
      console.error("Error signing out:", error)
      setError("Failed to sign out. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Dashboard</h1>
        <Button onClick={handleSignOut} disabled={loading} variant="outline">
          {loading ? "Signing out..." : "Sign out"}
        </Button>
      </div>

      {error && <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">{error}</div>}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Welcome, {profile?.full_name || "User"}</CardTitle>
          </CardHeader>
          <CardContent>
            <p>Email: {profile?.email || "Not available"}</p>
            {/* Add more profile information as needed */}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Green Loan Status</CardTitle>
          </CardHeader>
          <CardContent>
            <p>Your application status: {profile?.loan_status || "Not started"}</p>
            {/* Add more loan information as needed */}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

