"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import {
  LayoutDashboard,
  CreditCard,
  BarChart3,
  Users,
  Calendar,
  Settings,
  MessageSquare,
  Inbox,
  FileText,
  ChevronDown,
  Landmark,
  PiggyBank,
  Wallet,
} from "lucide-react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"

export default function DashboardSidebar() {
  const pathname = usePathname()
  const [openMenus, setOpenMenus] = useState({
    dashboard: true,
    financial: false,
  })

  const toggleMenu = (menu) => {
    setOpenMenus((prev) => ({
      ...prev,
      [menu]: !prev[menu],
    }))
  }

  const NavItem = ({ href, icon: Icon, children, isSubmenu = false }) => {
    const isActive = pathname === href

    return (
      <Link href={href} passHref>
        <Button
          variant="ghost"
          className={cn(
            "w-full justify-start gap-2 font-normal",
            isActive ? "bg-primary/10 text-primary font-medium" : "text-muted-foreground",
            isSubmenu && "pl-10",
          )}
        >
          {Icon && <Icon className="h-4 w-4" />}
          <span>{children}</span>
        </Button>
      </Link>
    )
  }

  return (
    <div className="w-64 border-r border-border bg-background hidden md:flex flex-col h-screen">
      <div className="h-16 flex items-center px-4 border-b border-border">
        <Link href="/dashboard" className="flex items-center gap-2">
          <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center">
            <Landmark className="h-4 w-4 text-primary-foreground" />
          </div>
          <span className="font-bold text-xl">Green Fina</span>
        </Link>
      </div>

      <div className="flex-1 overflow-y-auto py-4 px-3">
        <div className="mb-2">
          <p className="text-xs font-semibold text-muted-foreground mb-2 px-4">MAIN MENU</p>

          <div>
            <Button
              variant="ghost"
              className="w-full justify-start gap-2 font-normal mb-1"
              onClick={() => toggleMenu("dashboard")}
            >
              <LayoutDashboard className="h-4 w-4" />
              <span className="flex-1 text-left">Dashboard</span>
              <ChevronDown className={cn("h-4 w-4 transition-transform", openMenus.dashboard && "rotate-180")} />
            </Button>

            {openMenus.dashboard && (
              <div className="ml-2 space-y-1 mb-2">
                <NavItem href="/dashboard" icon={LayoutDashboard} isSubmenu>
                  Overview
                </NavItem>
                <NavItem href="/dashboard/analytics" icon={BarChart3} isSubmenu>
                  Analytics
                </NavItem>
              </div>
            )}
          </div>

          <NavItem href="/dashboard/stokvela" icon={PiggyBank}>
            Stokvela
          </NavItem>
          <NavItem href="/dashboard/loans" icon={CreditCard}>
            Loans
          </NavItem>
          <NavItem href="/dashboard/payments" icon={Wallet}>
            Payments
          </NavItem>
          <NavItem href="/dashboard/users" icon={Users}>
            Users
          </NavItem>
          <NavItem href="/dashboard/calendar" icon={Calendar}>
            Calendar
          </NavItem>
        </div>

        <div className="mb-2 mt-6">
          <p className="text-xs font-semibold text-muted-foreground mb-2 px-4">SUPPORT</p>
          <NavItem href="/dashboard/messages" icon={MessageSquare}>
            Messages
          </NavItem>
          <NavItem href="/dashboard/inbox" icon={Inbox}>
            Inbox
          </NavItem>
          <NavItem href="/dashboard/reports" icon={FileText}>
            Reports
          </NavItem>
          <NavItem href="/dashboard/settings" icon={Settings}>
            Settings
          </NavItem>
        </div>
      </div>
    </div>
  )
}

