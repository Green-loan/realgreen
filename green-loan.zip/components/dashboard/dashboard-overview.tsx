"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { LoanApplications } from "@/components/dashboard/loan-applications"
import { StokvelMembers } from "@/components/dashboard/stokvel-members"
import { Investments } from "@/components/dashboard/investments"

export function DashboardOverview() {
  // No authentication checks here, just render the dashboard
  return (
    <Tabs defaultValue="overview" className="space-y-4">
      <TabsList>
        <TabsTrigger value="overview">Overview</TabsTrigger>
        <TabsTrigger value="loans">Loans</TabsTrigger>
        <TabsTrigger value="stokvel">Stokvel</TabsTrigger>
        <TabsTrigger value="investments">Investments</TabsTrigger>
      </TabsList>
      <TabsContent value="overview" className="space-y-4">
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Loans</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">2</div>
              <p className="text-xs text-muted-foreground">+10% from last month</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Stokvel Balance</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">R 12,500</div>
              <p className="text-xs text-muted-foreground">Next payout: 15 June</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Green Investments</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">R 45,200</div>
              <p className="text-xs text-muted-foreground">+5.2% return rate</p>
            </CardContent>
          </Card>
        </div>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          <Card className="col-span-2">
            <CardHeader>
              <CardTitle>Recent Activity</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center">
                  <div className="ml-4 space-y-1">
                    <p className="text-sm font-medium leading-none">Loan payment processed</p>
                    <p className="text-sm text-muted-foreground">R 1,200 • 2 days ago</p>
                  </div>
                </div>
                <div className="flex items-center">
                  <div className="ml-4 space-y-1">
                    <p className="text-sm font-medium leading-none">Stokvel contribution received</p>
                    <p className="text-sm text-muted-foreground">R 500 • 5 days ago</p>
                  </div>
                </div>
                <div className="flex items-center">
                  <div className="ml-4 space-y-1">
                    <p className="text-sm font-medium leading-none">Investment dividend paid</p>
                    <p className="text-sm text-muted-foreground">R 320 • 1 week ago</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle>Upcoming Payments</CardTitle>
              <CardDescription>Your scheduled payments for this month</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-1">
                    <p className="text-sm font-medium leading-none">Loan Payment</p>
                    <p className="text-sm text-muted-foreground">Due in 5 days</p>
                  </div>
                  <div className="font-medium">R 1,200</div>
                </div>
                <div className="flex items-center justify-between">
                  <div className="space-y-1">
                    <p className="text-sm font-medium leading-none">Stokvel Contribution</p>
                    <p className="text-sm text-muted-foreground">Due in 12 days</p>
                  </div>
                  <div className="font-medium">R 500</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </TabsContent>
      <TabsContent value="loans" className="space-y-4">
        <LoanApplications />
      </TabsContent>
      <TabsContent value="stokvel" className="space-y-4">
        <StokvelMembers />
      </TabsContent>
      <TabsContent value="investments" className="space-y-4">
        <Investments />
      </TabsContent>
    </Tabs>
  )
}

