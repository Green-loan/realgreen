"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { Menu } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { DashboardSidebar } from "@/components/dashboard/sidebar"
import { ThemeToggle } from "@/components/theme-toggle"
import { NotificationsDropdown } from "@/components/dashboard/notifications-dropdown"
import { UserNav } from "@/components/user-nav" // Updated import path

export function DashboardHeader() {
  const pathname = usePathname()
  const isAdmin = pathname?.includes("/admin")

  return (
    <header className="fixed top-0 z-40 w-full border-b bg-background">
      <div className="flex h-14 items-center px-4 md:px-6">
        <Sheet>
          <SheetTrigger asChild>
            <Button variant="outline" size="icon" className="mr-4 md:hidden">
              <Menu className="h-5 w-5" />
              <span className="sr-only">Toggle Menu</span>
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="w-72 p-0">
            <DashboardSidebar />
          </SheetContent>
        </Sheet>
        <Link href="/" className="flex items-center gap-2">
          <span className="text-lg font-bold">
            Green<span className="text-primary">Fina</span>
          </span>
        </Link>
        <div className="ml-auto flex items-center gap-2">
          <NotificationsDropdown />
          <ThemeToggle />
          <UserNav />
        </div>
      </div>
    </header>
  )
}

