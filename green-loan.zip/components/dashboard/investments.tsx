"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"

// Mock data for investments
const investments = [
  {
    id: 1,
    name: "Solar Energy Fund",
    amount: "R 15,000",
    returnRate: "6.2%",
    startDate: "2022-10-15",
    term: "3 years",
    status: "active",
    progress: 42,
  },
  {
    id: 2,
    name: "Green Bond Portfolio",
    amount: "R 20,000",
    returnRate: "5.5%",
    startDate: "2023-01-10",
    term: "5 years",
    status: "active",
    progress: 25,
  },
  {
    id: 3,
    name: "Sustainable Agriculture ETF",
    amount: "R 10,200",
    returnRate: "4.8%",
    startDate: "2023-03-22",
    term: "2 years",
    status: "active",
    progress: 15,
  },
]

// Mock data for investment summary
const investmentSummary = {
  totalInvested: "R 45,200",
  totalReturn: "R 2,350",
  averageReturnRate: "5.2%",
  projectedAnnualReturn: "R 2,800",
}

export function Investments() {
  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>Investment Summary</CardTitle>
          <CardDescription>Your green investment portfolio overview</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <div>
              <h3 className="text-sm font-medium">Total Invested</h3>
              <p className="text-lg font-bold">{investmentSummary.totalInvested}</p>
            </div>
            <div>
              <h3 className="text-sm font-medium">Total Return</h3>
              <p className="text-lg font-bold">{investmentSummary.totalReturn}</p>
            </div>
            <div>
              <h3 className="text-sm font-medium">Average Return Rate</h3>
              <p className="text-lg font-bold">{investmentSummary.averageReturnRate}</p>
            </div>
            <div>
              <h3 className="text-sm font-medium">Projected Annual Return</h3>
              <p className="text-lg font-bold">{investmentSummary.projectedAnnualReturn}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Your Green Investments</CardTitle>
          <CardDescription>Details of your sustainable investment portfolio</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Investment</TableHead>
                <TableHead>Amount</TableHead>
                <TableHead>Return Rate</TableHead>
                <TableHead>Start Date</TableHead>
                <TableHead>Term</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Progress</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {investments.map((investment) => (
                <TableRow key={investment.id}>
                  <TableCell className="font-medium">{investment.name}</TableCell>
                  <TableCell>{investment.amount}</TableCell>
                  <TableCell>{investment.returnRate}</TableCell>
                  <TableCell>{investment.startDate}</TableCell>
                  <TableCell>{investment.term}</TableCell>
                  <TableCell>
                    <Badge
                      variant={
                        investment.status === "active"
                          ? "success"
                          : investment.status === "pending"
                            ? "outline"
                            : "default"
                      }
                    >
                      {investment.status}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="w-[100px]">
                      <Progress value={investment.progress} className="h-2" />
                      <p className="mt-1 text-xs text-muted-foreground">{investment.progress}% complete</p>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}

