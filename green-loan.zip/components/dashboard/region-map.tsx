"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function RegionMap() {
  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-md font-medium">Region labels</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-[300px] w-full flex items-center justify-center">
          <div className="relative w-full h-full">
            {/* This is a simplified map of South Africa */}
            <svg viewBox="0 0 500 500" className="w-full h-full">
              <path
                d="M100,100 L400,100 L450,250 L400,400 L100,400 L50,250 Z"
                fill="#e2e8f0"
                stroke="#94a3b8"
                strokeWidth="2"
              />

              {/* Add some province markers */}
              <circle cx="250" cy="150" r="10" fill="hsl(var(--primary))" opacity="0.7" />
              <circle cx="350" cy="200" r="8" fill="hsl(var(--primary))" opacity="0.5" />
              <circle cx="150" cy="250" r="12" fill="hsl(var(--primary))" opacity="0.8" />
              <circle cx="300" cy="300" r="7" fill="hsl(var(--primary))" opacity="0.4" />
              <circle cx="200" cy="350" r="9" fill="hsl(var(--primary))" opacity="0.6" />

              {/* Province labels */}
              <text x="250" y="130" fontSize="10" textAnchor="middle" fill="currentColor">
                Gauteng
              </text>
              <text x="350" y="180" fontSize="10" textAnchor="middle" fill="currentColor">
                Mpumalanga
              </text>
              <text x="150" y="230" fontSize="10" textAnchor="middle" fill="currentColor">
                Western Cape
              </text>
              <text x="300" y="280" fontSize="10" textAnchor="middle" fill="currentColor">
                KwaZulu-Natal
              </text>
              <text x="200" y="330" fontSize="10" textAnchor="middle" fill="currentColor">
                Eastern Cape
              </text>
            </svg>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

