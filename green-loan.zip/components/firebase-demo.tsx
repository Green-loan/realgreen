"use client"

import { useState } from "react"
import { db, rtdb } from "@/lib/firebase"
import { collection, getDocs, addDoc } from "firebase/firestore"
import { ref, set, onValue } from "firebase/database"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

export default function FirebaseDemo() {
  const [firestoreStatus, setFirestoreStatus] = useState<string>("Not tested")
  const [realtimeStatus, setRealtimeStatus] = useState<string>("Not tested")
  const [loading, setLoading] = useState<boolean>(false)

  // Test Firestore connection
  const testFirestore = async () => {
    if (!db) {
      setFirestoreStatus("Firestore not initialized")
      return
    }

    setLoading(true)
    try {
      const testCollection = collection(db, "test_collection")
      await addDoc(testCollection, {
        message: "Test connection",
        timestamp: new Date().toISOString(),
      })

      const querySnapshot = await getDocs(testCollection)
      const docsCount = querySnapshot.size

      setFirestoreStatus(`Connected! Found ${docsCount} documents.`)
    } catch (error) {
      console.error("Firestore test error:", error)
      setFirestoreStatus(`Error: ${error instanceof Error ? error.message : "Unknown error"}`)
    } finally {
      setLoading(false)
    }
  }

  // Test Realtime Database connection
  const testRealtimeDB = async () => {
    if (!rtdb) {
      setRealtimeStatus("Realtime Database not initialized")
      return
    }

    setLoading(true)
    try {
      const testRef = ref(rtdb, "test")
      await set(testRef, {
        message: "Test connection",
        timestamp: new Date().toISOString(),
      })

      onValue(
        testRef,
        (snapshot) => {
          const data = snapshot.val()
          setRealtimeStatus(`Connected! Data: ${JSON.stringify(data)}`)
        },
        {
          onlyOnce: true,
        },
      )
    } catch (error) {
      console.error("Realtime DB test error:", error)
      setRealtimeStatus(`Error: ${error instanceof Error ? error.message : "Unknown error"}`)
    } finally {
      setLoading(false)
    }
  }

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle>Firebase Connection Test</CardTitle>
        <CardDescription>Test your Firebase connection</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <h3 className="font-medium">Firestore Status:</h3>
          <p
            className={`text-sm ${firestoreStatus.includes("Error") ? "text-red-500" : firestoreStatus.includes("Connected") ? "text-green-500" : "text-gray-500"}`}
          >
            {firestoreStatus}
          </p>
        </div>
        <div>
          <h3 className="font-medium">Realtime Database Status:</h3>
          <p
            className={`text-sm ${realtimeStatus.includes("Error") ? "text-red-500" : realtimeStatus.includes("Connected") ? "text-green-500" : "text-gray-500"}`}
          >
            {realtimeStatus}
          </p>
        </div>
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button onClick={testFirestore} disabled={loading}>
          Test Firestore
        </Button>
        <Button onClick={testRealtimeDB} disabled={loading}>
          Test Realtime DB
        </Button>
      </CardFooter>
    </Card>
  )
}

