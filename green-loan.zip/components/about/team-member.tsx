"use client"

import { motion } from "framer-motion"
import { Linkedin, Twitter, Mail } from "lucide-react"

interface TeamMemberProps {
  name: string
  role: string
  bio: string
  image: string
  delay?: number
}

export function TeamMember({ name, role, bio, image, delay = 0 }: TeamMemberProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay }}
      whileHover={{ y: -5 }}
      className="bg-background/50 backdrop-blur-sm border border-border/50 rounded-xl overflow-hidden hover:border-teal-500/30 transition-all duration-300"
    >
      <div className="relative">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent to-background/80" />
        <img src={image || "/placeholder.svg"} alt={name} className="w-full aspect-square object-cover" />
      </div>

      <div className="p-6">
        <h3 className="text-xl font-semibold mb-1">{name}</h3>
        <p className="text-teal-500 mb-3">{role}</p>
        <p className="text-foreground/70 mb-4">{bio}</p>

        <div className="flex space-x-3">
          <motion.a
            href="#"
            className="w-8 h-8 rounded-full bg-foreground/5 flex items-center justify-center text-foreground/60 hover:bg-teal-500/20 hover:text-teal-500 transition-colors"
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.95 }}
          >
            <Linkedin size={16} />
          </motion.a>
          <motion.a
            href="#"
            className="w-8 h-8 rounded-full bg-foreground/5 flex items-center justify-center text-foreground/60 hover:bg-teal-500/20 hover:text-teal-500 transition-colors"
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.95 }}
          >
            <Twitter size={16} />
          </motion.a>
          <motion.a
            href="#"
            className="w-8 h-8 rounded-full bg-foreground/5 flex items-center justify-center text-foreground/60 hover:bg-teal-500/20 hover:text-teal-500 transition-colors"
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.95 }}
          >
            <Mail size={16} />
          </motion.a>
        </div>
      </div>
    </motion.div>
  )
}

