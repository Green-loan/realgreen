"use client"

import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Loader2 } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"
import { useSupabase } from "@/components/supabase-provider"
import { useRouter } from "next/navigation"

interface VerificationCodePopupProps {
  isOpen: boolean
  onClose: () => void
  email: string
}

export function VerificationCodePopup({ isOpen, onClose, email }: VerificationCodePopupProps) {
  const [verificationCode, setVerificationCode] = useState("")
  const [isVerifying, setIsVerifying] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [timeLeft, setTimeLeft] = useState(60)
  const { supabase } = useSupabase()
  const { toast } = useToast()
  const router = useRouter()

  useEffect(() => {
    let timer: NodeJS.Timeout
    if (isOpen && timeLeft > 0) {
      timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000)
    }
    return () => {
      if (timer) clearTimeout(timer)
    }
  }, [timeLeft, isOpen])

  const handleVerify = async () => {
    if (!verificationCode || verificationCode.length !== 6) {
      setError("Please enter a valid 6-digit verification code")
      return
    }

    setIsVerifying(true)
    setError(null)

    try {
      if (!supabase) {
        throw new Error("Authentication service is not available")
      }

      // Verify the OTP code with Supabase
      const { error } = await supabase.auth.verifyOtp({
        email,
        token: verificationCode,
        type: "email",
      })

      if (error) {
        throw error
      }

      toast({
        title: "Email verified!",
        description: "Your account has been verified successfully.",
      })

      // Close the popup and redirect to dashboard
      onClose()
      router.push("/dashboard")
    } catch (error: any) {
      console.error("Verification error:", error)
      setError(error.message || "Failed to verify your email. Please try again.")
    } finally {
      setIsVerifying(false)
    }
  }

  const handleResendCode = async () => {
    try {
      if (!supabase) {
        throw new Error("Authentication service is not available")
      }

      const { error } = await supabase.auth.resend({
        type: "signup",
        email,
      })

      if (error) {
        throw error
      }

      toast({
        title: "Verification code resent",
        description: "Please check your email for the new verification code.",
      })

      // Reset the timer
      setTimeLeft(60)
    } catch (error: any) {
      console.error("Resend error:", error)
      toast({
        variant: "destructive",
        title: "Failed to resend code",
        description: error.message || "Please try again later.",
      })
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-center text-xl">Email Verification</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div className="text-center text-sm text-muted-foreground">
            We've sent a verification code to <span className="font-medium text-foreground">{email}</span>. Please enter
            the 6-digit code below to verify your account.
          </div>
          <div className="space-y-2">
            <Input
              type="text"
              placeholder="6-digit code"
              value={verificationCode}
              onChange={(e) => {
                // Only allow numbers and max 6 digits
                const value = e.target.value.replace(/[^0-9]/g, "").slice(0, 6)
                setVerificationCode(value)
              }}
              className="text-center text-lg tracking-widest"
              maxLength={6}
            />
            {error && <p className="text-sm text-red-500">{error}</p>}
          </div>
          <Button
            onClick={handleVerify}
            className="w-full bg-gradient-to-r from-teal-500 to-blue-600 hover:from-teal-600 hover:to-blue-700"
            disabled={isVerifying}
          >
            {isVerifying ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Verifying...
              </>
            ) : (
              "Verify Email"
            )}
          </Button>
          <div className="text-center">
            <p className="text-sm text-muted-foreground">
              Didn't receive a code?{" "}
              {timeLeft > 0 ? (
                <span>Resend in {timeLeft}s</span>
              ) : (
                <button onClick={handleResendCode} className="text-primary hover:underline focus:outline-none">
                  Resend Code
                </button>
              )}
            </p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}

