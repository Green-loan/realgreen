"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Eye, EyeOff, Loader2 } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useSupabase } from "@/components/supabase-provider"
import { VerificationCodePopup } from "@/components/auth/verification-code-popup"

export function RegistrationForm() {
  const router = useRouter()
  const { supabase } = useSupabase()
  const { toast } = useToast()
  const [loading, setLoading] = useState(false)
  const [showPassword, setShowPassword] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [showVerification, setShowVerification] = useState(false)
  const [verificationEmail, setVerificationEmail] = useState("")
  const [debugInfo, setDebugInfo] = useState<any>(null)

  const [formData, setFormData] = useState({
    email: "",
    password: "",
    fullName: "",
    phone: "",
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    })
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)
    setDebugInfo(null)

    try {
      // Validate inputs
      if (!formData.email || !formData.password || !formData.fullName) {
        throw new Error("Please fill in all required fields")
      }

      if (formData.password.length < 6) {
        throw new Error("Password must be at least 6 characters long")
      }

      if (!supabase) {
        throw new Error("Authentication service is not available")
      }

      console.log("Starting registration process...")

      // Register with Supabase
      const { data, error: signUpError } = await supabase.auth.signUp({
        email: formData.email,
        password: formData.password,
        options: {
          data: {
            full_name: formData.fullName,
            phone: formData.phone || "",
            role_id: 1, // Set role_id to 1 (regular user)
          },
          emailRedirectTo: `${window.location.origin}/auth/callback`,
        },
      })

      if (signUpError) {
        console.error("Signup error:", signUpError)
        throw signUpError
      }

      console.log("Auth signup successful:", data)

      // Create or update user record
      if (data?.user) {
        try {
          console.log("Creating user record...")
          const { data: userData, error: userError } = await supabase.from("users").upsert(
            {
              id: data.user.id,
              full_name: formData.fullName,
              email: formData.email,
              phone: formData.phone || "",
              role_id: 1, // Set role_id to 1 (regular user)
              updated_at: new Date().toISOString(),
            },
            { onConflict: "id", returning: "minimal" },
          )

          if (userError) {
            console.error("User record creation failed:", userError)
            setDebugInfo({ type: "user_error", error: userError })
          } else {
            console.log("User record created successfully")
          }
        } catch (userErr) {
          console.error("User record creation error:", userErr)
          setDebugInfo({ type: "user_exception", error: userErr })
        }
      }

      // Show success message
      toast({
        title: "Registration successful!",
        description: "Please check your email for verification instructions.",
      })

      // Open verification popup
      setVerificationEmail(formData.email)
      setShowVerification(true)

      // Clear form
      setFormData({
        email: "",
        password: "",
        fullName: "",
        phone: "",
      })
    } catch (err: any) {
      console.error("Registration error:", err)
      setError(err.message || "An error occurred during registration")
      setDebugInfo({ type: "general_error", error: err })

      toast({
        variant: "destructive",
        title: "Registration failed",
        description: err.message || "An error occurred during registration",
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="fullName">Full Name</Label>
          <Input id="fullName" name="fullName" value={formData.fullName} onChange={handleChange} required />
        </div>

        <div className="space-y-2">
          <Label htmlFor="email">Email</Label>
          <Input id="email" name="email" type="email" value={formData.email} onChange={handleChange} required />
        </div>

        <div className="space-y-2">
          <Label htmlFor="phone">Phone Number (Optional)</Label>
          <Input id="phone" name="phone" type="tel" value={formData.phone} onChange={handleChange} />
        </div>

        <div className="space-y-2">
          <Label htmlFor="password">Password</Label>
          <div className="relative">
            <Input
              id="password"
              name="password"
              type={showPassword ? "text" : "password"}
              value={formData.password}
              onChange={handleChange}
              required
              minLength={6}
            />
            <button
              type="button"
              className="absolute right-3 top-1/2 -translate-y-1/2 text-foreground/60"
              onClick={() => setShowPassword(!showPassword)}
            >
              {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
            </button>
          </div>
        </div>

        {error && <div className="text-sm text-red-500 p-2 bg-red-50 border border-red-200 rounded">{error}</div>}

        {debugInfo && (
          <div className="text-xs text-amber-700 p-2 bg-amber-50 border border-amber-200 rounded overflow-auto max-h-32">
            <p>Debug Info:</p>
            <pre>{JSON.stringify(debugInfo, null, 2)}</pre>
          </div>
        )}

        <Button type="submit" className="w-full" disabled={loading}>
          {loading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Creating account...
            </>
          ) : (
            "Sign Up"
          )}
        </Button>
      </form>

      <VerificationCodePopup
        isOpen={showVerification}
        onClose={() => setShowVerification(false)}
        email={verificationEmail}
      />
    </>
  )
}

