"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Loader2 } from "lucide-react"
import { useRouter } from "next/navigation"
import { useSupabase } from "@/components/supabase-provider"

interface AuthModalProps {
  defaultTab?: "signin" | "signup"
  trigger?: React.ReactNode
}

export function AuthModal({ defaultTab = "signin", trigger }: AuthModalProps) {
  const router = useRouter()
  const { supabase } = useSupabase()
  const [open, setOpen] = useState(false)
  const [tab, setTab] = useState<"signin" | "signup">(defaultTab)

  // Sign In state
  const [signinEmail, setSigninEmail] = useState("")
  const [signinPassword, setSigninPassword] = useState("")
  const [signinLoading, setSigninLoading] = useState(false)
  const [signinError, setSigninError] = useState<string | null>(null)

  // Sign Up state
  const [signupEmail, setSignupEmail] = useState("")
  const [signupPassword, setSignupPassword] = useState("")
  const [signupFullName, setSignupFullName] = useState("")
  const [signupLoading, setSignupLoading] = useState(false)
  const [signupError, setSignupError] = useState<string | null>(null)
  const [signupSuccess, setSignupSuccess] = useState<string | null>(null)

  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault()
    setSigninLoading(true)
    setSigninError(null)

    try {
      if (!supabase) throw new Error("Supabase client not initialized")

      const { data, error } = await supabase.auth.signInWithPassword({
        email: signinEmail,
        password: signinPassword,
      })

      if (error) throw error

      // Close modal and redirect
      setOpen(false)
      router.push("/dashboard")
      router.refresh()
    } catch (error: any) {
      console.error("Sign in error:", error)
      setSigninError(error.message || "An error occurred during sign in")
    } finally {
      setSigninLoading(false)
    }
  }

  // Update the handleSignUp function to directly use supabase instead of the API
  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault()
    setSignupLoading(true)
    setSignupError(null)
    setSignupSuccess(null)

    try {
      if (!supabase) throw new Error("Supabase client not initialized")

      // Register the user directly with Supabase Auth
      const { data, error } = await supabase.auth.signUp({
        email: signupEmail,
        password: signupPassword,
        options: {
          data: {
            full_name: signupFullName,
          },
          emailRedirectTo: `${window.location.origin}/auth/callback`,
        },
      })

      if (error) throw error

      // Create a profile in the profiles table
      if (data?.user) {
        try {
          const { error: profileError } = await supabase.from("profiles").insert([
            {
              id: data.user.id,
              full_name: signupFullName,
              email: signupEmail,
              role: "user",
            },
          ])

          if (profileError) {
            console.error("Error creating profile:", profileError)
          }
        } catch (profileError) {
          console.error("Exception during profile creation:", profileError)
        }
      }

      setSignupSuccess("Registration successful! Please check your email to verify your account.")

      // Clear form
      setSignupEmail("")
      setSignupPassword("")
      setSignupFullName("")

      // Switch to sign in tab after successful registration
      setTimeout(() => {
        setTab("signin")
        setSignupSuccess(null)
      }, 3000)
    } catch (error: any) {
      console.error("Registration error:", error)
      setSignupError(error.message || "An error occurred during registration")
    } finally {
      setSignupLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      {trigger ? (
        <DialogTrigger asChild>{trigger}</DialogTrigger>
      ) : (
        <DialogTrigger asChild>
          <Button variant="outline">Sign In</Button>
        </DialogTrigger>
      )}
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Welcome to Green Fina</DialogTitle>
          <DialogDescription>Sign in to your account or create a new one to get started.</DialogDescription>
        </DialogHeader>
        <Tabs value={tab} onValueChange={(value) => setTab(value as "signin" | "signup")} className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="signin">Sign In</TabsTrigger>
            <TabsTrigger value="signup">Sign Up</TabsTrigger>
          </TabsList>
          <TabsContent value="signin" className="mt-4">
            <form onSubmit={handleSignIn} className="space-y-4">
              <div>
                <Label htmlFor="signinEmail">Email</Label>
                <Input
                  id="signinEmail"
                  type="email"
                  value={signinEmail}
                  onChange={(e) => setSigninEmail(e.target.value)}
                  placeholder="you@example.com"
                  required
                />
              </div>
              <div>
                <Label htmlFor="signinPassword">Password</Label>
                <Input
                  id="signinPassword"
                  type="password"
                  value={signinPassword}
                  onChange={(e) => setSigninPassword(e.target.value)}
                  placeholder="••••••••"
                  required
                />
              </div>
              {signinError && <div className="text-sm text-red-500">{signinError}</div>}
              <Button type="submit" className="w-full" disabled={signinLoading}>
                {signinLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Signing In...
                  </>
                ) : (
                  "Sign In"
                )}
              </Button>
              <div className="text-center text-sm">
                <a href="#" className="text-primary hover:underline">
                  Forgot password?
                </a>
              </div>
            </form>
          </TabsContent>
          <TabsContent value="signup" className="mt-4">
            <form onSubmit={handleSignUp} className="space-y-4">
              <div>
                <Label htmlFor="signupFullName">Full Name</Label>
                <Input
                  id="signupFullName"
                  type="text"
                  value={signupFullName}
                  onChange={(e) => setSignupFullName(e.target.value)}
                  placeholder="John Doe"
                />
              </div>
              <div>
                <Label htmlFor="signupEmail">Email</Label>
                <Input
                  id="signupEmail"
                  type="email"
                  value={signupEmail}
                  onChange={(e) => setSignupEmail(e.target.value)}
                  placeholder="you@example.com"
                  required
                />
              </div>
              <div>
                <Label htmlFor="signupPassword">Password</Label>
                <Input
                  id="signupPassword"
                  type="password"
                  value={signupPassword}
                  onChange={(e) => setSignupPassword(e.target.value)}
                  placeholder="••••••••"
                  required
                />
              </div>
              {signupError && <div className="text-sm text-red-500">{signupError}</div>}
              {signupSuccess && <div className="text-sm text-green-500">{signupSuccess}</div>}
              <Button type="submit" className="w-full" disabled={signupLoading}>
                {signupLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Creating Account...
                  </>
                ) : (
                  "Create Account"
                )}
              </Button>
            </form>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  )
}

