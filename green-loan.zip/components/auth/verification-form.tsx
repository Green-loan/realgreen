"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { useToast } from "@/components/ui/use-toast"
import { Loader2 } from "lucide-react"
import { useRouter } from "next/navigation"
import { useSupabaseClient } from "@supabase/auth-helpers-react"

interface VerificationFormProps {
  email: string
}

export function VerificationForm({ email }: VerificationFormProps) {
  const [token, setToken] = useState("")
  const [isVerifying, setIsVerifying] = useState(false)
  const [isResending, setIsResending] = useState(false)
  const { toast } = useToast()
  const router = useRouter()
  const supabase = useSupabaseClient()
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [successMessage, setSuccessMessage] = useState<string | null>(null)
  const [resendError, setResendError] = useState<string | null>(null)
  const [resendSuccess, setResendSuccess] = useState<string | null>(null)

  // Update the verifyEmail function to use Supabase directly
  const verifyToken = async () => {
    setIsLoading(true)
    setError(null)
    setSuccessMessage(null)

    try {
      if (!supabase) throw new Error("Supabase client not initialized")

      // Call the verify_email_token function directly
      const { data, error } = await supabase.rpc("verify_email_token", {
        user_email: email,
        verification_token: token,
      })

      if (error) throw error

      if (data) {
        setSuccessMessage("Email verified successfully! You can now log in.")
        // Redirect to login after 2 seconds
        setTimeout(() => {
          router.push("/login")
        }, 2000)
      } else {
        setError("Invalid or expired verification token.")
      }
    } catch (error: any) {
      console.error("Verification error:", error)
      setError(error.message || "An error occurred during verification.")
    } finally {
      setIsLoading(false)
    }
  }

  // Update the resendToken function to use Supabase directly
  const resendToken = async () => {
    setIsResending(true)
    setResendError(null)
    setResendSuccess(null)

    try {
      if (!supabase) throw new Error("Supabase client not initialized")

      // Call the regenerate_verification_token function directly
      const { data, error } = await supabase.rpc("regenerate_verification_token", {
        user_email: email,
      })

      if (error) throw error

      setResendSuccess("A new verification code has been sent to your email.")
    } catch (error: any) {
      console.error("Resend error:", error)
      setResendError(error.message || "An error occurred while resending the verification code.")
    } finally {
      setIsResending(false)
    }
  }

  const handleVerify = async (e: React.FormEvent) => {
    e.preventDefault()
    verifyToken()
  }

  const handleResend = async () => {
    resendToken()
  }

  return (
    <Card className="border-border/50 bg-background/50 backdrop-blur-sm">
      <CardHeader className="space-y-1">
        <div className="flex justify-center mb-4">
          <div className="w-12 h-12 rounded-full bg-gradient-to-br from-green-400 to-emerald-600 flex items-center justify-center">
            <span className="text-white font-bold text-xl">GL</span>
          </div>
        </div>
        <CardTitle className="text-2xl text-center">Verify Your Email</CardTitle>
        <CardDescription className="text-center">We've sent a 6-digit verification code to {email}</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleVerify} className="space-y-4">
          <div className="grid gap-2">
            <Label htmlFor="token">Verification Code</Label>
            <Input
              id="token"
              name="token"
              placeholder="Enter 6-digit code"
              value={token}
              onChange={(e) => setToken(e.target.value)}
              required
              maxLength={6}
              pattern="[0-9]{6}"
              className="text-center text-lg tracking-widest"
            />
          </div>
          <Button
            type="submit"
            className="w-full bg-gradient-to-r from-green-400 to-emerald-600 hover:from-green-500 hover:to-emerald-700"
            disabled={isLoading || token.length !== 6}
          >
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Verifying...
              </>
            ) : (
              "Verify Email"
            )}
          </Button>
          {error && <p className="text-red-500 text-sm">{error}</p>}
          {successMessage && <p className="text-green-500 text-sm">{successMessage}</p>}
        </form>
      </CardContent>
      <CardFooter className="flex flex-col space-y-4">
        <div className="text-center text-sm text-muted-foreground">
          Didn't receive the code?{" "}
          <Button
            variant="link"
            className="p-0 text-green-500 hover:text-green-600"
            onClick={handleResend}
            disabled={isResending}
          >
            {isResending ? (
              <>
                <Loader2 className="mr-2 h-3 w-3 animate-spin" />
                Resending...
              </>
            ) : (
              "Resend Code"
            )}
          </Button>
          {resendError && <p className="text-red-500 text-sm">{resendError}</p>}
          {resendSuccess && <p className="text-green-500 text-sm">{resendSuccess}</p>}
        </div>
      </CardFooter>
    </Card>
  )
}

