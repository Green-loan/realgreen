"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { createClientComponentClient } from "@supabase/auth-helpers-nextjs"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Icons } from "@/components/icons"

export function RegisterForm() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [fullName, setFullName] = useState("")
  const [phone, setPhone] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [debugInfo, setDebugInfo] = useState<string | null>(null)
  const router = useRouter()
  const supabase = createClientComponentClient()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError(null)
    setDebugInfo(null)

    try {
      // 1. Sign up the user with Supabase Auth
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email,
        password,
        options: {
          emailRedirectTo: `${window.location.origin}/auth/callback`,
          data: {
            full_name: fullName,
          },
        },
      })

      if (authError) {
        setDebugInfo(`Auth Error: ${JSON.stringify(authError)}`)
        throw authError
      }

      if (!authData.user) {
        setDebugInfo("No user returned from auth signup")
        throw new Error("Failed to create user account")
      }

      // Log user ID for debugging
      console.log("User created with ID:", authData.user.id)
      setDebugInfo(`User created with ID: ${authData.user.id}`)

      // 2. Insert user details into the users table with role_id = 1 (regular user)
      const { data: userData, error: userError } = await supabase
        .from("users")
        .insert({
          id: authData.user.id, // Use the auth user ID as the primary key
          full_name: fullName,
          email: email,
          phone: phone,
          role_id: 1, // 1 = regular user
        })
        .select()

      if (userError) {
        setDebugInfo(`User Insert Error: ${JSON.stringify(userError)}`)
        throw userError
      }

      console.log("User profile created:", userData)
      setDebugInfo(`User profile created: ${JSON.stringify(userData)}`)

      // Redirect to dashboard
      router.push("/dashboard")
    } catch (error: any) {
      setError(error.message || "An error occurred during registration")
      console.error("Registration error:", error)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="grid gap-6">
      <form onSubmit={handleSubmit}>
        <div className="grid gap-4">
          <div className="grid gap-2">
            <Label htmlFor="fullName">Full Name</Label>
            <Input
              id="fullName"
              placeholder="John Doe"
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              required
            />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              placeholder="name@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="phone">Phone Number</Label>
            <Input
              id="phone"
              type="tel"
              placeholder="+1234567890"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              required
            />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="password">Password</Label>
            <Input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
          {error && <div className="text-sm text-red-500">{error}</div>}
          {debugInfo && process.env.NODE_ENV !== "production" && (
            <div className="text-xs text-gray-500 bg-gray-100 p-2 rounded overflow-auto max-h-24">{debugInfo}</div>
          )}
          <Button disabled={isLoading} type="submit" className="w-full">
            {isLoading && <Icons.spinner className="mr-2 h-4 w-4 animate-spin" />}
            Register
          </Button>
        </div>
      </form>
    </div>
  )
}

