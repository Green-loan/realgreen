"use client"

import { Home, User, MessageSquare, FileText, LogIn } from "lucide-react"
import { NavBar } from "@/components/ui/tubelight-navbar"
import { useSupabase } from "@/components/supabase-provider"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { ThemeToggle } from "@/components/theme-toggle"
import Image from "next/image"

export function NavBarDemo() {
  const { supabase, user } = useSupabase()
  const router = useRouter()

  const handleSignIn = (e) => {
    e.preventDefault()
    router.push("/auth/signin")
  }

  const navItems = [
    { name: "Features", url: "#features", icon: Home },
    { name: "Testimonials", url: "#testimonials", icon: MessageSquare },
    { name: "Apply Now", url: "/apply", icon: FileText },
    { name: "About Us", url: "/about", icon: User },
  ]

  return (
    <div className="w-full flex items-center justify-between">
      {/* Logo - now even bigger */}
      <Link href="/" className="flex items-center mr-4">
        <Image src="/images/green-logo.png" alt="Green Finance" width={70} height={70} className="mr-2" />
      </Link>

      {/* Navigation */}
      <div className="flex-1 flex justify-center">
        <NavBar items={navItems} className="sm:relative sm:top-0 static" />
      </div>

      {/* Right side items */}
      <div className="flex items-center gap-4">
        <ThemeToggle />

        <button
          onClick={handleSignIn}
          className="flex items-center gap-2 bg-primary text-primary-foreground hover:bg-primary/90 px-4 py-2 rounded-full text-sm font-medium"
        >
          <LogIn size={16} />
          <span className="hidden md:inline">Sign in</span>
        </button>
      </div>
    </div>
  )
}

