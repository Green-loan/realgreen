"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { X, Send, Sparkles, Loader2, Brain } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { cn } from "@/lib/utils"

type Message = {
  id: string
  content: string
  role: "user" | "assistant"
  timestamp: Date
}

export function FinaAssistant() {
  const [isOpen, setIsOpen] = useState(false)
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      content: "Hi there! I'm Fina, your Green Finance AI assistant. How can I help you today?",
      role: "assistant",
      timestamp: new Date(),
    },
  ])
  const [inputValue, setInputValue] = useState("")
  const [isTyping, setIsTyping] = useState(false)
  const [isFloating, setIsFloating] = useState(true)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  // Floating animation effect
  useEffect(() => {
    const interval = setInterval(() => {
      setIsFloating((prev) => !prev)
    }, 2000)

    return () => clearInterval(interval)
  }, [])

  // Scroll to bottom of messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  const handleSendMessage = async (e?: React.FormEvent) => {
    if (e) e.preventDefault()
    if (!inputValue.trim()) return

    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      content: inputValue,
      role: "user",
      timestamp: new Date(),
    }
    setMessages((prev) => [...prev, userMessage])
    setInputValue("")
    setIsTyping(true)

    // Simulate AI response
    setTimeout(() => {
      const responses = [
        "I'd be happy to help you with your green finance questions!",
        "Our sustainable financing options start at just 3.5% APR.",
        "You can apply for a loan of up to R100,000 for your eco-friendly project.",
        "Solar panel installations typically qualify for our best rates.",
        "Would you like me to guide you through the application process?",
        "Our AI verification system can approve your application in minutes.",
        "Feel free to ask any questions about our loan terms or sustainability criteria.",
        "Green Fina offers special rates for first-time eco-entrepreneurs.",
        "I can help you calculate the ROI on your sustainable business idea.",
      ]

      const aiMessage: Message = {
        id: Date.now().toString(),
        content: responses[Math.floor(Math.random() * responses.length)],
        role: "assistant",
        timestamp: new Date(),
      }

      setMessages((prev) => [...prev, aiMessage])
      setIsTyping(false)
    }, 1500)
  }

  return (
    <div className="fixed bottom-6 right-6 z-50">
      <AnimatePresence>
        {isOpen ? (
          <motion.div
            initial={{ opacity: 0, scale: 0.8, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.8, y: 20 }}
            className="mb-4"
          >
            <Card className="w-80 md:w-96 shadow-xl border-green-600/20 overflow-hidden bg-black/90 backdrop-blur-lg text-white">
              <CardHeader className="bg-gradient-to-r from-green-500 to-emerald-600 p-3 flex flex-row justify-between items-center">
                <div className="flex items-center text-white">
                  <div className="relative mr-2">
                    <Brain className="h-5 w-5" />
                    <motion.div
                      className="absolute inset-0 rounded-full bg-white/30"
                      animate={{ scale: [1, 1.2, 1], opacity: [0.7, 0.2, 0.7] }}
                      transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
                    />
                  </div>
                  <h3 className="font-medium">Fina AI Assistant</h3>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setIsOpen(false)}
                  className="text-white hover:bg-white/20"
                >
                  <X className="h-4 w-4" />
                </Button>
              </CardHeader>
              <CardContent className="p-0">
                <div className="h-80 overflow-y-auto p-4 bg-black/80 backdrop-blur-sm">
                  {messages.map((message) => (
                    <div
                      key={message.id}
                      className={cn(
                        "mb-4 max-w-[80%] rounded-lg p-3",
                        message.role === "user"
                          ? "ml-auto bg-green-600 text-white"
                          : "bg-gray-800 border border-green-500/30",
                      )}
                    >
                      <p className="text-sm">{message.content}</p>
                      <p className="mt-1 text-xs opacity-70 text-right">
                        {message.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                      </p>
                    </div>
                  ))}
                  {isTyping && (
                    <div className="mb-4 max-w-[80%] rounded-lg p-3 bg-gray-800 border border-green-500/30">
                      <div className="flex items-center space-x-2">
                        <div className="h-2 w-2 rounded-full bg-green-400 animate-pulse"></div>
                        <div className="h-2 w-2 rounded-full bg-green-400 animate-pulse delay-150"></div>
                        <div className="h-2 w-2 rounded-full bg-green-400 animate-pulse delay-300"></div>
                      </div>
                    </div>
                  )}
                  <div ref={messagesEndRef} />
                </div>
              </CardContent>
              <CardFooter className="p-2 border-t border-green-500/20">
                <form onSubmit={handleSendMessage} className="flex w-full gap-2">
                  <Input
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    placeholder="Ask Fina anything..."
                    className="flex-1 bg-gray-900/50 border-green-600/20 focus:border-green-500/50 text-white"
                  />
                  <Button
                    type="submit"
                    size="icon"
                    disabled={!inputValue.trim() || isTyping}
                    className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700"
                  >
                    {isTyping ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                  </Button>
                </form>
              </CardFooter>
            </Card>
          </motion.div>
        ) : null}
      </AnimatePresence>

      <motion.button
        onClick={() => setIsOpen(!isOpen)}
        className={cn(
          "flex items-center justify-center w-16 h-16 rounded-full shadow-lg",
          "bg-black border-2 border-green-500 text-green-400",
          "focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2",
        )}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        animate={{
          y: isFloating ? -5 : 5,
          boxShadow: isFloating ? "0 0 15px 2px rgba(34, 197, 94, 0.6)" : "0 0 10px 1px rgba(34, 197, 94, 0.3)",
        }}
        transition={{
          y: { duration: 2, repeat: Number.POSITIVE_INFINITY, repeatType: "reverse", ease: "easeInOut" },
          boxShadow: { duration: 2, repeat: Number.POSITIVE_INFINITY, repeatType: "reverse", ease: "easeInOut" },
        }}
      >
        <div className="relative">
          <Sparkles className="h-7 w-7" />
          <motion.div
            className="absolute inset-0 rounded-full"
            animate={{
              boxShadow: [
                "0 0 0 0 rgba(34, 197, 94, 0.7)",
                "0 0 0 10px rgba(34, 197, 94, 0)",
                "0 0 0 0 rgba(34, 197, 94, 0)",
              ],
            }}
            transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
          />
        </div>
      </motion.button>
    </div>
  )
}

