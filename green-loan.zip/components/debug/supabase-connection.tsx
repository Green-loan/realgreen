"use client"

import { useState, useEffect } from "react"
import { useSupabase } from "@/components/supabase-provider"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Loader2, CheckCircle, XCircle } from "lucide-react"

export function SupabaseConnectionDebug() {
  const { supabase } = useSupabase()
  const [loading, setLoading] = useState(true)
  const [authStatus, setAuthStatus] = useState<"success" | "error" | null>(null)
  const [dbStatus, setDbStatus] = useState<"success" | "error" | null>(null)
  const [profilesTableStatus, setProfilesTableStatus] = useState<"exists" | "missing" | "error" | null>(null)
  const [triggerStatus, setTriggerStatus] = useState<"exists" | "missing" | "error" | null>(null)
  const [errorMessage, setErrorMessage] = useState<string | null>(null)

  const checkConnection = async () => {
    setLoading(true)
    setErrorMessage(null)

    try {
      // Check auth connection
      const { data: authData, error: authError } = await supabase.auth.getSession()
      setAuthStatus(authError ? "error" : "success")

      // Check database connection
      const { data: dbData, error: dbError } = await supabase
        .from("_test_connection")
        .select("*")
        .limit(1)
        .catch(() => ({ data: null, error: { message: "Table does not exist, but DB connection works" } }))

      // If we get a specific error about the table not existing, that's actually good
      // because it means we connected to the database
      setDbStatus(dbError && !dbError.message.includes("does not exist") ? "error" : "success")

      // Check if profiles table exists
      const { data: profilesData, error: profilesError } = await supabase.from("profiles").select("id").limit(1)

      if (profilesError) {
        if (profilesError.message.includes("does not exist")) {
          setProfilesTableStatus("missing")
        } else {
          setProfilesTableStatus("error")
          setErrorMessage(`Profiles table error: ${profilesError.message}`)
        }
      } else {
        setProfilesTableStatus("exists")
      }

      // Check if the trigger exists
      const { data: triggerData, error: triggerError } = await supabase
        .rpc("check_trigger_exists", { trigger_name: "on_auth_user_created" })
        .catch(() => ({ data: null, error: { message: "RPC not available" } }))

      if (triggerError) {
        if (triggerError.message.includes('function "check_trigger_exists" does not exist')) {
          // The function doesn't exist, we can't check
          setTriggerStatus("error")
          // But we don't set an error message since this is expected
        } else {
          setTriggerStatus("error")
          setErrorMessage(`Trigger check error: ${triggerError.message}`)
        }
      } else {
        setTriggerStatus(triggerData ? "exists" : "missing")
      }
    } catch (err: any) {
      setErrorMessage(`Connection check failed: ${err.message}`)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    checkConnection()
  }, [])

  return (
    <Card>
      <CardHeader>
        <CardTitle>Supabase Connection Status</CardTitle>
        <CardDescription>Check the connection to your Supabase project</CardDescription>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="flex justify-center py-4">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : (
          <div className="space-y-4">
            <div className="flex items-center justify-between p-2 bg-muted rounded-md">
              <span>Authentication Service</span>
              {authStatus === "success" ? (
                <CheckCircle className="h-5 w-5 text-green-500" />
              ) : authStatus === "error" ? (
                <XCircle className="h-5 w-5 text-red-500" />
              ) : (
                <span className="text-muted-foreground">Not checked</span>
              )}
            </div>

            <div className="flex items-center justify-between p-2 bg-muted rounded-md">
              <span>Database Connection</span>
              {dbStatus === "success" ? (
                <CheckCircle className="h-5 w-5 text-green-500" />
              ) : dbStatus === "error" ? (
                <XCircle className="h-5 w-5 text-red-500" />
              ) : (
                <span className="text-muted-foreground">Not checked</span>
              )}
            </div>

            <div className="flex items-center justify-between p-2 bg-muted rounded-md">
              <span>Profiles Table</span>
              {profilesTableStatus === "exists" ? (
                <CheckCircle className="h-5 w-5 text-green-500" />
              ) : profilesTableStatus === "missing" ? (
                <span className="text-amber-500">Missing</span>
              ) : profilesTableStatus === "error" ? (
                <XCircle className="h-5 w-5 text-red-500" />
              ) : (
                <span className="text-muted-foreground">Not checked</span>
              )}
            </div>

            <div className="flex items-center justify-between p-2 bg-muted rounded-md">
              <span>User Creation Trigger</span>
              {triggerStatus === "exists" ? (
                <CheckCircle className="h-5 w-5 text-green-500" />
              ) : triggerStatus === "missing" ? (
                <span className="text-amber-500">Missing</span>
              ) : triggerStatus === "error" ? (
                <XCircle className="h-5 w-5 text-red-500" />
              ) : (
                <span className="text-muted-foreground">Not checked</span>
              )}
            </div>

            {errorMessage && (
              <div className="p-3 bg-destructive/10 border border-destructive text-destructive rounded-md text-sm">
                {errorMessage}
              </div>
            )}
          </div>
        )}
      </CardContent>
      <CardFooter>
        <Button onClick={checkConnection} disabled={loading} className="w-full">
          {loading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Checking Connection...
            </>
          ) : (
            "Refresh Connection Status"
          )}
        </Button>
      </CardFooter>
    </Card>
  )
}

