"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Loader2 } from "lucide-react"
import { useSupabase } from "@/components/supabase-provider"

export function RegistrationDebugger() {
  const { supabase } = useSupabase()
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [fullName, setFullName] = useState("")
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<any>(null)
  const [error, setError] = useState<string | null>(null)

  const handleDirectSignUp = async () => {
    setLoading(true)
    setError(null)
    setResult(null)

    try {
      if (!supabase) throw new Error("Supabase client not initialized")

      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            full_name: fullName || "",
          },
        },
      })

      if (error) throw error

      setResult({
        message: "Direct signup successful",
        data,
      })
    } catch (error: any) {
      console.error("Direct signup error:", error)
      setError(error.message || "An error occurred during direct signup")
    } finally {
      setLoading(false)
    }
  }

  const handleApiSignUp = async () => {
    setLoading(true)
    setError(null)
    setResult(null)

    try {
      const response = await fetch("/api/auth/register", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email,
          password,
          fullName,
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "API registration failed")
      }

      setResult({
        message: "API signup successful",
        data,
      })
    } catch (error: any) {
      console.error("API signup error:", error)
      setError(error.message || "An error occurred during API signup")
    } finally {
      setLoading(false)
    }
  }

  const handleDebugApi = async () => {
    setLoading(true)
    setError(null)
    setResult(null)

    try {
      const response = await fetch("/api/auth/debug-register", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email,
          password,
          fullName,
        }),
      })

      const data = await response.json()
      setResult({
        message: "Debug API response",
        data,
      })
    } catch (error: any) {
      console.error("Debug API error:", error)
      setError(error.message || "An error occurred during debug API call")
    } finally {
      setLoading(false)
    }
  }

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle>Registration Debugger</CardTitle>
        <CardDescription>Test different registration methods to diagnose issues</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div>
            <Label htmlFor="debugEmail">Email</Label>
            <Input
              id="debugEmail"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="test@example.com"
            />
          </div>
          <div>
            <Label htmlFor="debugPassword">Password</Label>
            <Input
              id="debugPassword"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
            />
          </div>
          <div>
            <Label htmlFor="debugFullName">Full Name</Label>
            <Input
              id="debugFullName"
              type="text"
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              placeholder="Test User"
            />
          </div>

          <div className="flex flex-col gap-2">
            <Button onClick={handleDirectSignUp} disabled={loading} variant="outline">
              {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
              Test Direct Signup
            </Button>
            <Button onClick={handleApiSignUp} disabled={loading} variant="outline">
              {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
              Test API Signup
            </Button>
            <Button onClick={handleDebugApi} disabled={loading} variant="outline">
              {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
              Test Debug API
            </Button>
          </div>

          {error && (
            <div className="p-4 bg-red-500/10 border border-red-500/20 rounded-md text-sm text-red-500">{error}</div>
          )}

          {result && (
            <div className="p-4 bg-green-500/10 border border-green-500/20 rounded-md text-sm">
              <pre className="whitespace-pre-wrap overflow-auto max-h-40">{JSON.stringify(result, null, 2)}</pre>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}

