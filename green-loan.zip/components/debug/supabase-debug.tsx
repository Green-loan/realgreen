"use client"

import { useState } from "react"
import { useSupabase } from "@/components/supabase-provider"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { CheckCircle, XCircle, AlertCircle, Loader2 } from "lucide-react"

export function SupabaseDebug() {
  const { supabase, isLoading, error } = useSupabase()
  const [testResult, setTestResult] = useState<{
    success: boolean
    message: string
    details?: any
  } | null>(null)
  const [isTesting, setIsTesting] = useState(false)

  const testConnection = async () => {
    setIsTesting(true)
    setTestResult(null)

    try {
      if (!supabase) {
        throw new Error("Supabase client is not initialized")
      }

      // Test a simple query to verify connection
      const { data, error: queryError } = await supabase.from("profiles").select("id").limit(1)

      if (queryError) {
        throw queryError
      }

      setTestResult({
        success: true,
        message: "Successfully connected to Supabase",
        details: { data },
      })
    } catch (err: any) {
      console.error("Supabase connection test failed:", err)
      setTestResult({
        success: false,
        message: err.message || "Failed to connect to Supabase",
        details: err,
      })
    } finally {
      setIsTesting(false)
    }
  }

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle>Supabase Connection Diagnostics</CardTitle>
        <CardDescription>Test your connection to Supabase and diagnose any issues</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {isLoading ? (
          <div className="flex items-center space-x-2">
            <Loader2 className="h-4 w-4 animate-spin" />
            <p>Initializing Supabase client...</p>
          </div>
        ) : error ? (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Initialization Error</AlertTitle>
            <AlertDescription>{error.message || "Failed to initialize Supabase client"}</AlertDescription>
          </Alert>
        ) : (
          <Alert variant="default" className="bg-green-50 text-green-800 border-green-200">
            <CheckCircle className="h-4 w-4 text-green-600" />
            <AlertTitle>Supabase Client Initialized</AlertTitle>
            <AlertDescription>The Supabase client has been successfully initialized</AlertDescription>
          </Alert>
        )}

        {testResult && (
          <Alert
            variant={testResult.success ? "default" : "destructive"}
            className={testResult.success ? "bg-green-50 text-green-800 border-green-200" : undefined}
          >
            {testResult.success ? <CheckCircle className="h-4 w-4 text-green-600" /> : <XCircle className="h-4 w-4" />}
            <AlertTitle>{testResult.success ? "Connection Successful" : "Connection Failed"}</AlertTitle>
            <AlertDescription>
              {testResult.message}
              {testResult.details && (
                <pre className="mt-2 p-2 bg-gray-100 rounded text-xs overflow-auto">
                  {JSON.stringify(testResult.details, null, 2)}
                </pre>
              )}
            </AlertDescription>
          </Alert>
        )}
      </CardContent>
      <CardFooter>
        <Button onClick={testConnection} disabled={isLoading || isTesting || !!error}>
          {isTesting ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Testing Connection...
            </>
          ) : (
            "Test Connection"
          )}
        </Button>
      </CardFooter>
    </Card>
  )
}

