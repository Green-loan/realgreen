import { Globe } from "@/components/ui/globe"

export function GlobeDemo() {
  return (
    <section className="py-16 w-full flex justify-center items-center bg-transparent">
      <div className="relative flex flex-col items-center justify-center w-full max-w-4xl mx-auto bg-transparent">
        {/* Removed the heading to make it cleaner */}
        <div className="relative w-full aspect-square max-w-[600px] flex items-center justify-center bg-transparent">
          <Globe />
          {/* Removed the background gradient overlay */}
        </div>
      </div>
    </section>
  )
}

