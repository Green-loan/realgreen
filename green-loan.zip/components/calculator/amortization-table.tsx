"use client"

import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Input } from "@/components/ui/input"
import { useState } from "react"
import { Search } from "lucide-react"

interface AmortizationTableProps {
  schedule: {
    period: number
    payment: number
    principal: number
    interest: number
    totalPrincipal: number
    totalInterest: number
    balance: number
  }[]
}

export function AmortizationTable({ schedule }: AmortizationTableProps) {
  const [searchTerm, setSearchTerm] = useState("")

  // Format currency
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("en-ZA", {
      style: "currency",
      currency: "ZAR",
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(value)
  }

  // Filter schedule based on search term
  const filteredSchedule = schedule.filter((item) => {
    if (!searchTerm) return true

    const term = searchTerm.toLowerCase()
    return (
      item.period.toString().includes(term) ||
      formatCurrency(item.payment).toLowerCase().includes(term) ||
      formatCurrency(item.principal).toLowerCase().includes(term) ||
      formatCurrency(item.interest).toLowerCase().includes(term) ||
      formatCurrency(item.balance).toLowerCase().includes(term)
    )
  })

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-semibold">Amortization Schedule</h2>
        <div className="relative w-64">
          <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-4 w-4 text-foreground/60" />
          <Input
            placeholder="Search payments..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-8"
          />
        </div>
      </div>

      <div className="border rounded-md">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Period</TableHead>
              <TableHead>Payment</TableHead>
              <TableHead>Principal</TableHead>
              <TableHead>Interest</TableHead>
              <TableHead>Balance</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredSchedule.length > 0 ? (
              filteredSchedule.map((item) => (
                <TableRow key={item.period}>
                  <TableCell>{item.period}</TableCell>
                  <TableCell>{formatCurrency(item.payment)}</TableCell>
                  <TableCell>{formatCurrency(item.principal)}</TableCell>
                  <TableCell>{formatCurrency(item.interest)}</TableCell>
                  <TableCell>{formatCurrency(item.balance)}</TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={5} className="text-center py-4">
                  No payments found matching your search.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      <p className="text-sm text-foreground/70">
        Note: This table shows the first year of payments, annual summaries, and the final payment. The full
        amortization schedule would include all monthly payments.
      </p>
    </div>
  )
}

