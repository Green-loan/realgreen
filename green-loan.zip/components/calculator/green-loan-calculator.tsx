"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Slider } from "@/components/ui/slider"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { InfoIcon as InfoCircle } from "lucide-react"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

interface GreenLoanCalculatorProps {
  values: {
    loanAmount: number
    loanTerm: number
    interestRate: number
    projectType: string
  }
  onChange: (values: any) => void
}

export function GreenLoanCalculator({ values, onChange }: GreenLoanCalculatorProps) {
  // Initialize state with props values
  const [loanAmount, setLoanAmount] = useState(values.loanAmount)
  const [loanTerm, setLoanTerm] = useState(values.loanTerm)
  const [interestRate, setInterestRate] = useState(values.interestRate)
  const [projectType, setProjectType] = useState(values.projectType)

  // Add useEffect to sync with prop changes
  useEffect(() => {
    setLoanAmount(values.loanAmount)
    setLoanTerm(values.loanTerm)
    setInterestRate(values.interestRate)
    setProjectType(values.projectType)
  }, [values])

  // Update parent component when values change
  useEffect(() => {
    // Only update parent component if values are different from props
    if (
      loanAmount !== values.loanAmount ||
      loanTerm !== values.loanTerm ||
      interestRate !== values.interestRate ||
      projectType !== values.projectType
    ) {
      onChange({
        loanAmount,
        loanTerm,
        interestRate,
        projectType,
      })
    }
  }, [
    loanAmount,
    loanTerm,
    interestRate,
    projectType,
    values.loanAmount,
    values.loanTerm,
    values.interestRate,
    values.projectType,
  ])

  // Handle loan amount input change
  const handleLoanAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = Number.parseFloat(e.target.value)
    if (!isNaN(value)) {
      setLoanAmount(Math.min(Math.max(value, 1000), 100000))
    }
  }

  // Handle loan amount slider change
  const handleLoanAmountSlider = (value: number[]) => {
    setLoanAmount(value[0])
  }

  // Handle loan term input change
  const handleLoanTermChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = Number.parseInt(e.target.value)
    if (!isNaN(value)) {
      setLoanTerm(Math.min(Math.max(value, 12), 120))
    }
  }

  // Handle loan term slider change
  const handleLoanTermSlider = (value: number[]) => {
    setLoanTerm(value[0])
  }

  // Handle interest rate input change
  const handleInterestRateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = Number.parseFloat(e.target.value)
    if (!isNaN(value)) {
      setInterestRate(Math.min(Math.max(value, 1), 15))
    }
  }

  // Handle interest rate slider change
  const handleInterestRateSlider = (value: number[]) => {
    setInterestRate(value[0])
  }

  // Handle project type change
  const handleProjectTypeChange = (value: string) => {
    setProjectType(value)

    // Set fixed interest rate to 39.99% regardless of project type
    setInterestRate(39.99)
  }

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold">Loan Details</h2>

      <div className="space-y-4">
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <Label htmlFor="projectType">Project Type</Label>
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger>
                  <InfoCircle className="h-4 w-4 text-foreground/60" />
                </TooltipTrigger>
                <TooltipContent>
                  <p className="max-w-xs">Different project types may qualify for different interest rates.</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
          <Select value={projectType} onValueChange={handleProjectTypeChange}>
            <SelectTrigger id="projectType">
              <SelectValue placeholder="Select project type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="solar">Solar Installation</SelectItem>
              <SelectItem value="ev">Electric Vehicle</SelectItem>
              <SelectItem value="energy-efficiency">Energy Efficiency Upgrade</SelectItem>
              <SelectItem value="sustainable-business">Sustainable Business</SelectItem>
              <SelectItem value="other">Other Green Project</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <Label htmlFor="loanAmount">Loan Amount: R{loanAmount.toLocaleString()}</Label>
            <span className="text-xs text-foreground/60">R1,000 - R100,000</span>
          </div>
          <div className="flex items-center gap-4">
            <Slider
              id="loanAmount"
              min={1000}
              max={100000}
              step={1000}
              value={[loanAmount]}
              onValueChange={handleLoanAmountSlider}
            />
            <Input
              type="number"
              value={loanAmount}
              onChange={handleLoanAmountChange}
              min={1000}
              max={100000}
              className="w-24"
            />
          </div>
        </div>

        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <Label htmlFor="loanTerm">Loan Term: {loanTerm} months</Label>
            <span className="text-xs text-foreground/60">12 - 120 months</span>
          </div>
          <div className="flex items-center gap-4">
            <Slider
              id="loanTerm"
              min={12}
              max={120}
              step={12}
              value={[loanTerm]}
              onValueChange={handleLoanTermSlider}
            />
            <Input
              type="number"
              value={loanTerm}
              onChange={handleLoanTermChange}
              min={12}
              max={120}
              step={12}
              className="w-24"
            />
          </div>
          <div className="flex justify-between text-xs text-foreground/60 px-2">
            <span>1 year</span>
            <span>5 years</span>
            <span>10 years</span>
          </div>
        </div>

        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <Label htmlFor="interestRate">Interest Rate: {interestRate.toFixed(1)}%</Label>
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger>
                  <InfoCircle className="h-4 w-4 text-foreground/60" />
                </TooltipTrigger>
                <TooltipContent>
                  <p className="max-w-xs">Interest rates are fixed based on project type and loan term.</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
          <div className="flex items-center gap-4">
            <Slider
              id="interestRate"
              min={3.3}
              max={15}
              step={0.1}
              value={[interestRate]}
              onValueChange={handleInterestRateSlider}
              disabled={true}
            />
            <Input
              type="number"
              value={interestRate}
              onChange={handleInterestRateChange}
              min={3.3}
              max={15}
              step={0.1}
              className="w-24"
              disabled={true}
            />
          </div>
        </div>
      </div>

      <div className="bg-teal-500/10 p-4 rounded-lg border border-teal-500/20">
        <h3 className="font-medium text-sm mb-2">Important Information</h3>
        <p className="text-sm text-foreground/70">
          All our green loans have a fixed interest rate of 39.99%. The total interest you'll pay over the loan term is
          R{Math.round(loanAmount * (interestRate / 100) * (loanTerm / 12)).toLocaleString()}.
        </p>
      </div>
    </div>
  )
}

