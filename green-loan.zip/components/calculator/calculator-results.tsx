"use client"

import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from "recharts"
import { Card, CardContent } from "@/components/ui/card"
import { motion } from "framer-motion"

interface CalculatorResultsProps {
  loanAmount: number
  monthlyPayment: number
  totalInterest: number
  totalCost: number
  loanTerm: number
}

export function CalculatorResults({
  loanAmount,
  monthlyPayment,
  totalInterest,
  totalCost,
  loanTerm,
}: CalculatorResultsProps) {
  // Data for the pie chart
  const data = [
    { name: "Principal", value: loanAmount },
    { name: "Interest", value: totalInterest },
  ]

  // Colors for the pie chart
  const COLORS = ["#0ea5e9", "#14b8a6"]

  // Format currency
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("en-ZA", {
      style: "currency",
      currency: "ZAR",
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(value)
  }

  // Custom tooltip for the pie chart
  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-background/95 border border-border p-2 rounded-md shadow-md">
          <p className="font-medium">{payload[0].name}</p>
          <p className="text-sm">{formatCurrency(payload[0].value)}</p>
          <p className="text-xs text-foreground/70">{Math.round((payload[0].value / totalCost) * 100)}% of total</p>
        </div>
      )
    }
    return null
  }

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold">Loan Summary</h2>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }}>
          <Card className="bg-gradient-to-br from-blue-500/10 to-blue-600/5 border-blue-500/20">
            <CardContent className="p-4 text-center">
              <h3 className="text-sm font-medium text-foreground/70 mb-1">Monthly Payment</h3>
              <p className="text-2xl font-bold text-blue-500">{formatCurrency(monthlyPayment)}</p>
              <p className="text-xs text-foreground/60 mt-1">For {loanTerm} months</p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.1 }}
        >
          <Card className="bg-gradient-to-br from-teal-500/10 to-teal-600/5 border-teal-500/20">
            <CardContent className="p-4 text-center">
              <h3 className="text-sm font-medium text-foreground/70 mb-1">Total Interest</h3>
              <p className="text-2xl font-bold text-teal-500">{formatCurrency(totalInterest)}</p>
              <p className="text-xs text-foreground/60 mt-1">
                {Math.round((totalInterest / totalCost) * 100)}% of total payment
              </p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.2 }}
        >
          <Card className="bg-gradient-to-br from-purple-500/10 to-purple-600/5 border-purple-500/20">
            <CardContent className="p-4 text-center">
              <h3 className="text-sm font-medium text-foreground/70 mb-1">Total Cost</h3>
              <p className="text-2xl font-bold text-purple-500">{formatCurrency(totalCost)}</p>
              <p className="text-xs text-foreground/60 mt-1">Principal + Interest</p>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      <div className="mt-6">
        <h3 className="text-lg font-medium mb-4">Payment Breakdown</h3>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={data}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={80}
                paddingAngle={5}
                dataKey="value"
                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                labelLine={false}
              >
                {data.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip content={<CustomTooltip />} />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4 text-sm">
        <div>
          <p className="text-foreground/70">Loan Amount:</p>
          <p className="font-medium">{formatCurrency(loanAmount)}</p>
        </div>
        <div>
          <p className="text-foreground/70">Loan Term:</p>
          <p className="font-medium">
            {loanTerm} months ({Math.round((loanTerm / 12) * 10) / 10} years)
          </p>
        </div>
        <div>
          <p className="text-foreground/70">Total Principal:</p>
          <p className="font-medium">{formatCurrency(loanAmount)}</p>
        </div>
        <div>
          <p className="text-foreground/70">Total Interest:</p>
          <p className="font-medium">{formatCurrency(totalInterest)}</p>
        </div>
      </div>
    </div>
  )
}

