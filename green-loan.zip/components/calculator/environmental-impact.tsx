"use client"

import { useState, useEffect } from "react"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts"
import { motion } from "framer-motion"
import { Leaf, Zap, Droplets, Car } from "lucide-react"

interface EnvironmentalImpactProps {
  loanAmount: number
  projectType: string
}

export function EnvironmentalImpact({ loanAmount, projectType }: EnvironmentalImpactProps) {
  const [impactData, setImpactData] = useState<any[]>([])
  const [impactSummary, setImpactSummary] = useState({
    co2Reduction: 0,
    energySaved: 0,
    waterSaved: 0,
    fuelSaved: 0,
  })

  // Calculate environmental impact based on loan amount and project type
  useEffect(() => {
    // Calculate impact metrics
    let co2Reduction = 0
    let energySaved = 0
    let waterSaved = 0
    let fuelSaved = 0

    // Different calculations based on project type
    switch (projectType) {
      case "solar":
        // Approximate values for solar installations
        co2Reduction = loanAmount * 0.04 // kg CO2 per dollar
        energySaved = loanAmount * 0.15 // kWh per dollar
        waterSaved = loanAmount * 0.02 // gallons per dollar
        break
      case "ev":
        // Approximate values for electric vehicles
        co2Reduction = loanAmount * 0.03 // kg CO2 per dollar
        fuelSaved = loanAmount * 0.01 // gallons per dollar
        break
      case "energy-efficiency":
        // Approximate values for energy efficiency upgrades
        co2Reduction = loanAmount * 0.025 // kg CO2 per dollar
        energySaved = loanAmount * 0.2 // kWh per dollar
        waterSaved = loanAmount * 0.03 // gallons per dollar
        break
      case "sustainable-business":
        // Approximate values for sustainable business projects
        co2Reduction = loanAmount * 0.035 // kg CO2 per dollar
        energySaved = loanAmount * 0.1 // kWh per dollar
        waterSaved = loanAmount * 0.025 // gallons per dollar
        fuelSaved = loanAmount * 0.005 // gallons per dollar
        break
      default:
        // Default values for other green projects
        co2Reduction = loanAmount * 0.02 // kg CO2 per dollar
        energySaved = loanAmount * 0.08 // kWh per dollar
        waterSaved = loanAmount * 0.015 // gallons per dollar
        fuelSaved = loanAmount * 0.003 // gallons per dollar
    }

    // Update impact summary
    setImpactSummary({
      co2Reduction,
      energySaved,
      waterSaved,
      fuelSaved,
    })

    // Generate yearly impact data for chart (5 years)
    const yearlyData = []
    for (let i = 1; i <= 5; i++) {
      yearlyData.push({
        year: `Year ${i}`,
        "CO₂ Reduction": Math.round(co2Reduction * i),
        "Energy Saved": Math.round(energySaved * i),
        "Water Saved": Math.round(waterSaved * i),
        "Fuel Saved": Math.round(fuelSaved * i),
      })
    }

    setImpactData(yearlyData)
  }, [loanAmount, projectType])

  // Format large numbers with commas
  const formatNumber = (num: number) => {
    return new Intl.NumberFormat("en-US").format(Math.round(num))
  }

  // Custom tooltip for the chart
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-background/95 border border-border p-3 rounded-md shadow-md">
          <p className="font-medium mb-2">{label}</p>
          {payload.map((entry: any, index: number) => (
            <p key={`item-${index}`} className="text-sm" style={{ color: entry.color }}>
              {entry.name}: {formatNumber(entry.value)} {getUnit(entry.name)}
            </p>
          ))}
        </div>
      )
    }
    return null
  }

  // Get unit for each impact metric
  const getUnit = (metric: string) => {
    switch (metric) {
      case "CO₂ Reduction":
        return "kg"
      case "Energy Saved":
        return "kWh"
      case "Water Saved":
        return "gallons"
      case "Fuel Saved":
        return "gallons"
      default:
        return ""
    }
  }

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold">Environmental Impact</h2>
      <p className="text-sm text-foreground/70 mb-4">
        Estimate the positive environmental impact your green project will have over time.
      </p>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          className="bg-green-500/10 p-4 rounded-lg border border-green-500/20"
        >
          <div className="flex items-center mb-2">
            <Leaf className="h-5 w-5 text-green-500 mr-2" />
            <h3 className="font-medium">CO₂ Reduction</h3>
          </div>
          <p className="text-2xl font-bold">{formatNumber(impactSummary.co2Reduction)} kg</p>
          <p className="text-xs text-foreground/60 mt-1">
            Equivalent to planting {formatNumber(impactSummary.co2Reduction / 20)} trees
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.1 }}
          className="bg-blue-500/10 p-4 rounded-lg border border-blue-500/20"
        >
          <div className="flex items-center mb-2">
            <Zap className="h-5 w-5 text-blue-500 mr-2" />
            <h3 className="font-medium">Energy Saved</h3>
          </div>
          <p className="text-2xl font-bold">{formatNumber(impactSummary.energySaved)} kWh</p>
          <p className="text-xs text-foreground/60 mt-1">
            Enough to power {formatNumber(impactSummary.energySaved / 30)} homes for a month
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.2 }}
          className="bg-cyan-500/10 p-4 rounded-lg border border-cyan-500/20"
        >
          <div className="flex items-center mb-2">
            <Droplets className="h-5 w-5 text-cyan-500 mr-2" />
            <h3 className="font-medium">Water Saved</h3>
          </div>
          <p className="text-2xl font-bold">{formatNumber(impactSummary.waterSaved)} gal</p>
          <p className="text-xs text-foreground/60 mt-1">
            Equivalent to {formatNumber(impactSummary.waterSaved / 50)} full bathtubs
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.3 }}
          className="bg-amber-500/10 p-4 rounded-lg border border-amber-500/20"
        >
          <div className="flex items-center mb-2">
            <Car className="h-5 w-5 text-amber-500 mr-2" />
            <h3 className="font-medium">Fuel Saved</h3>
          </div>
          <p className="text-2xl font-bold">{formatNumber(impactSummary.fuelSaved)} gal</p>
          <p className="text-xs text-foreground/60 mt-1">
            Equivalent to {formatNumber(impactSummary.fuelSaved * 25)} miles not driven
          </p>
        </motion.div>
      </div>

      <div className="mt-6">
        <h3 className="text-lg font-medium mb-4">5-Year Impact Projection</h3>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={impactData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="year" />
              <YAxis />
              <Tooltip content={<CustomTooltip />} />
              <Legend />
              <Bar dataKey="CO₂ Reduction" fill="#22c55e" />
              <Bar dataKey="Energy Saved" fill="#3b82f6" />
              <Bar dataKey="Water Saved" fill="#06b6d4" />
              <Bar dataKey="Fuel Saved" fill="#f59e0b" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="bg-teal-500/10 p-4 rounded-lg border border-teal-500/20 mt-4">
        <p className="text-sm text-foreground/70">
          <span className="font-medium">Note:</span> These environmental impact estimates are based on industry averages
          and may vary based on specific project details, location, and implementation.
        </p>
      </div>
    </div>
  )
}

