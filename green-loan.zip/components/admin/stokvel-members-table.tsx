"use client"

import { useState } from "react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ArrowUpDown, MoreHorizontal, Edit, Trash, ArrowUp, ArrowDown, Plus } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"

type StokvelMember = {
  id: number
  name: string
  email: string
  phone: string
  position_number: number
  total_contribution: number
  last_payment_date: string
  last_payment_amount: number
  payout_status: "pending" | "completed"
  next_payout_date: string | null
  notes: string
  created_at: string
}

interface StokvelMembersTableProps {
  members: StokvelMember[]
}

export function StokvelMembersTable({ members: initialMembers }: StokvelMembersTableProps) {
  const [members, setMembers] = useState<StokvelMember[]>(initialMembers)
  const [editingMember, setEditingMember] = useState<StokvelMember | null>(null)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [isAddPaymentDialogOpen, setIsAddPaymentDialogOpen] = useState(false)
  const [newPayment, setNewPayment] = useState({ amount: 500, date: new Date().toISOString().split("T")[0] })
  const [isPositionDialogOpen, setIsPositionDialogOpen] = useState(false)
  const [newPosition, setNewPosition] = useState<number | null>(null)

  // Function to handle position changes
  const changePosition = (memberId: number, newPosition: number) => {
    // Find the member to change
    const memberToChange = members.find((m) => m.id === memberId)
    if (!memberToChange) return

    // Get the old position
    const oldPosition = memberToChange.position_number

    // Update all affected members
    const updatedMembers = members.map((member) => {
      // The member we're changing
      if (member.id === memberId) {
        return { ...member, position_number: newPosition }
      }

      // If moving up (to a lower position number)
      if (newPosition < oldPosition) {
        if (member.position_number >= newPosition && member.position_number < oldPosition) {
          return { ...member, position_number: member.position_number + 1 }
        }
      }

      // If moving down (to a higher position number)
      if (newPosition > oldPosition) {
        if (member.position_number <= newPosition && member.position_number > oldPosition) {
          return { ...member, position_number: member.position_number - 1 }
        }
      }

      return member
    })

    // Sort by position and update state
    setMembers(updatedMembers.sort((a, b) => a.position_number - b.position_number))
    setIsPositionDialogOpen(false)
    setNewPosition(null)
  }

  // Function to rotate all positions
  const rotatePositions = () => {
    const maxPosition = members.length

    const updatedMembers = members.map((member) => {
      const newPosition = member.position_number === maxPosition ? 1 : member.position_number + 1
      return { ...member, position_number: newPosition }
    })

    setMembers(updatedMembers.sort((a, b) => a.position_number - b.position_number))
  }

  // Function to move a member up or down one position
  const movePosition = (memberId: number, direction: "up" | "down") => {
    const memberIndex = members.findIndex((m) => m.id === memberId)
    if (memberIndex === -1) return

    const member = members[memberIndex]
    const currentPosition = member.position_number

    // Can't move up if already at position 1
    if (direction === "up" && currentPosition === 1) return

    // Can't move down if already at last position
    if (direction === "down" && currentPosition === members.length) return

    const newPosition = direction === "up" ? currentPosition - 1 : currentPosition + 1

    // Find the member in the target position
    const targetMember = members.find((m) => m.position_number === newPosition)
    if (!targetMember) return

    // Swap positions
    const updatedMembers = members.map((m) => {
      if (m.id === memberId) {
        return { ...m, position_number: newPosition }
      }
      if (m.id === targetMember.id) {
        return { ...m, position_number: currentPosition }
      }
      return m
    })

    setMembers(updatedMembers.sort((a, b) => a.position_number - b.position_number))
  }

  // Function to add a payment
  const addPayment = () => {
    if (!editingMember) return

    const updatedMembers = members.map((member) => {
      if (member.id === editingMember.id) {
        return {
          ...member,
          last_payment_date: newPayment.date,
          last_payment_amount: newPayment.amount,
          total_contribution: member.total_contribution + newPayment.amount,
        }
      }
      return member
    })

    setMembers(updatedMembers)
    setIsAddPaymentDialogOpen(false)
    setNewPayment({ amount: 500, date: new Date().toISOString().split("T")[0] })
  }

  // Function to update member details
  const updateMember = (updatedMember: StokvelMember) => {
    const updatedMembers = members.map((member) => (member.id === updatedMember.id ? updatedMember : member))

    setMembers(updatedMembers)
    setIsEditDialogOpen(false)
    setEditingMember(null)
  }

  return (
    <div className="space-y-4">
      <div className="rounded-md border border-green-500/20 overflow-hidden">
        <Table>
          <TableHeader className="bg-green-500/5">
            <TableRow>
              <TableHead className="w-16 text-center">Position</TableHead>
              <TableHead>Member</TableHead>
              <TableHead>Contact</TableHead>
              <TableHead className="text-right">Total Contribution</TableHead>
              <TableHead>Last Payment</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {members.map((member) => (
              <TableRow key={member.id} className="hover:bg-green-500/5">
                <TableCell className="text-center font-medium">
                  <div className="flex flex-col items-center">
                    <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary mb-1">
                      <span className="text-xs font-bold text-primary-foreground">{member.position_number}</span>
                    </div>
                    <div className="flex space-x-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-5 w-5 rounded-full"
                        onClick={() => movePosition(member.id, "up")}
                        disabled={member.position_number === 1}
                      >
                        <ArrowUp className="h-3 w-3" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-5 w-5 rounded-full"
                        onClick={() => movePosition(member.id, "down")}
                        disabled={member.position_number === members.length}
                      >
                        <ArrowDown className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                </TableCell>
                <TableCell>
                  <div className="font-medium">{member.name}</div>
                  <div className="text-sm text-muted-foreground">
                    Member since {new Date(member.created_at).toLocaleDateString()}
                  </div>
                </TableCell>
                <TableCell>
                  <div>{member.email}</div>
                  <div className="text-sm text-muted-foreground">{member.phone}</div>
                </TableCell>
                <TableCell className="text-right font-medium">R{member.total_contribution.toLocaleString()}</TableCell>
                <TableCell>
                  <div>R{member.last_payment_amount}</div>
                  <div className="text-sm text-muted-foreground">
                    {new Date(member.last_payment_date).toLocaleDateString()}
                  </div>
                </TableCell>
                <TableCell>
                  {member.payout_status === "completed" ? (
                    <Badge className="bg-green-500/20 text-green-500 hover:bg-green-500/30">Paid Out</Badge>
                  ) : (
                    <Badge variant="outline" className="border-amber-500/20 text-amber-500">
                      Waiting (
                      {member.next_payout_date
                        ? new Date(member.next_payout_date).toLocaleDateString("en-ZA", {
                            month: "short",
                            year: "numeric",
                          })
                        : "TBD"}
                      )
                    </Badge>
                  )}
                </TableCell>
                <TableCell className="text-right">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="bg-background/95 backdrop-blur-sm border-green-500/20">
                      <DropdownMenuItem
                        onClick={() => {
                          setEditingMember(member)
                          setIsAddPaymentDialogOpen(true)
                        }}
                      >
                        <Plus className="mr-2 h-4 w-4" />
                        Add Payment
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        onClick={() => {
                          setEditingMember(member)
                          setNewPosition(member.position_number)
                          setIsPositionDialogOpen(true)
                        }}
                      >
                        <ArrowUpDown className="mr-2 h-4 w-4" />
                        Change Position
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        onClick={() => {
                          setEditingMember(member)
                          setIsEditDialogOpen(true)
                        }}
                      >
                        <Edit className="mr-2 h-4 w-4" />
                        Edit Details
                      </DropdownMenuItem>
                      <DropdownMenuItem>
                        <Trash className="mr-2 h-4 w-4" />
                        Remove
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {/* Edit Member Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="bg-background/95 backdrop-blur-sm border-green-500/20 sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Edit Member Details</DialogTitle>
            <DialogDescription>Update the information for this stokvel member.</DialogDescription>
          </DialogHeader>
          {editingMember && (
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="name" className="text-right">
                  Name
                </Label>
                <Input
                  id="name"
                  value={editingMember.name}
                  onChange={(e) => setEditingMember({ ...editingMember, name: e.target.value })}
                  className="col-span-3"
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="email" className="text-right">
                  Email
                </Label>
                <Input
                  id="email"
                  value={editingMember.email}
                  onChange={(e) => setEditingMember({ ...editingMember, email: e.target.value })}
                  className="col-span-3"
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="phone" className="text-right">
                  Phone
                </Label>
                <Input
                  id="phone"
                  value={editingMember.phone}
                  onChange={(e) => setEditingMember({ ...editingMember, phone: e.target.value })}
                  className="col-span-3"
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="status" className="text-right">
                  Status
                </Label>
                <Select
                  value={editingMember.payout_status}
                  onValueChange={(value) =>
                    setEditingMember({ ...editingMember, payout_status: value as "pending" | "completed" })
                  }
                >
                  <SelectTrigger className="col-span-3">
                    <SelectValue placeholder="Select status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="completed">Paid Out</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="next_payout_date" className="text-right">
                  Next Payout
                </Label>
                <Input
                  id="next_payout_date"
                  type="date"
                  value={editingMember.next_payout_date || ""}
                  onChange={(e) => setEditingMember({ ...editingMember, next_payout_date: e.target.value })}
                  className="col-span-3"
                  disabled={editingMember.payout_status === "completed"}
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="notes" className="text-right">
                  Notes
                </Label>
                <Textarea
                  id="notes"
                  value={editingMember.notes}
                  onChange={(e) => setEditingMember({ ...editingMember, notes: e.target.value })}
                  className="col-span-3"
                />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={() => editingMember && updateMember(editingMember)}>Save Changes</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add Payment Dialog */}
      <Dialog open={isAddPaymentDialogOpen} onOpenChange={setIsAddPaymentDialogOpen}>
        <DialogContent className="bg-background/95 backdrop-blur-sm border-green-500/20 sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Add Payment</DialogTitle>
            <DialogDescription>Record a new payment for {editingMember?.name}.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="payment_amount" className="text-right">
                Amount
              </Label>
              <Input
                id="payment_amount"
                type="number"
                value={newPayment.amount}
                onChange={(e) => setNewPayment({ ...newPayment, amount: Number(e.target.value) })}
                className="col-span-3"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="payment_date" className="text-right">
                Date
              </Label>
              <Input
                id="payment_date"
                type="date"
                value={newPayment.date}
                onChange={(e) => setNewPayment({ ...newPayment, date: e.target.value })}
                className="col-span-3"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddPaymentDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={addPayment}>Record Payment</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Change Position Dialog */}
      <Dialog open={isPositionDialogOpen} onOpenChange={setIsPositionDialogOpen}>
        <DialogContent className="bg-background/95 backdrop-blur-sm border-green-500/20 sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Change Position</DialogTitle>
            <DialogDescription>Update the position number for {editingMember?.name}.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="position_number" className="text-right">
                Position
              </Label>
              <Select value={newPosition?.toString() || ""} onValueChange={(value) => setNewPosition(Number(value))}>
                <SelectTrigger className="col-span-3">
                  <SelectValue placeholder="Select position" />
                </SelectTrigger>
                <SelectContent>
                  {Array.from({ length: members.length }, (_, i) => i + 1).map((position) => (
                    <SelectItem key={position} value={position.toString()}>
                      Position {position}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsPositionDialogOpen(false)}>
              Cancel
            </Button>
            <Button
              onClick={() => editingMember && newPosition && changePosition(editingMember.id, newPosition)}
              disabled={!newPosition || (editingMember && newPosition === editingMember.position_number)}
            >
              Update Position
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

