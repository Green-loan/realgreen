"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Brain,
  Sparkles,
  TrendingUp,
  TrendingDown,
  PieChart,
  LineChart,
  Lightbulb,
  Zap,
  Download,
  AlertTriangle,
} from "lucide-react"
import { FuturisticChart } from "./futuristic-chart"

interface Insight {
  id: number
  metric: string
  value: string
  change: string
  insight: string
}

interface AIInsightsDashboardProps {
  insights: Insight[]
}

export function AIInsightsDashboard({ insights }: AIInsightsDashboardProps) {
  // Mock data for AI insights
  const anomalyData = [
    { date: "2023-01", value: 42, threshold: 45 },
    { date: "2023-02", value: 48, threshold: 45 },
    { date: "2023-03", value: 46, threshold: 45 },
    { date: "2023-04", value: 52, threshold: 45 },
    { date: "2023-05", value: 72, threshold: 45, isAnomaly: true },
    { date: "2023-06", value: 48, threshold: 45 },
  ]

  const predictionData = [
    { month: "Jul", Actual: 110, Predicted: 115 },
    { month: "Aug", Actual: 120, Predicted: 125 },
    { month: "Sep", Actual: 130, Predicted: 135 },
    { month: "Oct", Actual: null, Predicted: 145 },
    { month: "Nov", Actual: null, Predicted: 160 },
    { month: "Dec", Actual: null, Predicted: 175 },
  ]

  const segmentationData = [
    { name: "Solar Panel", value: 42 },
    { name: "EV Charging", value: 28 },
    { name: "Home Insulation", value: 18 },
    { name: "Smart Home", value: 12 },
  ]

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold flex items-center">
            <Brain className="mr-2 h-5 w-5 text-green-500" />
            AI Insights Dashboard
            <Badge variant="outline" className="ml-2 bg-green-500/10 text-green-500 border-green-500/20">
              <Sparkles className="mr-1 h-3 w-3" /> Powered by AI
            </Badge>
          </h2>
          <p className="text-muted-foreground">
            Advanced analytics and intelligent insights for your loan applications
          </p>
        </div>
        <Button variant="outline" className="border-green-500/20 bg-green-500/10 text-green-500 hover:bg-green-500/20">
          <Download className="mr-2 h-4 w-4" />
          Export Insights
        </Button>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        {insights.map((insight, index) => (
          <Card
            key={insight.id}
            className="border border-green-500/20 bg-black/40 backdrop-blur-sm shadow-[0_0_15px_rgba(0,200,100,0.15)] animate-in fade-in duration-500"
            style={{ animationDelay: `${index * 100}ms` }}
          >
            <CardHeader className="pb-2">
              <CardTitle className="text-lg font-bold">{insight.metric}</CardTitle>
              <CardDescription>AI-analyzed performance metric</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div className="text-3xl font-bold">{insight.value}</div>
                <div
                  className={`flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                    insight.change.startsWith("+") ? "bg-green-500/10 text-green-500" : "bg-red-500/10 text-red-500"
                  }`}
                >
                  {insight.change.startsWith("+") ? (
                    <TrendingUp className="mr-1 h-3 w-3" />
                  ) : (
                    <TrendingDown className="mr-1 h-3 w-3" />
                  )}
                  {insight.change}
                </div>
              </div>
              <div className="mt-4 p-3 rounded-lg border border-green-500/20 bg-green-500/5">
                <div className="flex items-start space-x-2">
                  <Lightbulb className="h-4 w-4 text-green-500 mt-0.5" />
                  <p className="text-sm">{insight.insight}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Tabs defaultValue="anomalies" className="space-y-4">
        <TabsList className="bg-black/40 backdrop-blur-sm border border-green-500/20 p-1">
          <TabsTrigger
            value="anomalies"
            className="data-[state=active]:bg-green-500/10 data-[state=active]:text-green-500"
          >
            <Zap className="mr-2 h-4 w-4" />
            Anomaly Detection
          </TabsTrigger>
          <TabsTrigger
            value="predictions"
            className="data-[state=active]:bg-green-500/10 data-[state=active]:text-green-500"
          >
            <LineChart className="mr-2 h-4 w-4" />
            Future Predictions
          </TabsTrigger>
          <TabsTrigger
            value="segmentation"
            className="data-[state=active]:bg-green-500/10 data-[state=active]:text-green-500"
          >
            <PieChart className="mr-2 h-4 w-4" />
            Customer Segmentation
          </TabsTrigger>
        </TabsList>

        <TabsContent value="anomalies">
          <Card className="border border-green-500/20 bg-black/40 backdrop-blur-sm shadow-[0_0_15px_rgba(0,200,100,0.15)]">
            <CardHeader>
              <CardTitle className="text-xl font-bold flex items-center">
                <Zap className="mr-2 h-5 w-5 text-green-500" />
                Anomaly Detection
              </CardTitle>
              <CardDescription>AI has identified unusual patterns in your application data</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                <FuturisticChart
                  type="line"
                  data={anomalyData.map((item) => ({
                    month: item.date.split("-")[1],
                    Applications: item.value,
                    Threshold: item.threshold,
                    ...(item.isAnomaly ? { Anomaly: item.value } : {}),
                  }))}
                />
              </div>

              <div className="mt-6 p-4 rounded-lg border border-amber-500/20 bg-amber-500/5">
                <div className="flex items-start space-x-3">
                  <div className="p-2 rounded-full bg-amber-500/10 text-amber-500">
                    <AlertTriangle className="h-4 w-4" />
                  </div>
                  <div>
                    <h4 className="font-medium">Anomaly Detected in May 2023</h4>
                    <p className="text-sm text-muted-foreground mt-1">
                      There was a 50% increase in application volume, significantly above the expected threshold. This
                      coincided with the launch of the new solar panel incentive program.
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="predictions">
          <Card className="border border-green-500/20 bg-black/40 backdrop-blur-sm shadow-[0_0_15px_rgba(0,200,100,0.15)]">
            <CardHeader>
              <CardTitle className="text-xl font-bold flex items-center">
                <LineChart className="mr-2 h-5 w-5 text-green-500" />
                Future Predictions
              </CardTitle>
              <CardDescription>AI-powered forecast of application trends for the next 3 months</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                <FuturisticChart type="line" data={predictionData} />
              </div>

              <div className="mt-6 p-4 rounded-lg border border-green-500/20 bg-green-500/5">
                <div className="flex items-start space-x-3">
                  <div className="p-2 rounded-full bg-green-500/10 text-green-500">
                    <Lightbulb className="h-4 w-4" />
                  </div>
                  <div>
                    <h4 className="font-medium">Growth Prediction</h4>
                    <p className="text-sm text-muted-foreground mt-1">
                      AI predicts a 59% increase in application volume by December. Recommendation: Prepare additional
                      resources for processing the increased volume.
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="segmentation">
          <Card className="border border-green-500/20 bg-black/40 backdrop-blur-sm shadow-[0_0_15px_rgba(0,200,100,0.15)]">
            <CardHeader>
              <CardTitle className="text-xl font-bold flex items-center">
                <PieChart className="mr-2 h-5 w-5 text-green-500" />
                Customer Segmentation
              </CardTitle>
              <CardDescription>AI-powered analysis of application categories</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                <FuturisticChart
                  type="bar"
                  data={segmentationData.map((item) => ({
                    month: item.name,
                    Applications: item.value,
                  }))}
                />
              </div>

              <div className="mt-6 p-4 rounded-lg border border-green-500/20 bg-green-500/5">
                <div className="flex items-start space-x-3">
                  <div className="p-2 rounded-full bg-green-500/10 text-green-500">
                    <Lightbulb className="h-4 w-4" />
                  </div>
                  <div>
                    <h4 className="font-medium">Segment Analysis</h4>
                    <p className="text-sm text-muted-foreground mt-1">
                      Solar panel loans represent the largest segment at 42%. Recommendation: Develop specialized
                      marketing campaigns for this high-performing segment.
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

