"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { CheckCircle, Clock, FileText, Brain, AlertTriangle, ArrowRight, Bell, Eye, Zap } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

export function ApprovalPipeline() {
  const [notificationSent, setNotificationSent] = useState<Record<string, boolean>>({})

  // Mock data for approval pipeline
  const pipelineStages = [
    {
      id: "document-verification",
      name: "Document Verification",
      description: "AI-powered verification of submitted documents",
      applications: [
        {
          id: 1,
          name: "James Wilson",
          purpose: "Solar Panels",
          amount: 25000,
          progress: 25,
          avatar: "/placeholder.svg?height=40&width=40",
        },
        {
          id: 2,
          name: "Sarah Johnson",
          purpose: "EV Charging",
          amount: 18000,
          progress: 40,
          avatar: "/placeholder.svg?height=40&width=40",
        },
        {
          id: 3,
          name: "Michael Chen",
          purpose: "Home Insulation",
          amount: 12000,
          progress: 60,
          avatar: "/placeholder.svg?height=40&width=40",
        },
      ],
    },
    {
      id: "risk-assessment",
      name: "Risk Assessment",
      description: "AI analysis of application risk factors",
      applications: [
        {
          id: 4,
          name: "Emma Rodriguez",
          purpose: "Solar Panels",
          amount: 30000,
          progress: 65,
          avatar: "/placeholder.svg?height=40&width=40",
        },
        {
          id: 5,
          name: "David Kim",
          purpose: "Smart Home",
          amount: 15000,
          progress: 75,
          avatar: "/placeholder.svg?height=40&width=40",
        },
      ],
    },
    {
      id: "final-review",
      name: "Final Review",
      description: "Final approval decision by loan officers",
      applications: [
        {
          id: 6,
          name: "Olivia Patel",
          purpose: "Solar Panels",
          amount: 22000,
          progress: 85,
          avatar: "/placeholder.svg?height=40&width=40",
        },
      ],
    },
    {
      id: "approved",
      name: "Approved",
      description: "Applications ready for disbursement",
      applications: [
        {
          id: 7,
          name: "William Brown",
          purpose: "EV Charging",
          amount: 20000,
          progress: 100,
          avatar: "/placeholder.svg?height=40&width=40",
        },
        {
          id: 8,
          name: "Jennifer Lee",
          purpose: "Solar Panels",
          amount: 28000,
          progress: 100,
          avatar: "/placeholder.svg?height=40&width=40",
        },
      ],
    },
  ]

  const handleNotify = (applicationId: number) => {
    setNotificationSent((prev) => ({ ...prev, [applicationId]: true }))
    // In a real app, this would trigger an API call to send a notification
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold flex items-center">
            <Clock className="mr-2 h-5 w-5 text-green-500" />
            Approval Pipeline
          </h2>
          <p className="text-muted-foreground">Track applications through the approval process</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {pipelineStages.map((stage, stageIndex) => (
          <Card
            key={stage.id}
            className="border border-green-500/20 bg-black/40 backdrop-blur-sm shadow-[0_0_15px_rgba(0,200,100,0.15)] animate-in fade-in duration-500"
            style={{ animationDelay: `${stageIndex * 100}ms` }}
          >
            <CardHeader className="pb-2">
              <CardTitle className="text-lg font-bold flex items-center">
                {stage.id === "document-verification" && <FileText className="mr-2 h-5 w-5 text-green-500" />}
                {stage.id === "risk-assessment" && <Brain className="mr-2 h-5 w-5 text-green-500" />}
                {stage.id === "final-review" && <AlertTriangle className="mr-2 h-5 w-5 text-green-500" />}
                {stage.id === "approved" && <CheckCircle className="mr-2 h-5 w-5 text-green-500" />}
                {stage.name}
                <Badge className="ml-2 bg-green-500/10 text-green-500 border-green-500/20">
                  {stage.applications.length}
                </Badge>
              </CardTitle>
              <CardDescription>{stage.description}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {stage.applications.map((application, appIndex) => (
                  <div
                    key={application.id}
                    className="p-3 rounded-lg border border-green-500/20 bg-green-500/5 space-y-3 animate-in fade-in duration-300"
                    style={{ animationDelay: `${stageIndex * 100 + appIndex * 50}ms` }}
                  >
                    <div className="flex items-center space-x-3">
                      <Avatar className="h-8 w-8">
                        <AvatarImage src={application.avatar} alt={application.name} />
                        <AvatarFallback>{application.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">{application.name}</p>
                        <p className="text-xs text-muted-foreground truncate">
                          {application.purpose} - ${application.amount.toLocaleString()}
                        </p>
                      </div>
                    </div>

                    <div className="space-y-1">
                      <div className="flex items-center justify-between text-xs">
                        <span>Progress</span>
                        <span>{application.progress}%</span>
                      </div>
                      <Progress
                        value={application.progress}
                        className="h-1.5 bg-gray-800"
                        indicatorClassName={
                          application.progress === 100
                            ? "bg-gradient-to-r from-green-500 to-green-400"
                            : "bg-gradient-to-r from-blue-500 to-green-400"
                        }
                      />
                    </div>

                    <div className="flex items-center justify-between pt-1">
                      <Button variant="outline" size="sm" className="h-8 w-8 p-0">
                        <Eye className="h-4 w-4" />
                        <span className="sr-only">View</span>
                      </Button>

                      {stage.id !== "approved" && (
                        <Button
                          variant="outline"
                          size="sm"
                          className="h-8 px-2 text-xs border-green-500/20 bg-green-500/10 text-green-500 hover:bg-green-500/20"
                        >
                          <ArrowRight className="mr-1 h-3 w-3" />
                          Advance
                        </Button>
                      )}

                      {stage.id === "approved" && (
                        <Button
                          variant="outline"
                          size="sm"
                          className="h-8 px-2 text-xs border-green-500/20 bg-green-500/10 text-green-500 hover:bg-green-500/20"
                          onClick={() => handleNotify(application.id)}
                          disabled={notificationSent[application.id]}
                        >
                          {notificationSent[application.id] ? (
                            <>
                              <CheckCircle className="mr-1 h-3 w-3" />
                              Notified
                            </>
                          ) : (
                            <>
                              <Bell className="mr-1 h-3 w-3" />
                              Notify
                            </>
                          )}
                        </Button>
                      )}
                    </div>
                  </div>
                ))}

                {stage.applications.length === 0 && (
                  <div className="p-4 rounded-lg border border-green-500/20 bg-green-500/5 text-center">
                    <p className="text-sm text-muted-foreground">No applications in this stage</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="border border-green-500/20 bg-black/40 backdrop-blur-sm shadow-[0_0_15px_rgba(0,200,100,0.15)]">
        <CardHeader>
          <CardTitle className="text-xl font-bold flex items-center">
            <Zap className="mr-2 h-5 w-5 text-green-500" />
            AI Process Optimization
          </CardTitle>
          <CardDescription>AI-powered suggestions to improve your approval process</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="p-4 rounded-lg border border-green-500/20 bg-green-500/5">
              <div className="flex items-start space-x-3">
                <div className="p-2 rounded-full bg-green-500/10 text-green-500">
                  <Brain className="h-4 w-4" />
                </div>
                <div>
                  <h4 className="font-medium">Approval Process Bottleneck Detected</h4>
                  <p className="text-sm text-muted-foreground mt-1">
                    AI has detected that document verification is taking 2.5 days on average, which is 40% longer than
                    the target time. Consider adding additional verification resources or implementing automated
                    document analysis.
                  </p>
                  <div className="mt-3">
                    <Button
                      variant="outline"
                      className="border-green-500/20 bg-green-500/10 text-green-500 hover:bg-green-500/20"
                    >
                      <Zap className="mr-2 h-4 w-4" />
                      Apply AI Optimization
                    </Button>
                  </div>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 rounded-lg border border-green-500/20 bg-green-500/5">
                <div className="flex flex-col h-full">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-medium">Average Processing Time</h4>
                    <Badge variant="outline" className="bg-amber-500/10 text-amber-500 border-amber-500/20">
                      <Clock className="mr-1 h-3 w-3" /> 3.2 days
                    </Badge>
                  </div>
                  <p className="text-sm text-muted-foreground flex-1">Target: 2.5 days</p>
                  <div className="mt-2">
                    <Progress value={78} className="h-1.5 bg-gray-800" indicatorClassName="bg-amber-500" />
                  </div>
                </div>
              </div>

              <div className="p-4 rounded-lg border border-green-500/20 bg-green-500/5">
                <div className="flex flex-col h-full">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-medium">Approval Rate</h4>
                    <Badge variant="outline" className="bg-green-500/10 text-green-500 border-green-500/20">
                      <CheckCircle className="mr-1 h-3 w-3" /> 72%
                    </Badge>
                  </div>
                  <p className="text-sm text-muted-foreground flex-1">Target: 70%</p>
                  <div className="mt-2">
                    <Progress value={103} className="h-1.5 bg-gray-800" indicatorClassName="bg-green-500" />
                  </div>
                </div>
              </div>

              <div className="p-4 rounded-lg border border-green-500/20 bg-green-500/5">
                <div className="flex flex-col h-full">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-medium">Customer Satisfaction</h4>
                    <Badge variant="outline" className="bg-green-500/10 text-green-500 border-green-500/20">
                      <CheckCircle className="mr-1 h-3 w-3" /> 92%
                    </Badge>
                  </div>
                  <p className="text-sm text-muted-foreground flex-1">Target: 90%</p>
                  <div className="mt-2">
                    <Progress value={102} className="h-1.5 bg-gray-800" indicatorClassName="bg-green-500" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

