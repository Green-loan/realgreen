"use client"

import { Card, CardContent } from "@/components/ui/card"
import type { LucideIcon } from "lucide-react"
import { cn } from "@/lib/utils"

interface MetricProps {
  title: string
  value: string | number
  change: string
  icon: LucideIcon
  color: "green" | "blue" | "purple" | "amber" | "red"
}

interface FuturisticMetricsGridProps {
  metrics: MetricProps[]
}

export function FuturisticMetricsGrid({ metrics }: FuturisticMetricsGridProps) {
  const getColorClasses = (color: string) => {
    switch (color) {
      case "green":
        return {
          bgGlow: "shadow-[0_0_15px_rgba(0,200,100,0.15)]",
          border: "border-green-500/20",
          iconBg: "bg-green-500/10",
          iconColor: "text-green-500",
          changeBg: "bg-green-500/10",
          changeColor: "text-green-500",
        }
      case "blue":
        return {
          bgGlow: "shadow-[0_0_15px_rgba(0,100,200,0.15)]",
          border: "border-blue-500/20",
          iconBg: "bg-blue-500/10",
          iconColor: "text-blue-500",
          changeBg: "bg-blue-500/10",
          changeColor: "text-blue-500",
        }
      case "purple":
        return {
          bgGlow: "shadow-[0_0_15px_rgba(150,0,200,0.15)]",
          border: "border-purple-500/20",
          iconBg: "bg-purple-500/10",
          iconColor: "text-purple-500",
          changeBg: "bg-purple-500/10",
          changeColor: "text-purple-500",
        }
      case "amber":
        return {
          bgGlow: "shadow-[0_0_15px_rgba(200,150,0,0.15)]",
          border: "border-amber-500/20",
          iconBg: "bg-amber-500/10",
          iconColor: "text-amber-500",
          changeBg: "bg-amber-500/10",
          changeColor: "text-amber-500",
        }
      case "red":
        return {
          bgGlow: "shadow-[0_0_15px_rgba(200,50,50,0.15)]",
          border: "border-red-500/20",
          iconBg: "bg-red-500/10",
          iconColor: "text-red-500",
          changeBg: "bg-red-500/10",
          changeColor: "text-red-500",
        }
      default:
        return {
          bgGlow: "shadow-[0_0_15px_rgba(0,200,100,0.15)]",
          border: "border-green-500/20",
          iconBg: "bg-green-500/10",
          iconColor: "text-green-500",
          changeBg: "bg-green-500/10",
          changeColor: "text-green-500",
        }
    }
  }

  return (
    <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
      {metrics.map((metric, index) => {
        const colors = getColorClasses(metric.color)

        return (
          <Card
            key={index}
            className={cn(
              "border bg-black/40 backdrop-blur-sm overflow-hidden animate-in fade-in duration-500 delay-100",
              colors.border,
              colors.bgGlow,
            )}
            style={{ animationDelay: `${index * 100}ms` }}
          >
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className={cn("p-3 rounded-full", colors.iconBg)}>
                  <metric.icon className={cn("h-5 w-5", colors.iconColor)} />
                </div>
                <div className={cn("px-2 py-1 rounded-full text-xs font-medium", colors.changeBg, colors.changeColor)}>
                  {metric.change}
                </div>
              </div>
              <div className="space-y-1">
                <p className="text-sm font-medium text-muted-foreground">{metric.title}</p>
                <p className="text-2xl font-bold">{metric.value}</p>
              </div>
              <div className="mt-4 h-1 w-full bg-gray-800 rounded-full overflow-hidden">
                <div
                  className={cn(
                    "h-full rounded-full bg-gradient-to-r animate-pulse",
                    metric.color === "green"
                      ? "from-green-500 to-green-400"
                      : metric.color === "blue"
                        ? "from-blue-500 to-blue-400"
                        : metric.color === "purple"
                          ? "from-purple-500 to-purple-400"
                          : metric.color === "amber"
                            ? "from-amber-500 to-amber-400"
                            : "from-red-500 to-red-400",
                  )}
                  style={{ width: `${Math.random() * 40 + 60}%` }}
                />
              </div>
            </CardContent>
          </Card>
        )
      })}
    </div>
  )
}

