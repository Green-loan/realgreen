"use client"

import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts"

const data = [
  { name: "Jan", Revenue: 45000, Target: 40000 },
  { name: "Feb", Revenue: 52000, Target: 50000 },
  { name: "Mar", Revenue: 61000, Target: 60000 },
  { name: "Apr", Revenue: 58000, Target: 70000 },
  { name: "May", Revenue: 75000, Target: 80000 },
  { name: "Jun", Revenue: 90000, Target: 90000 },
]

export function RevenueChart() {
  return (
    <div className="h-[300px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart
          data={data}
          margin={{
            top: 20,
            right: 30,
            left: 20,
            bottom: 5,
          }}
        >
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="name" />
          <YAxis />
          <Tooltip formatter={(value) => `$${value.toLocaleString()}`} />
          <Legend />
          <Line type="monotone" dataKey="Revenue" stroke="#10b981" activeDot={{ r: 8 }} />
          <Line type="monotone" dataKey="Target" stroke="#6366f1" strokeDasharray="5 5" />
        </LineChart>
      </ResponsiveContainer>
    </div>
  )
}

