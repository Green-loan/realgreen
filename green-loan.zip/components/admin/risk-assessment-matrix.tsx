"use client"

import { useState } from "react"
import { Progress } from "@/components/ui/progress"
import { AlertTriangle, CheckCircle, HelpCircle } from "lucide-react"

export function RiskAssessmentMatrix() {
  const [hoveredCell, setHoveredCell] = useState<string | null>(null)

  const riskMatrix = [
    { id: "high-impact-high-prob", impact: "High", probability: "High", color: "bg-red-500", count: 3 },
    { id: "high-impact-med-prob", impact: "High", probability: "Medium", color: "bg-amber-500", count: 7 },
    { id: "high-impact-low-prob", impact: "High", probability: "Low", color: "bg-yellow-500", count: 12 },
    { id: "med-impact-high-prob", impact: "Medium", probability: "High", color: "bg-amber-500", count: 5 },
    { id: "med-impact-med-prob", impact: "Medium", probability: "Medium", color: "bg-yellow-500", count: 18 },
    { id: "med-impact-low-prob", impact: "Medium", probability: "Low", color: "bg-green-500", count: 24 },
    { id: "low-impact-high-prob", impact: "Low", probability: "High", color: "bg-yellow-500", count: 8 },
    { id: "low-impact-med-prob", impact: "Low", probability: "Medium", color: "bg-green-500", count: 15 },
    { id: "low-impact-low-prob", impact: "Low", probability: "Low", color: "bg-green-500", count: 32 },
  ]

  const getCellInfo = (impact: string, probability: string) => {
    return riskMatrix.find((cell) => cell.impact === impact && cell.probability === probability)
  }

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-4 gap-2 text-xs font-medium">
        <div className="col-span-1"></div>
        <div className="text-center">High Probability</div>
        <div className="text-center">Medium Probability</div>
        <div className="text-center">Low Probability</div>

        {/* High Impact Row */}
        <div className="flex items-center">High Impact</div>
        {["High", "Medium", "Low"].map((probability) => {
          const cell = getCellInfo("High", probability)
          return (
            <div
              key={`High-${probability}`}
              className={`p-2 rounded-md flex items-center justify-center ${cell?.color} bg-opacity-20 border border-${cell?.color.replace("bg-", "")} border-opacity-30 cursor-pointer transition-all hover:bg-opacity-30`}
              onMouseEnter={() => setHoveredCell(`High-${probability}`)}
              onMouseLeave={() => setHoveredCell(null)}
            >
              <span className="font-bold">{cell?.count}</span>
            </div>
          )
        })}

        {/* Medium Impact Row */}
        <div className="flex items-center">Medium Impact</div>
        {["High", "Medium", "Low"].map((probability) => {
          const cell = getCellInfo("Medium", probability)
          return (
            <div
              key={`Medium-${probability}`}
              className={`p-2 rounded-md flex items-center justify-center ${cell?.color} bg-opacity-20 border border-${cell?.color.replace("bg-", "")} border-opacity-30 cursor-pointer transition-all hover:bg-opacity-30`}
              onMouseEnter={() => setHoveredCell(`Medium-${probability}`)}
              onMouseLeave={() => setHoveredCell(null)}
            >
              <span className="font-bold">{cell?.count}</span>
            </div>
          )
        })}

        {/* Low Impact Row */}
        <div className="flex items-center">Low Impact</div>
        {["High", "Medium", "Low"].map((probability) => {
          const cell = getCellInfo("Low", probability)
          return (
            <div
              key={`Low-${probability}`}
              className={`p-2 rounded-md flex items-center justify-center ${cell?.color} bg-opacity-20 border border-${cell?.color.replace("bg-", "")} border-opacity-30 cursor-pointer transition-all hover:bg-opacity-30`}
              onMouseEnter={() => setHoveredCell(`Low-${probability}`)}
              onMouseLeave={() => setHoveredCell(null)}
            >
              <span className="font-bold">{cell?.count}</span>
            </div>
          )
        })}
      </div>

      <div className="mt-4 p-3 rounded-lg border border-green-500/20 bg-green-500/5">
        <div className="flex items-start space-x-3">
          <div className="p-2 rounded-full bg-green-500/10 text-green-500">
            <HelpCircle className="h-4 w-4" />
          </div>
          <div>
            <h4 className="font-medium text-sm">Risk Assessment</h4>
            <p className="text-xs text-muted-foreground mt-1">
              AI has analyzed all applications and categorized them by risk level. High-risk applications require
              additional verification.
            </p>
          </div>
        </div>

        <div className="mt-3 space-y-2">
          <div className="flex items-center justify-between text-xs">
            <div className="flex items-center">
              <AlertTriangle className="h-3 w-3 text-red-500 mr-1" />
              <span>High Risk</span>
            </div>
            <span>10 applications</span>
          </div>
          <Progress value={10} max={124} className="h-1 bg-gray-800" indicatorClassName="bg-red-500" />

          <div className="flex items-center justify-between text-xs">
            <div className="flex items-center">
              <AlertTriangle className="h-3 w-3 text-amber-500 mr-1" />
              <span>Medium Risk</span>
            </div>
            <span>30 applications</span>
          </div>
          <Progress value={30} max={124} className="h-1 bg-gray-800" indicatorClassName="bg-amber-500" />

          <div className="flex items-center justify-between text-xs">
            <div className="flex items-center">
              <CheckCircle className="h-3 w-3 text-green-500 mr-1" />
              <span>Low Risk</span>
            </div>
            <span>84 applications</span>
          </div>
          <Progress value={84} max={124} className="h-1 bg-gray-800" indicatorClassName="bg-green-500" />
        </div>
      </div>
    </div>
  )
}

