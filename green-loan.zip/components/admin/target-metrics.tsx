"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Target, TrendingUp, Users, FileText, DollarSign } from "lucide-react"

export function TargetMetrics() {
  const quarterlyTargets = [
    {
      name: "New Applications",
      current: 320,
      target: 400,
      icon: FileText,
      percentComplete: 80,
      trend: "+15% from last quarter",
      color: "bg-blue-500",
    },
    {
      name: "New Users",
      current: 1250,
      target: 1500,
      icon: Users,
      percentComplete: 83,
      trend: "+12% from last quarter",
      color: "bg-purple-500",
    },
    {
      name: "Loan Volume",
      current: 2800000,
      target: 3500000,
      icon: DollarSign,
      percentComplete: 80,
      trend: "+18% from last quarter",
      color: "bg-green-500",
    },
    {
      name: "Approval Rate",
      current: 78,
      target: 85,
      icon: Target,
      percentComplete: 92,
      trend: "+5% from last quarter",
      color: "bg-amber-500",
    },
  ]

  const yearlyTargets = [
    {
      name: "Total Applications",
      current: 1250,
      target: 2000,
      icon: FileText,
      percentComplete: 62,
      trend: "+25% from last year",
      color: "bg-blue-500",
    },
    {
      name: "User Growth",
      current: 4500,
      target: 6000,
      icon: Users,
      percentComplete: 75,
      trend: "+30% from last year",
      color: "bg-purple-500",
    },
    {
      name: "Annual Loan Volume",
      current: 8500000,
      target: 12000000,
      icon: DollarSign,
      percentComplete: 71,
      trend: "+35% from last year",
      color: "bg-green-500",
    },
    {
      name: "Customer Satisfaction",
      current: 92,
      target: 95,
      icon: Target,
      percentComplete: 97,
      trend: "+3% from last year",
      color: "bg-amber-500",
    },
  ]

  return (
    <Tabs defaultValue="quarterly" className="space-y-4">
      <TabsList>
        <TabsTrigger value="quarterly">Quarterly Targets</TabsTrigger>
        <TabsTrigger value="yearly">Yearly Targets</TabsTrigger>
      </TabsList>
      <TabsContent value="quarterly" className="space-y-4">
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {quarterlyTargets.map((item, index) => (
            <Card key={index} className="overflow-hidden">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center">
                    <div className={`p-2 rounded-full ${item.color} bg-opacity-10 mr-3`}>
                      <item.icon className={`h-5 w-5 ${item.color.replace("bg-", "text-")}`} />
                    </div>
                    <h3 className="font-medium">{item.name}</h3>
                  </div>
                  <div className="text-sm font-medium">{item.percentComplete}%</div>
                </div>
                <div className="space-y-2">
                  <Progress value={item.percentComplete} className="h-2" />
                  <div className="flex items-center justify-between text-sm">
                    <div className="text-muted-foreground">
                      {item.name === "Loan Volume"
                        ? `$${item.current.toLocaleString()} / $${item.target.toLocaleString()}`
                        : `${item.current.toLocaleString()} / ${item.target.toLocaleString()}`}
                    </div>
                    <div className="flex items-center text-green-500">
                      <TrendingUp className="h-3 w-3 mr-1" />
                      <span className="text-xs">{item.trend}</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </TabsContent>
      <TabsContent value="yearly" className="space-y-4">
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {yearlyTargets.map((item, index) => (
            <Card key={index} className="overflow-hidden">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center">
                    <div className={`p-2 rounded-full ${item.color} bg-opacity-10 mr-3`}>
                      <item.icon className={`h-5 w-5 ${item.color.replace("bg-", "text-")}`} />
                    </div>
                    <h3 className="font-medium">{item.name}</h3>
                  </div>
                  <div className="text-sm font-medium">{item.percentComplete}%</div>
                </div>
                <div className="space-y-2">
                  <Progress value={item.percentComplete} className="h-2" />
                  <div className="flex items-center justify-between text-sm">
                    <div className="text-muted-foreground">
                      {item.name === "Annual Loan Volume"
                        ? `$${item.current.toLocaleString()} / $${item.target.toLocaleString()}`
                        : `${item.current.toLocaleString()} / ${item.target.toLocaleString()}`}
                    </div>
                    <div className="flex items-center text-green-500">
                      <TrendingUp className="h-3 w-3 mr-1" />
                      <span className="text-xs">{item.trend}</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </TabsContent>
    </Tabs>
  )
}

