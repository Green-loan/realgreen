"use client"
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts"

interface FuturisticChartProps {
  type: "line" | "area" | "bar"
  data: any[]
  height?: number
}

export function FuturisticChart({ type, data, height = 300 }: FuturisticChartProps) {
  return (
    <div className="h-[300px] w-full">
      <ResponsiveContainer width="100%" height={height}>
        {type === "line" ? (
          <LineChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
            <XAxis dataKey="month" stroke="rgba(255,255,255,0.5)" tick={{ fill: "rgba(255,255,255,0.5)" }} />
            <YAxis stroke="rgba(255,255,255,0.5)" tick={{ fill: "rgba(255,255,255,0.5)" }} />
            <Tooltip
              contentStyle={{
                backgroundColor: "rgba(0,0,0,0.8)",
                border: "1px solid rgba(0,200,100,0.2)",
                borderRadius: "8px",
                boxShadow: "0 0 15px rgba(0,200,100,0.15)",
              }}
            />
            <Legend />
            <Line
              type="monotone"
              dataKey="Applications"
              stroke="#10b981"
              strokeWidth={2}
              dot={{ fill: "#10b981", r: 4 }}
              activeDot={{ r: 6, fill: "#10b981", stroke: "rgba(16,185,129,0.2)", strokeWidth: 6 }}
            />
            <Line
              type="monotone"
              dataKey="Approved"
              stroke="#3b82f6"
              strokeWidth={2}
              dot={{ fill: "#3b82f6", r: 4 }}
              activeDot={{ r: 6, fill: "#3b82f6", stroke: "rgba(59,130,246,0.2)", strokeWidth: 6 }}
            />
            <Line
              type="monotone"
              dataKey="Predicted"
              stroke="#a855f7"
              strokeWidth={2}
              strokeDasharray="5 5"
              dot={{ fill: "#a855f7", r: 4 }}
              activeDot={{ r: 6, fill: "#a855f7", stroke: "rgba(168,85,247,0.2)", strokeWidth: 6 }}
            />
          </LineChart>
        ) : type === "area" ? (
          <AreaChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
            <defs>
              <linearGradient id="colorApplications" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#10b981" stopOpacity={0.8} />
                <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
              </linearGradient>
              <linearGradient id="colorApproved" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.8} />
                <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
              </linearGradient>
              <linearGradient id="colorPredicted" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#a855f7" stopOpacity={0.8} />
                <stop offset="95%" stopColor="#a855f7" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
            <XAxis dataKey="month" stroke="rgba(255,255,255,0.5)" tick={{ fill: "rgba(255,255,255,0.5)" }} />
            <YAxis stroke="rgba(255,255,255,0.5)" tick={{ fill: "rgba(255,255,255,0.5)" }} />
            <Tooltip
              contentStyle={{
                backgroundColor: "rgba(0,0,0,0.8)",
                border: "1px solid rgba(0,200,100,0.2)",
                borderRadius: "8px",
                boxShadow: "0 0 15px rgba(0,200,100,0.15)",
              }}
            />
            <Legend />
            <Area
              type="monotone"
              dataKey="Applications"
              stroke="#10b981"
              strokeWidth={2}
              fillOpacity={1}
              fill="url(#colorApplications)"
              activeDot={{ r: 6, fill: "#10b981", stroke: "rgba(16,185,129,0.2)", strokeWidth: 6 }}
            />
            <Area
              type="monotone"
              dataKey="Approved"
              stroke="#3b82f6"
              strokeWidth={2}
              fillOpacity={1}
              fill="url(#colorApproved)"
              activeDot={{ r: 6, fill: "#3b82f6", stroke: "rgba(59,130,246,0.2)", strokeWidth: 6 }}
            />
            <Area
              type="monotone"
              dataKey="Predicted"
              stroke="#a855f7"
              strokeWidth={2}
              strokeDasharray="5 5"
              fillOpacity={1}
              fill="url(#colorPredicted)"
              activeDot={{ r: 6, fill: "#a855f7", stroke: "rgba(168,85,247,0.2)", strokeWidth: 6 }}
            />
          </AreaChart>
        ) : (
          <BarChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
            <XAxis dataKey="month" stroke="rgba(255,255,255,0.5)" tick={{ fill: "rgba(255,255,255,0.5)" }} />
            <YAxis stroke="rgba(255,255,255,0.5)" tick={{ fill: "rgba(255,255,255,0.5)" }} />
            <Tooltip
              contentStyle={{
                backgroundColor: "rgba(0,0,0,0.8)",
                border: "1px solid rgba(0,200,100,0.2)",
                borderRadius: "8px",
                boxShadow: "0 0 15px rgba(0,200,100,0.15)",
              }}
            />
            <Legend />
            <Bar dataKey="Applications" fill="#10b981" radius={[4, 4, 0, 0]} />
            <Bar dataKey="Approved" fill="#3b82f6" radius={[4, 4, 0, 0]} />
            <Bar dataKey="Predicted" fill="#a855f7" radius={[4, 4, 0, 0]} />
          </BarChart>
        )}
      </ResponsiveContainer>
    </div>
  )
}

