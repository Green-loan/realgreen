"use client"

import { useState } from "react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import {
  CheckCircle,
  XCircle,
  Clock,
  Eye,
  Brain,
  Bell,
  Search,
  Filter,
  ArrowUpDown,
  Download,
  FileText,
} from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Card, CardContent } from "@/components/ui/card"

interface Application {
  id: number
  user_id?: string
  loan_amount?: number
  loan_purpose?: string
  status?: string
  created_at: string
  risk_score?: number
}

interface FuturisticApplicationsTableProps {
  applications: Application[]
}

export function FuturisticApplicationsTable({ applications }: FuturisticApplicationsTableProps) {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedStatus, setSelectedStatus] = useState<string | null>(null)

  // Filter applications based on search term and selected status
  const filteredApplications = applications.filter((app) => {
    const matchesSearch =
      app.loan_purpose?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      app.id.toString().includes(searchTerm) ||
      app.loan_amount?.toString().includes(searchTerm)

    const matchesStatus = selectedStatus ? app.status === selectedStatus : true

    return matchesSearch && matchesStatus
  })

  return (
    <Card className="border border-green-500/20 bg-black/40 backdrop-blur-sm shadow-[0_0_15px_rgba(0,200,100,0.15)]">
      <CardContent className="p-0">
        <div className="p-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="relative w-full sm:w-auto flex-1">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search applications..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-8 bg-background/50 border-green-500/20 focus-visible:ring-green-500/30"
            />
          </div>
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="outline"
                  className="border-green-500/20 bg-green-500/10 text-green-500 hover:bg-green-500/20"
                >
                  <Filter className="mr-2 h-4 w-4" />
                  Filter
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                <DropdownMenuLabel>Filter by Status</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => setSelectedStatus(null)}>All</DropdownMenuItem>
                <DropdownMenuItem onClick={() => setSelectedStatus("approved")}>
                  <CheckCircle className="mr-2 h-4 w-4 text-green-500" />
                  Approved
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setSelectedStatus("pending")}>
                  <Clock className="mr-2 h-4 w-4 text-amber-500" />
                  Pending
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setSelectedStatus("rejected")}>
                  <XCircle className="mr-2 h-4 w-4 text-red-500" />
                  Rejected
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            <Button
              variant="outline"
              className="border-green-500/20 bg-green-500/10 text-green-500 hover:bg-green-500/20"
            >
              <Download className="mr-2 h-4 w-4" />
              Export
            </Button>
          </div>
        </div>

        <Table>
          <TableHeader>
            <TableRow className="hover:bg-green-500/5 border-green-500/20">
              <TableHead className="w-[100px]">ID</TableHead>
              <TableHead>
                <div className="flex items-center">
                  Purpose
                  <ArrowUpDown className="ml-2 h-4 w-4" />
                </div>
              </TableHead>
              <TableHead>
                <div className="flex items-center">
                  Amount
                  <ArrowUpDown className="ml-2 h-4 w-4" />
                </div>
              </TableHead>
              <TableHead>
                <div className="flex items-center">
                  Date
                  <ArrowUpDown className="ml-2 h-4 w-4" />
                </div>
              </TableHead>
              <TableHead>
                <div className="flex items-center">
                  Status
                  <ArrowUpDown className="ml-2 h-4 w-4" />
                </div>
              </TableHead>
              <TableHead>
                <div className="flex items-center">
                  AI Risk Score
                  <ArrowUpDown className="ml-2 h-4 w-4" />
                </div>
              </TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredApplications.length > 0 ? (
              filteredApplications.map((application) => (
                <TableRow
                  key={application.id}
                  className="hover:bg-green-500/5 border-green-500/20 animate-in fade-in duration-300"
                >
                  <TableCell className="font-medium">#{application.id}</TableCell>
                  <TableCell>{application.loan_purpose || "N/A"}</TableCell>
                  <TableCell>${application.loan_amount?.toLocaleString() || "0"}</TableCell>
                  <TableCell>{new Date(application.created_at).toLocaleDateString()}</TableCell>
                  <TableCell>
                    {application.status === "approved" && (
                      <Badge variant="outline" className="bg-green-500/10 text-green-500 border-green-500/20">
                        <CheckCircle className="mr-1 h-3 w-3" /> Approved
                      </Badge>
                    )}
                    {application.status === "pending" && (
                      <Badge variant="outline" className="bg-amber-500/10 text-amber-500 border-amber-500/20">
                        <Clock className="mr-1 h-3 w-3" /> Pending
                      </Badge>
                    )}
                    {application.status === "rejected" && (
                      <Badge variant="outline" className="bg-red-500/10 text-red-500 border-red-500/20">
                        <XCircle className="mr-1 h-3 w-3" /> Rejected
                      </Badge>
                    )}
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center">
                      <div
                        className={`h-2 w-2 rounded-full mr-2 ${
                          (application.risk_score || 0) > 70
                            ? "bg-green-500"
                            : (application.risk_score || 0) > 40
                              ? "bg-amber-500"
                              : "bg-red-500"
                        }`}
                      />
                      <span>{application.risk_score || Math.floor(Math.random() * 100)}</span>
                    </div>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex items-center justify-end gap-2">
                      <Button variant="outline" size="sm" className="h-8 w-8 p-0">
                        <Eye className="h-4 w-4" />
                        <span className="sr-only">View</span>
                      </Button>
                      <Button variant="outline" size="sm" className="h-8 w-8 p-0">
                        <Brain className="h-4 w-4" />
                        <span className="sr-only">AI Analysis</span>
                      </Button>
                      <Button variant="outline" size="sm" className="h-8 w-8 p-0">
                        <Bell className="h-4 w-4" />
                        <span className="sr-only">Notify</span>
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={7} className="text-center py-6">
                  <div className="flex flex-col items-center justify-center">
                    <FileText className="h-10 w-10 text-muted-foreground mb-2" />
                    <p className="text-muted-foreground">No applications found</p>
                  </div>
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  )
}

