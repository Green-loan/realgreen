"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { LayoutDashboard, Users, FileText, BarChart3, Settings, Bell, CheckCircle, AlertCircle } from "lucide-react"

export function AdminSidebar() {
  const pathname = usePathname()

  const navItems = [
    {
      title: "Dashboard",
      href: "/admin/dashboard",
      icon: LayoutDashboard,
    },
    {
      title: "Applications",
      href: "/admin/applications",
      icon: FileText,
    },
    {
      title: "Users",
      href: "/admin/users",
      icon: Users,
    },
    {
      title: "Reports",
      href: "/admin/reports",
      icon: BarChart3,
    },
    {
      title: "Approvals",
      href: "/admin/approvals",
      icon: CheckCircle,
    },
    {
      title: "Notifications",
      href: "/admin/notifications",
      icon: Bell,
    },
    {
      title: "Risk Management",
      href: "/admin/risk",
      icon: AlertCircle,
    },
    {
      title: "Settings",
      href: "/admin/settings",
      icon: Settings,
    },
  ]

  return (
    <div className="fixed inset-y-0 left-0 z-20 hidden w-64 flex-col border-r border-border/40 bg-background/95 pt-14 md:flex">
      <div className="flex h-14 items-center border-b border-border/40 px-4">
        <h2 className="text-lg font-semibold">Admin Panel</h2>
      </div>
      <ScrollArea className="flex-1">
        <nav className="flex flex-col gap-1 p-2">
          {navItems.map((item) => (
            <Button
              key={item.href}
              asChild
              variant="ghost"
              className={cn("justify-start", pathname === item.href && "bg-accent text-accent-foreground")}
            >
              <Link href={item.href}>
                <item.icon className="mr-2 h-5 w-5" />
                <span>{item.title}</span>
              </Link>
            </Button>
          ))}
        </nav>
      </ScrollArea>
    </div>
  )
}

