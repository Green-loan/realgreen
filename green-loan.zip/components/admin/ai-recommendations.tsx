"use client"

import { Badge } from "@/components/ui/badge"
import { Lightbulb, Zap, TrendingUp } from "lucide-react"

interface Recommendation {
  id: number
  title: string
  impact: "High" | "Medium" | "Low"
  description: string
}

interface AIRecommendationsProps {
  recommendations: Recommendation[]
}

export function AIRecommendations({ recommendations }: AIRecommendationsProps) {
  return (
    <div className="space-y-4">
      {recommendations.map((recommendation, index) => (
        <div
          key={recommendation.id}
          className="p-4 rounded-lg border border-green-500/20 bg-green-500/5 space-y-2 animate-in fade-in duration-300"
          style={{ animationDelay: `${index * 150}ms` }}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Lightbulb className="h-4 w-4 text-green-500" />
              <h4 className="font-medium">{recommendation.title}</h4>
            </div>
            <Badge
              variant="outline"
              className={
                recommendation.impact === "High"
                  ? "bg-green-500/10 text-green-500 border-green-500/20"
                  : recommendation.impact === "Medium"
                    ? "bg-blue-500/10 text-blue-500 border-blue-500/20"
                    : "bg-amber-500/10 text-amber-500 border-amber-500/20"
              }
            >
              {recommendation.impact === "High" && <Zap className="mr-1 h-3 w-3" />}
              {recommendation.impact === "Medium" && <TrendingUp className="mr-1 h-3 w-3" />}
              {recommendation.impact} Impact
            </Badge>
          </div>
          <p className="text-sm text-muted-foreground">{recommendation.description}</p>
        </div>
      ))}
    </div>
  )
}

