"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Brain, Sparkles, CheckCircle, AlertTriangle, Lightbulb, Download } from "lucide-react"

interface AIApplicationAnalysisProps {
  applicationId?: number
}

export function AIApplicationAnalysis({ applicationId = 123 }: AIApplicationAnalysisProps) {
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [analysisComplete, setAnalysisComplete] = useState(false)

  const handleAnalyze = async () => {
    setIsAnalyzing(true)
    // Simulate AI analysis
    await new Promise((resolve) => setTimeout(resolve, 2500))
    setIsAnalyzing(false)
    setAnalysisComplete(true)
  }

  return (
    <Card className="border border-green-500/20 bg-black/40 backdrop-blur-sm shadow-[0_0_15px_rgba(0,200,100,0.15)]">
      <CardHeader>
        <CardTitle className="text-xl font-bold flex items-center">
          <Brain className="mr-2 h-5 w-5 text-green-500" />
          AI Application Analysis
          <Badge variant="outline" className="ml-2 bg-green-500/10 text-green-500 border-green-500/20">
            <Sparkles className="mr-1 h-3 w-3" /> Advanced
          </Badge>
        </CardTitle>
        <CardDescription>Deep analysis of application #{applicationId} using AI</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {!analysisComplete ? (
          <div className="flex flex-col items-center justify-center py-8">
            {isAnalyzing ? (
              <>
                <div className="relative h-24 w-24 mb-6">
                  <div className="absolute inset-0 rounded-full border-4 border-green-500/20 border-t-green-500 animate-spin" />
                  <div className="absolute inset-3 rounded-full border-4 border-blue-500/20 border-t-blue-500 animate-spin animation-delay-500" />
                  <div className="absolute inset-6 rounded-full border-4 border-purple-500/20 border-t-purple-500 animate-spin animation-delay-1000" />
                  <Brain className="absolute inset-0 h-full w-full p-6 text-green-500 animate-pulse" />
                </div>
                <h3 className="text-lg font-bold mb-2">AI Analysis in Progress</h3>
                <p className="text-sm text-muted-foreground text-center max-w-md mb-4">
                  Our advanced AI is analyzing credit history, application data, and market conditions to provide a
                  comprehensive risk assessment.
                </p>
                <div className="w-full max-w-md">
                  <div className="h-1.5 w-full bg-gray-800 rounded-full overflow-hidden">
                    <div className="h-full bg-gradient-to-r from-green-500 to-blue-500 animate-progress" />
                  </div>
                </div>
              </>
            ) : (
              <>
                <div className="p-6 rounded-full bg-green-500/10 mb-6">
                  <Brain className="h-12 w-12 text-green-500" />
                </div>
                <h3 className="text-lg font-bold mb-2">AI Analysis Ready</h3>
                <p className="text-sm text-muted-foreground text-center max-w-md mb-6">
                  Click the button below to start AI analysis of this application. The process takes approximately 2-3
                  seconds.
                </p>
                <Button
                  onClick={handleAnalyze}
                  className="bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600"
                >
                  <Sparkles className="mr-2 h-4 w-4" />
                  Start AI Analysis
                </Button>
              </>
            )}
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 rounded-lg border border-green-500/20 bg-green-500/5 flex flex-col">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-medium">Approval Probability</h4>
                  <Badge variant="outline" className="bg-green-500/10 text-green-500 border-green-500/20">
                    <CheckCircle className="mr-1 h-3 w-3" /> High
                  </Badge>
                </div>
                <div className="mt-2 mb-4 flex-1">
                  <div className="flex items-center justify-between text-xs mb-1">
                    <span>Score</span>
                    <span>85%</span>
                  </div>
                  <Progress value={85} className="h-2 bg-gray-800" indicatorClassName="bg-green-500" />
                </div>
                <p className="text-xs text-muted-foreground">Based on credit history and application data</p>
              </div>

              <div className="p-4 rounded-lg border border-green-500/20 bg-green-500/5 flex flex-col">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-medium">Risk Assessment</h4>
                  <Badge variant="outline" className="bg-green-500/10 text-green-500 border-green-500/20">
                    <CheckCircle className="mr-1 h-3 w-3" /> Low Risk
                  </Badge>
                </div>
                <div className="mt-2 mb-4 flex-1">
                  <div className="flex items-center justify-between text-xs mb-1">
                    <span>Score</span>
                    <span>15%</span>
                  </div>
                  <Progress value={15} className="h-2 bg-gray-800" indicatorClassName="bg-green-500" />
                </div>
                <p className="text-xs text-muted-foreground">Based on financial stability and payment history</p>
              </div>

              <div className="p-4 rounded-lg border border-green-500/20 bg-green-500/5 flex flex-col">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-medium">Fraud Detection</h4>
                  <Badge variant="outline" className="bg-green-500/10 text-green-500 border-green-500/20">
                    <CheckCircle className="mr-1 h-3 w-3" /> No Issues
                  </Badge>
                </div>
                <div className="mt-2 mb-4 flex-1">
                  <div className="flex items-center justify-between text-xs mb-1">
                    <span>Score</span>
                    <span>2%</span>
                  </div>
                  <Progress value={2} className="h-2 bg-gray-800" indicatorClassName="bg-green-500" />
                </div>
                <p className="text-xs text-muted-foreground">Based on identity verification and behavior patterns</p>
              </div>
            </div>

            <div className="p-4 rounded-lg border border-green-500/20 bg-green-500/5">
              <div className="flex items-start space-x-3">
                <div className="p-2 rounded-full bg-green-500/10 text-green-500">
                  <Lightbulb className="h-4 w-4" />
                </div>
                <div>
                  <h4 className="font-medium">AI Recommendation</h4>
                  <p className="text-sm text-muted-foreground mt-1">
                    Based on the comprehensive analysis, this application is recommended for approval. The applicant has
                    a strong credit history (score: 720) and a low debt-to-income ratio (28%). The requested loan amount
                    ($25,000) for solar panel installation is within the recommended range based on the applicant's
                    income and property value.
                  </p>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 rounded-lg border border-green-500/20 bg-green-500/5">
                <h4 className="font-medium mb-3">Key Factors</h4>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                      <span className="text-sm">Strong Payment History</span>
                    </div>
                    <Badge variant="outline" className="bg-green-500/10 text-green-500 border-green-500/20">
                      Positive
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                      <span className="text-sm">Stable Employment (5+ years)</span>
                    </div>
                    <Badge variant="outline" className="bg-green-500/10 text-green-500 border-green-500/20">
                      Positive
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                      <span className="text-sm">Low Debt-to-Income Ratio</span>
                    </div>
                    <Badge variant="outline" className="bg-green-500/10 text-green-500 border-green-500/20">
                      Positive
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <AlertTriangle className="h-4 w-4 text-amber-500 mr-2" />
                      <span className="text-sm">Recent Credit Inquiry</span>
                    </div>
                    <Badge variant="outline" className="bg-amber-500/10 text-amber-500 border-amber-500/20">
                      Neutral
                    </Badge>
                  </div>
                </div>
              </div>

              <div className="p-4 rounded-lg border border-green-500/20 bg-green-500/5">
                <h4 className="font-medium mb-3">Loan Terms Recommendation</h4>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Interest Rate</span>
                    <span className="font-medium">4.25%</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Loan Term</span>
                    <span className="font-medium">10 years</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Monthly Payment</span>
                    <span className="font-medium">$256.38</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Total Interest</span>
                    <span className="font-medium">$5,765.60</span>
                  </div>
                </div>
              </div>
            </div>
          </>
        )}
      </CardContent>
      {analysisComplete && (
        <CardFooter className="flex justify-between">
          <Button
            variant="outline"
            className="border-green-500/20 bg-green-500/10 text-green-500 hover:bg-green-500/20"
          >
            <Download className="mr-2 h-4 w-4" />
            Export Analysis
          </Button>
          <Button className="bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600">
            <CheckCircle className="mr-2 h-4 w-4" />
            Approve Application
          </Button>
        </CardFooter>
      )}
    </Card>
  )
}

