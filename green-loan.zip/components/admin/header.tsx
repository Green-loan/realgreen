import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ThemeToggle } from "@/components/theme-toggle"

export function AdminHeader() {
  return (
    <header className="fixed top-0 z-40 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="flex h-14 items-center justify-between px-4">
        <div className="flex items-center gap-2 md:gap-4">
          <Link href="/admin/dashboard" className="flex items-center gap-2">
            <div className="h-6 w-6 rounded-full bg-gradient-to-br from-green-400 to-emerald-600" />
            <span className="font-semibold text-lg hidden md:inline-flex">GreenLoan Admin</span>
          </Link>
        </div>
        <div className="flex items-center gap-2">
          <ThemeToggle />
          <Button asChild variant="outline" size="sm">
            <Link href="/">Back to Site</Link>
          </Button>
        </div>
      </div>
    </header>
  )
}

