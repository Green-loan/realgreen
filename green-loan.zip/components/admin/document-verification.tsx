"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { FileCheck, Clock, CheckCircle, XCircle, Eye } from "lucide-react"

interface Document {
  id: number
  name: string
  user: string
  status: "pending" | "in_progress" | "verified" | "rejected"
  confidence: number
  date: string
}

interface DocumentVerificationProps {
  documents: Document[]
}

export function DocumentVerification({ documents }: DocumentVerificationProps) {
  const [processingId, setProcessingId] = useState<number | null>(null)
  const [verifiedDocs, setVerifiedDocs] = useState<Record<number, boolean>>({})

  const handleVerify = async (id: number) => {
    setProcessingId(id)

    // Simulate AI verification process
    await new Promise((resolve) => setTimeout(resolve, 2000))

    setVerifiedDocs((prev) => ({ ...prev, [id]: true }))
    setProcessingId(null)
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="space-y-1">
          <h3 className="text-lg font-medium">Document Verification Queue</h3>
          <p className="text-sm text-muted-foreground">AI-powered verification system for loan application documents</p>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="outline" className="bg-green-500/10 text-green-500">
            <CheckCircle className="mr-1 h-3 w-3" /> 24 Verified
          </Badge>
          <Badge variant="outline" className="bg-yellow-500/10 text-yellow-500">
            <Clock className="mr-1 h-3 w-3" /> 12 Pending
          </Badge>
          <Badge variant="outline" className="bg-red-500/10 text-red-500">
            <XCircle className="mr-1 h-3 w-3" /> 5 Rejected
          </Badge>
        </div>
      </div>

      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Document</TableHead>
                <TableHead>User</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Confidence</TableHead>
                <TableHead>Date</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {documents.map((doc) => {
                const isVerified = verifiedDocs[doc.id] || doc.status === "verified"
                const isProcessing = processingId === doc.id
                const confidence = verifiedDocs[doc.id] ? 95 : doc.confidence

                return (
                  <TableRow key={doc.id} className="animate-in fade-in duration-300">
                    <TableCell className="font-medium">{doc.name}</TableCell>
                    <TableCell>{doc.user}</TableCell>
                    <TableCell>
                      {isVerified ? (
                        <Badge variant="outline" className="bg-green-500/10 text-green-500">
                          <CheckCircle className="mr-1 h-3 w-3" /> Verified
                        </Badge>
                      ) : isProcessing ? (
                        <Badge variant="outline" className="bg-blue-500/10 text-blue-500">
                          <Clock className="mr-1 h-3 w-3 animate-spin" /> Processing
                        </Badge>
                      ) : doc.status === "pending" ? (
                        <Badge variant="outline" className="bg-yellow-500/10 text-yellow-500">
                          <Clock className="mr-1 h-3 w-3" /> Pending
                        </Badge>
                      ) : doc.status === "in_progress" ? (
                        <Badge variant="outline" className="bg-blue-500/10 text-blue-500">
                          <Clock className="mr-1 h-3 w-3" /> In Progress
                        </Badge>
                      ) : (
                        <Badge variant="outline" className="bg-red-500/10 text-red-500">
                          <XCircle className="mr-1 h-3 w-3" /> Rejected
                        </Badge>
                      )}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Progress
                          value={confidence}
                          className="h-2 w-24"
                          indicatorClassName={
                            confidence > 80 ? "bg-green-500" : confidence > 50 ? "bg-yellow-500" : "bg-red-500"
                          }
                        />
                        <span className="text-xs">{confidence}%</span>
                      </div>
                    </TableCell>
                    <TableCell>{doc.date}</TableCell>
                    <TableCell className="text-right">
                      {!isVerified && !isProcessing && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleVerify(doc.id)}
                          disabled={isProcessing}
                        >
                          <FileCheck className="mr-1 h-4 w-4" />
                          Verify with AI
                        </Button>
                      )}
                      {isVerified && (
                        <Button variant="outline" size="sm">
                          <Eye className="mr-1 h-4 w-4" />
                          View
                        </Button>
                      )}
                    </TableCell>
                  </TableRow>
                )
              })}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}

