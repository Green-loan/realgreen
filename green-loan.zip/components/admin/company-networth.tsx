"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { TrendingUp, DollarSign, Download, BarChart3, LineChart, PieChart, Info } from "lucide-react"
import { FuturisticChart } from "./futuristic-chart"
import { useState } from "react"

interface NetworthData {
  totalNetworth: number
  networthChange: number
  networthChangePercentage: number
  historicalData: {
    date: string
    networth: number
    assets: number
    liabilities: number
    revenue: number
    expenses: number
  }[]
  breakdown: {
    name: string
    value: number
    percentage: number
    change: number
  }[]
  projections: {
    date: string
    projected: number
    optimistic: number
    conservative: number
  }[]
}

interface CompanyNetworthProps {
  data: NetworthData
}

export function CompanyNetworth({ data }: CompanyNetworthProps) {
  const [timeframe, setTimeframe] = useState<"1M" | "3M" | "6M" | "1Y" | "ALL">("1Y")

  // Format currency
  const formatCurrency = (value: number) => {
    if (value >= 1000000000) {
      return `$${(value / 1000000000).toFixed(2)}B`
    } else if (value >= 1000000) {
      return `$${(value / 1000000).toFixed(2)}M`
    } else if (value >= 1000) {
      return `$${(value / 1000).toFixed(2)}K`
    } else {
      return `$${value.toFixed(2)}`
    }
  }

  // Filter data based on timeframe
  const getFilteredData = () => {
    const now = new Date()
    const cutoffDate = new Date()

    switch (timeframe) {
      case "1M":
        cutoffDate.setMonth(now.getMonth() - 1)
        break
      case "3M":
        cutoffDate.setMonth(now.getMonth() - 3)
        break
      case "6M":
        cutoffDate.setMonth(now.getMonth() - 6)
        break
      case "1Y":
        cutoffDate.setFullYear(now.getFullYear() - 1)
        break
      case "ALL":
        return data.historicalData
    }

    return data.historicalData.filter((item) => new Date(item.date) >= cutoffDate)
  }

  const filteredData = getFilteredData()

  return (
    <Card className="border border-green-500/20 bg-black/40 backdrop-blur-sm shadow-[0_0_15px_rgba(0,200,100,0.15)]">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-xl font-bold flex items-center">
              <DollarSign className="mr-2 h-5 w-5 text-green-500" />
              Company Networth
              <Badge variant="outline" className="ml-2 bg-green-500/10 text-green-500 border-green-500/20">
                <TrendingUp className="mr-1 h-3 w-3" />
                {data.networthChangePercentage >= 0 ? "+" : ""}
                {data.networthChangePercentage.toFixed(2)}%
              </Badge>
            </CardTitle>
            <CardDescription>Financial performance and historical analysis</CardDescription>
          </div>
          <div className="flex items-center space-x-2">
            <Button
              variant="outline"
              size="sm"
              className="border-green-500/20 bg-green-500/10 text-green-500 hover:bg-green-500/20"
            >
              <Download className="mr-2 h-4 w-4" />
              Export
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="border-green-500/20 bg-green-500/10 text-green-500 hover:bg-green-500/20"
            >
              <Info className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid gap-6 md:grid-cols-3 mb-6">
          <div className="space-y-2">
            <p className="text-sm text-muted-foreground">Current Networth</p>
            <p className="text-3xl font-bold">{formatCurrency(data.totalNetworth)}</p>
            <div className="flex items-center text-sm">
              <span className={data.networthChange >= 0 ? "text-green-500" : "text-red-500"}>
                {data.networthChange >= 0 ? "+" : ""}
                {formatCurrency(data.networthChange)} ({data.networthChangePercentage >= 0 ? "+" : ""}
                {data.networthChangePercentage.toFixed(2)}%)
              </span>
              <span className="text-muted-foreground ml-1">vs previous period</span>
            </div>
          </div>

          <div className="space-y-2">
            <p className="text-sm text-muted-foreground">Total Assets</p>
            <p className="text-3xl font-bold">{formatCurrency(filteredData[filteredData.length - 1]?.assets || 0)}</p>
            <div className="flex items-center text-sm">
              <span className="text-green-500">
                +{formatCurrency((filteredData[filteredData.length - 1]?.assets || 0) - (filteredData[0]?.assets || 0))}
              </span>
              <span className="text-muted-foreground ml-1">since {filteredData[0]?.date}</span>
            </div>
          </div>

          <div className="space-y-2">
            <p className="text-sm text-muted-foreground">Total Liabilities</p>
            <p className="text-3xl font-bold">
              {formatCurrency(filteredData[filteredData.length - 1]?.liabilities || 0)}
            </p>
            <div className="flex items-center text-sm">
              <span className="text-amber-500">
                {formatCurrency(
                  (filteredData[filteredData.length - 1]?.liabilities || 0) - (filteredData[0]?.liabilities || 0),
                )}
              </span>
              <span className="text-muted-foreground ml-1">since {filteredData[0]?.date}</span>
            </div>
          </div>
        </div>

        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-2">
            <Button
              variant={timeframe === "1M" ? "default" : "outline"}
              size="sm"
              onClick={() => setTimeframe("1M")}
              className={
                timeframe === "1M"
                  ? "bg-green-500 text-white"
                  : "border-green-500/20 bg-green-500/10 text-green-500 hover:bg-green-500/20"
              }
            >
              1M
            </Button>
            <Button
              variant={timeframe === "3M" ? "default" : "outline"}
              size="sm"
              onClick={() => setTimeframe("3M")}
              className={
                timeframe === "3M"
                  ? "bg-green-500 text-white"
                  : "border-green-500/20 bg-green-500/10 text-green-500 hover:bg-green-500/20"
              }
            >
              3M
            </Button>
            <Button
              variant={timeframe === "6M" ? "default" : "outline"}
              size="sm"
              onClick={() => setTimeframe("6M")}
              className={
                timeframe === "6M"
                  ? "bg-green-500 text-white"
                  : "border-green-500/20 bg-green-500/10 text-green-500 hover:bg-green-500/20"
              }
            >
              6M
            </Button>
            <Button
              variant={timeframe === "1Y" ? "default" : "outline"}
              size="sm"
              onClick={() => setTimeframe("1Y")}
              className={
                timeframe === "1Y"
                  ? "bg-green-500 text-white"
                  : "border-green-500/20 bg-green-500/10 text-green-500 hover:bg-green-500/20"
              }
            >
              1Y
            </Button>
            <Button
              variant={timeframe === "ALL" ? "default" : "outline"}
              size="sm"
              onClick={() => setTimeframe("ALL")}
              className={
                timeframe === "ALL"
                  ? "bg-green-500 text-white"
                  : "border-green-500/20 bg-green-500/10 text-green-500 hover:bg-green-500/20"
              }
            >
              ALL
            </Button>
          </div>

          <div className="flex items-center space-x-2">
            <Button
              variant="outline"
              size="sm"
              className="border-green-500/20 bg-green-500/10 text-green-500 hover:bg-green-500/20"
            >
              <LineChart className="h-4 w-4" />
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="border-green-500/20 bg-green-500/10 text-green-500 hover:bg-green-500/20"
            >
              <BarChart3 className="h-4 w-4" />
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="border-green-500/20 bg-green-500/10 text-green-500 hover:bg-green-500/20"
            >
              <PieChart className="h-4 w-4" />
            </Button>
          </div>
        </div>

        <Tabs defaultValue="networth" className="space-y-4">
          <TabsList className="bg-black/40 backdrop-blur-sm border border-green-500/20 p-1">
            <TabsTrigger
              value="networth"
              className="data-[state=active]:bg-green-500/10 data-[state=active]:text-green-500"
            >
              Networth
            </TabsTrigger>
            <TabsTrigger
              value="breakdown"
              className="data-[state=active]:bg-green-500/10 data-[state=active]:text-green-500"
            >
              Breakdown
            </TabsTrigger>
            <TabsTrigger
              value="projections"
              className="data-[state=active]:bg-green-500/10 data-[state=active]:text-green-500"
            >
              Projections
            </TabsTrigger>
          </TabsList>

          <TabsContent value="networth" className="space-y-4">
            <div className="h-[300px]">
              <FuturisticChart
                type="area"
                height={300}
                data={filteredData.map((item) => ({
                  date: item.date,
                  Networth: item.networth,
                  Assets: item.assets,
                  Liabilities: item.liabilities,
                }))}
              />
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4">
              {[
                {
                  label: "Revenue",
                  value: formatCurrency(filteredData.reduce((sum, item) => sum + item.revenue, 0)),
                  change: "+12.5%",
                },
                {
                  label: "Expenses",
                  value: formatCurrency(filteredData.reduce((sum, item) => sum + item.expenses, 0)),
                  change: "+8.3%",
                },
                { label: "Profit Margin", value: "24.7%", change: "+2.1%" },
                { label: "ROI", value: "18.3%", change: "+3.5%" },
              ].map((item, index) => (
                <div key={index} className="p-3 rounded-lg border border-green-500/20 bg-green-500/5">
                  <p className="text-xs text-muted-foreground">{item.label}</p>
                  <p className="text-lg font-bold">{item.value}</p>
                  <p className="text-xs text-green-500">{item.change}</p>
                </div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="breakdown">
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h4 className="text-sm font-medium mb-3">Networth Composition</h4>
                <div className="space-y-4">
                  {data.breakdown.map((item, index) => (
                    <div key={index} className="space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <span className="text-sm font-medium">{item.name}</span>
                          <Badge className="ml-2 bg-green-500/10 text-green-500 border-green-500/20">
                            {item.percentage}%
                          </Badge>
                        </div>
                        <span className="text-sm font-medium">{formatCurrency(item.value)}</span>
                      </div>
                      <div className="h-2 rounded-full bg-green-950">
                        <div
                          className="h-full rounded-full bg-gradient-to-r from-green-500 to-blue-400"
                          style={{ width: `${item.percentage}%` }}
                        />
                      </div>
                      <div className="flex items-center text-xs">
                        <span className={item.change >= 0 ? "text-green-500" : "text-red-500"}>
                          {item.change >= 0 ? "+" : ""}
                          {item.change}% from previous period
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-center">
                <div className="w-64 h-64 rounded-full border-8 border-green-500/20 relative flex items-center justify-center">
                  <div
                    className="absolute inset-0 rounded-full border-t-8 border-green-500 animate-spin"
                    style={{ animationDuration: "10s" }}
                  ></div>
                  <div className="text-center">
                    <p className="text-3xl font-bold">{formatCurrency(data.totalNetworth)}</p>
                    <p className="text-sm text-muted-foreground">Total Networth</p>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="projections">
            <div className="h-[300px]">
              <FuturisticChart
                type="line"
                height={300}
                data={data.projections.map((item) => ({
                  date: item.date,
                  Projected: item.projected,
                  Optimistic: item.optimistic,
                  Conservative: item.conservative,
                }))}
              />
            </div>

            <div className="grid grid-cols-3 gap-4 mt-4">
              {[
                { label: "Projected Growth", value: "+15.7%", description: "Based on current trends" },
                { label: "Optimistic Scenario", value: "+24.3%", description: "With market expansion" },
                { label: "Conservative Scenario", value: "+8.2%", description: "Accounting for market risks" },
              ].map((item, index) => (
                <div key={index} className="p-3 rounded-lg border border-green-500/20 bg-green-500/5">
                  <p className="text-xs text-muted-foreground">{item.label}</p>
                  <p className="text-lg font-bold">{item.value}</p>
                  <p className="text-xs text-muted-foreground">{item.description}</p>
                </div>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}

