"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Users, Activity, MousePointer, Clock, Globe, Laptop, Smartphone, Tablet } from "lucide-react"

interface VisitorData {
  totalActive: number
  newVisitors: number
  returningVisitors: number
  averageSessionTime: string
  bounceRate: string
  pageViews: number
  devices: {
    desktop: number
    mobile: number
    tablet: number
  }
  topPages: {
    path: string
    visitors: number
    percentage: number
  }[]
  locations: {
    country: string
    visitors: number
    percentage: number
  }[]
}

export function RealTimeVisitors() {
  const [visitorData, setVisitorData] = useState<VisitorData>({
    totalActive: 0,
    newVisitors: 0,
    returningVisitors: 0,
    averageSessionTime: "0:00",
    bounceRate: "0%",
    pageViews: 0,
    devices: {
      desktop: 0,
      mobile: 0,
      tablet: 0,
    },
    topPages: [],
    locations: [],
  })

  // Simulate real-time data updates
  useEffect(() => {
    // Initial data
    const initialData: VisitorData = {
      totalActive: Math.floor(Math.random() * 50) + 20,
      newVisitors: Math.floor(Math.random() * 15) + 5,
      returningVisitors: Math.floor(Math.random() * 20) + 10,
      averageSessionTime: `${Math.floor(Math.random() * 3) + 1}:${Math.floor(Math.random() * 60)
        .toString()
        .padStart(2, "0")}`,
      bounceRate: `${Math.floor(Math.random() * 20) + 30}%`,
      pageViews: Math.floor(Math.random() * 200) + 100,
      devices: {
        desktop: Math.floor(Math.random() * 40) + 30,
        mobile: Math.floor(Math.random() * 30) + 20,
        tablet: Math.floor(Math.random() * 10) + 5,
      },
      topPages: [
        { path: "/", visitors: Math.floor(Math.random() * 30) + 20, percentage: Math.floor(Math.random() * 30) + 20 },
        {
          path: "/calculator",
          visitors: Math.floor(Math.random() * 20) + 10,
          percentage: Math.floor(Math.random() * 20) + 10,
        },
        {
          path: "/about",
          visitors: Math.floor(Math.random() * 15) + 5,
          percentage: Math.floor(Math.random() * 15) + 5,
        },
        {
          path: "/contact",
          visitors: Math.floor(Math.random() * 10) + 5,
          percentage: Math.floor(Math.random() * 10) + 5,
        },
      ],
      locations: [
        {
          country: "South Africa",
          visitors: Math.floor(Math.random() * 30) + 20,
          percentage: Math.floor(Math.random() * 30) + 20,
        },
        {
          country: "Nigeria",
          visitors: Math.floor(Math.random() * 20) + 10,
          percentage: Math.floor(Math.random() * 20) + 10,
        },
        {
          country: "Kenya",
          visitors: Math.floor(Math.random() * 15) + 5,
          percentage: Math.floor(Math.random() * 15) + 5,
        },
        {
          country: "Ghana",
          visitors: Math.floor(Math.random() * 10) + 5,
          percentage: Math.floor(Math.random() * 10) + 5,
        },
      ],
    }

    setVisitorData(initialData)

    // Update data every 5 seconds to simulate real-time changes
    const interval = setInterval(() => {
      setVisitorData((prevData) => {
        const changeValue = (value: number) => {
          const change = Math.floor(Math.random() * 5) - 2 // Random change between -2 and +2
          return Math.max(0, value + change)
        }

        return {
          ...prevData,
          totalActive: changeValue(prevData.totalActive),
          newVisitors: changeValue(prevData.newVisitors),
          returningVisitors: changeValue(prevData.returningVisitors),
          pageViews: prevData.pageViews + Math.floor(Math.random() * 5),
          devices: {
            desktop: changeValue(prevData.devices.desktop),
            mobile: changeValue(prevData.devices.mobile),
            tablet: changeValue(prevData.devices.tablet),
          },
        }
      })
    }, 5000)

    return () => clearInterval(interval)
  }, [])

  return (
    <Card className="border border-green-500/20 bg-black/40 backdrop-blur-sm shadow-[0_0_15px_rgba(0,200,100,0.15)]">
      <CardHeader>
        <CardTitle className="text-xl font-bold flex items-center">
          <Activity className="mr-2 h-5 w-5 text-green-500" />
          Real-Time Visitors
          <Badge variant="outline" className="ml-2 bg-green-500/10 text-green-500 border-green-500/20 animate-pulse">
            Live
          </Badge>
        </CardTitle>
        <CardDescription>Current user activity on your website</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-muted-foreground">Active Users</span>
              <Users className="h-4 w-4 text-green-500" />
            </div>
            <p className="text-2xl font-bold">{visitorData.totalActive}</p>
            <div className="h-1 w-full bg-gray-800 rounded-full overflow-hidden">
              <div
                className="h-full rounded-full bg-gradient-to-r from-green-500 to-green-400"
                style={{ width: `${Math.min(100, (visitorData.totalActive / 100) * 100)}%` }}
              />
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-muted-foreground">New Visitors</span>
              <MousePointer className="h-4 w-4 text-blue-500" />
            </div>
            <p className="text-2xl font-bold">{visitorData.newVisitors}</p>
            <div className="h-1 w-full bg-gray-800 rounded-full overflow-hidden">
              <div
                className="h-full rounded-full bg-gradient-to-r from-blue-500 to-blue-400"
                style={{ width: `${Math.min(100, (visitorData.newVisitors / 50) * 100)}%` }}
              />
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-muted-foreground">Page Views</span>
              <Activity className="h-4 w-4 text-purple-500" />
            </div>
            <p className="text-2xl font-bold">{visitorData.pageViews}</p>
            <div className="h-1 w-full bg-gray-800 rounded-full overflow-hidden">
              <div
                className="h-full rounded-full bg-gradient-to-r from-purple-500 to-purple-400"
                style={{ width: `${Math.min(100, (visitorData.pageViews / 300) * 100)}%` }}
              />
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-muted-foreground">Avg. Session</span>
              <Clock className="h-4 w-4 text-amber-500" />
            </div>
            <p className="text-2xl font-bold">{visitorData.averageSessionTime}</p>
            <div className="h-1 w-full bg-gray-800 rounded-full overflow-hidden">
              <div
                className="h-full rounded-full bg-gradient-to-r from-amber-500 to-amber-400"
                style={{ width: "65%" }}
              />
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h3 className="text-sm font-medium text-muted-foreground mb-3">Top Pages</h3>
            <div className="space-y-3">
              {visitorData.topPages.map((page, index) => (
                <div key={index} className="space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium truncate max-w-[180px]">{page.path}</span>
                    <span className="text-sm">{page.visitors} users</span>
                  </div>
                  <div className="h-1.5 w-full bg-gray-800 rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-green-500 to-blue-500"
                      style={{ width: `${page.percentage}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div>
            <h3 className="text-sm font-medium text-muted-foreground mb-3">Devices</h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <div className="p-1.5 rounded-full bg-green-500/10 text-green-500 mr-2">
                    <Laptop className="h-4 w-4" />
                  </div>
                  <span className="text-sm font-medium">Desktop</span>
                </div>
                <span className="text-sm">{visitorData.devices.desktop} users</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <div className="p-1.5 rounded-full bg-blue-500/10 text-blue-500 mr-2">
                    <Smartphone className="h-4 w-4" />
                  </div>
                  <span className="text-sm font-medium">Mobile</span>
                </div>
                <span className="text-sm">{visitorData.devices.mobile} users</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <div className="p-1.5 rounded-full bg-purple-500/10 text-purple-500 mr-2">
                    <Tablet className="h-4 w-4" />
                  </div>
                  <span className="text-sm font-medium">Tablet</span>
                </div>
                <span className="text-sm">{visitorData.devices.tablet} users</span>
              </div>
            </div>

            <h3 className="text-sm font-medium text-muted-foreground mt-6 mb-3">Top Locations</h3>
            <div className="space-y-3">
              {visitorData.locations.map((location, index) => (
                <div key={index} className="flex items-center justify-between">
                  <div className="flex items-center">
                    <div className="p-1.5 rounded-full bg-green-500/10 text-green-500 mr-2">
                      <Globe className="h-4 w-4" />
                    </div>
                    <span className="text-sm font-medium">{location.country}</span>
                  </div>
                  <span className="text-sm">{location.visitors} users</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

