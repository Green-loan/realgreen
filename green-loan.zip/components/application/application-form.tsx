"use client"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Loader2, ArrowLeft, ArrowRight, Upload, Check, AlertCircle } from "lucide-react"
import { useState } from "react"
import { cn } from "@/lib/utils"

interface ApplicationFormProps {
  currentStep: number
  formData: any
  onChange: (field: string, value: any) => void
  onStepChange: (step: number) => void
  onSubmit: () => void
  isSubmitting: boolean
  steps: { id: string; title: string }[]
}

export function ApplicationForm({
  currentStep,
  formData,
  onChange,
  onStepChange,
  onSubmit,
  isSubmitting,
  steps,
}: ApplicationFormProps) {
  const [errors, setErrors] = useState<Record<string, string>>({})

  const validateStep = () => {
    const newErrors: Record<string, string> = {}
    let isValid = true

    // Validation for Personal Details
    if (currentStep === 0) {
      if (!formData.fullName) {
        newErrors.fullName = "Full name is required"
        isValid = false
      }
      if (!formData.email) {
        newErrors.email = "Email is required"
        isValid = false
      } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
        newErrors.email = "Email is invalid"
        isValid = false
      }
      if (!formData.phone) {
        newErrors.phone = "Phone number is required"
        isValid = false
      }
      if (!formData.dateOfBirth) {
        newErrors.dateOfBirth = "Date of birth is required"
        isValid = false
      }
      if (!formData.monthlyIncome) {
        newErrors.monthlyIncome = "Monthly income is required"
        isValid = false
      }
    }

    // Validation for Banking Information
    else if (currentStep === 1) {
      if (!formData.bankName) {
        newErrors.bankName = "Bank name is required"
        isValid = false
      }
      if (!formData.accountNumber) {
        newErrors.accountNumber = "Account number is required"
        isValid = false
      }
    }

    // Validation for Physical Address
    else if (currentStep === 2) {
      if (!formData.streetAddress) {
        newErrors.streetAddress = "Street address is required"
        isValid = false
      }
      if (!formData.city) {
        newErrors.city = "City is required"
        isValid = false
      }
      if (!formData.province) {
        newErrors.province = "Province is required"
        isValid = false
      }
      if (!formData.zipCode) {
        newErrors.zipCode = "ZIP code is required"
        isValid = false
      }
    }

    // Validation for Project Details
    else if (currentStep === 3) {
      if (!formData.loanAmount) {
        newErrors.loanAmount = "Loan amount is required"
        isValid = false
      }
      if (!formData.loanPurpose) {
        newErrors.loanPurpose = "Loan purpose is required"
        isValid = false
      }
      if (!formData.dueDate) {
        newErrors.dueDate = "Due date is required"
        isValid = false
      }
    }

    // Validation for Documents
    else if (currentStep === 4) {
      if (!formData.identificationDoc) {
        newErrors.identificationDoc = "ID/Passport document is required"
        isValid = false
      }
      if (!formData.bankStatementDoc) {
        newErrors.bankStatementDoc = "Bank statement is required"
        isValid = false
      }
    }

    // Validation for Review & Submit
    else if (currentStep === 5) {
      if (!formData.agreeToTerms) {
        newErrors.agreeToTerms = "You must agree to the terms and conditions"
        isValid = false
      }
    }

    setErrors(newErrors)
    return isValid
  }

  const handleNext = () => {
    if (validateStep()) {
      onStepChange(currentStep + 1)
    }
  }

  const handleBack = () => {
    onStepChange(currentStep - 1)
  }

  const handleSubmitForm = () => {
    if (validateStep()) {
      onSubmit()
    }
  }

  const renderFormStep = () => {
    switch (currentStep) {
      case 0:
        return (
          <div className="space-y-6 p-6">
            <h2 className="text-2xl font-semibold">Personal Details</h2>
            <p className="text-foreground/70">Please provide your personal information.</p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="fullName">
                  Full Name <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="fullName"
                  value={formData.fullName}
                  onChange={(e) => onChange("fullName", e.target.value)}
                  placeholder=""
                  className={cn(errors.fullName && "border-red-500")}
                />
                {errors.fullName && (
                  <p className="text-red-500 text-sm flex items-center gap-1">
                    <AlertCircle className="h-3 w-3" /> {errors.fullName}
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">
                  Email <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => onChange("email", e.target.value)}
                  placeholder=""
                  className={cn(errors.email && "border-red-500")}
                />
                {errors.email && (
                  <p className="text-red-500 text-sm flex items-center gap-1">
                    <AlertCircle className="h-3 w-3" /> {errors.email}
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="phone">
                  Phone Number <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="phone"
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => onChange("phone", e.target.value)}
                  placeholder=""
                  className={cn(errors.phone && "border-red-500")}
                />
                {errors.phone && (
                  <p className="text-red-500 text-sm flex items-center gap-1">
                    <AlertCircle className="h-3 w-3" /> {errors.phone}
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="dateOfBirth">
                  Date of Birth <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="dateOfBirth"
                  type="date"
                  value={formData.dateOfBirth}
                  onChange={(e) => onChange("dateOfBirth", e.target.value)}
                  className={cn(errors.dateOfBirth && "border-red-500")}
                />
                {errors.dateOfBirth && (
                  <p className="text-red-500 text-sm flex items-center gap-1">
                    <AlertCircle className="h-3 w-3" /> {errors.dateOfBirth}
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="employmentStatus">
                  Employment Status <span className="text-red-500">*</span>
                </Label>
                <Select
                  value={formData.employmentStatus}
                  onValueChange={(value) => onChange("employmentStatus", value)}
                >
                  <SelectTrigger id="employmentStatus">
                    <SelectValue placeholder="Select employment status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="employed">Employed</SelectItem>
                    <SelectItem value="self-employed">Self-Employed</SelectItem>
                    <SelectItem value="business-owner">Business Owner</SelectItem>
                    <SelectItem value="retired">Retired</SelectItem>
                    <SelectItem value="student">Student</SelectItem>
                    <SelectItem value="unemployed">Unemployed</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="monthlyIncome">
                  Monthly Income (R) <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="monthlyIncome"
                  type="number"
                  value={formData.monthlyIncome}
                  onChange={(e) => onChange("monthlyIncome", e.target.value)}
                  placeholder=""
                  className={cn(errors.monthlyIncome && "border-red-500")}
                />
                {errors.monthlyIncome && (
                  <p className="text-red-500 text-sm flex items-center gap-1">
                    <AlertCircle className="h-3 w-3" /> {errors.monthlyIncome}
                  </p>
                )}
              </div>
            </div>
          </div>
        )

      case 1:
        return (
          <div className="space-y-6 p-6">
            <h2 className="text-2xl font-semibold">Banking Information</h2>
            <p className="text-foreground/70">Please provide your banking details for loan disbursement.</p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="bankName">
                  Bank Name <span className="text-red-500">*</span>
                </Label>
                <Select value={formData.bankName} onValueChange={(value) => onChange("bankName", value)}>
                  <SelectTrigger id="bankName" className={cn(errors.bankName && "border-red-500")}>
                    <SelectValue placeholder="Select your bank" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="FNB">FNB</SelectItem>
                    <SelectItem value="CAPITEC">CAPITEC</SelectItem>
                    <SelectItem value="STANDARD BANK">STANDARD BANK</SelectItem>
                    <SelectItem value="ABSA">ABSA</SelectItem>
                    <SelectItem value="NEDBANK">NEDBANK</SelectItem>
                  </SelectContent>
                </Select>
                {errors.bankName && (
                  <p className="text-red-500 text-sm flex items-center gap-1">
                    <AlertCircle className="h-3 w-3" /> {errors.bankName}
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="accountType">
                  Account Type <span className="text-red-500">*</span>
                </Label>
                <Select value={formData.accountType} onValueChange={(value) => onChange("accountType", value)}>
                  <SelectTrigger id="accountType">
                    <SelectValue placeholder="Select account type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="checking">Checking</SelectItem>
                    <SelectItem value="savings">Savings</SelectItem>
                    <SelectItem value="business">Business</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="accountNumber">
                  Account Number <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="accountNumber"
                  value={formData.accountNumber}
                  onChange={(e) => onChange("accountNumber", e.target.value)}
                  placeholder=""
                  className={cn(errors.accountNumber && "border-red-500")}
                />
                {errors.accountNumber && (
                  <p className="text-red-500 text-sm flex items-center gap-1">
                    <AlertCircle className="h-3 w-3" /> {errors.accountNumber}
                  </p>
                )}
              </div>
            </div>

            <div className="bg-blue-500/10 p-4 rounded-lg border border-blue-500/20">
              <p className="text-sm text-blue-500 flex items-start">
                <AlertCircle className="h-4 w-4 mr-2 mt-0.5 flex-shrink-0" />
                Your banking information is secure and encrypted. We use industry-standard security measures to protect
                your data.
              </p>
            </div>
          </div>
        )

      case 2:
        return (
          <div className="space-y-6 p-6">
            <h2 className="text-2xl font-semibold">Physical Address</h2>
            <p className="text-foreground/70">Please provide your current residential address.</p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="streetAddress">
                  Street Address <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="streetAddress"
                  value={formData.streetAddress}
                  onChange={(e) => onChange("streetAddress", e.target.value)}
                  placeholder=""
                  className={cn(errors.streetAddress && "border-red-500")}
                />
                {errors.streetAddress && (
                  <p className="text-red-500 text-sm flex items-center gap-1">
                    <AlertCircle className="h-3 w-3" /> {errors.streetAddress}
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="city">
                  City <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="city"
                  value={formData.city}
                  onChange={(e) => onChange("city", e.target.value)}
                  placeholder=""
                  className={cn(errors.city && "border-red-500")}
                />
                {errors.city && (
                  <p className="text-red-500 text-sm flex items-center gap-1">
                    <AlertCircle className="h-3 w-3" /> {errors.city}
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="province">
                  Province <span className="text-red-500">*</span>
                </Label>
                <Select value={formData.province} onValueChange={(value) => onChange("province", value)}>
                  <SelectTrigger id="province" className={cn(errors.province && "border-red-500")}>
                    <SelectValue placeholder="Select province" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Eastern Cape">Eastern Cape</SelectItem>
                    <SelectItem value="Free State">Free State</SelectItem>
                    <SelectItem value="Gauteng">Gauteng</SelectItem>
                    <SelectItem value="KwaZulu-Natal">KwaZulu-Natal</SelectItem>
                    <SelectItem value="Limpopo">Limpopo</SelectItem>
                    <SelectItem value="Mpumalanga">Mpumalanga</SelectItem>
                    <SelectItem value="Northern Cape">Northern Cape</SelectItem>
                    <SelectItem value="North West">North West</SelectItem>
                    <SelectItem value="Western Cape">Western Cape</SelectItem>
                  </SelectContent>
                </Select>
                {errors.province && (
                  <p className="text-red-500 text-sm flex items-center gap-1">
                    <AlertCircle className="h-3 w-3" /> {errors.province}
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="zipCode">
                  ZIP Code <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="zipCode"
                  value={formData.zipCode}
                  onChange={(e) => onChange("zipCode", e.target.value)}
                  placeholder=""
                  className={cn(errors.zipCode && "border-red-500")}
                />
                {errors.zipCode && (
                  <p className="text-red-500 text-sm flex items-center gap-1">
                    <AlertCircle className="h-3 w-3" /> {errors.zipCode}
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="residenceType">
                  Residence Type <span className="text-red-500">*</span>
                </Label>
                <RadioGroup
                  value={formData.residenceType}
                  onValueChange={(value) => onChange("residenceType", value)}
                  className="flex flex-col space-y-1"
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="own" id="own" />
                    <Label htmlFor="own">Own</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="rent" id="rent" />
                    <Label htmlFor="rent">Rent</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="other" id="other-residence" />
                    <Label htmlFor="other-residence">Other</Label>
                  </div>
                </RadioGroup>
              </div>
            </div>
          </div>
        )

      case 3:
        return (
          <div className="space-y-6 p-6">
            <h2 className="text-2xl font-semibold">Loan Details</h2>
            <p className="text-foreground/70">Tell us about the loan you need.</p>

            <div className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="loanType">
                  Loan Type <span className="text-red-500">*</span>
                </Label>
                <Select value={formData.loanType} onValueChange={(value) => onChange("loanType", value)}>
                  <SelectTrigger id="loanType">
                    <SelectValue placeholder="Select loan type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="personal">Personal Loan</SelectItem>
                    <SelectItem value="business">Business Loan</SelectItem>
                    <SelectItem value="medical">Medical</SelectItem>
                    <SelectItem value="school">School</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="loanAmount">
                  Loan Amount (R) <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="loanAmount"
                  type="number"
                  value={formData.loanAmount}
                  onChange={(e) => onChange("loanAmount", Number(e.target.value))}
                  placeholder=""
                  className={cn(errors.loanAmount && "border-red-500")}
                />
                {errors.loanAmount && (
                  <p className="text-red-500 text-sm flex items-center gap-1">
                    <AlertCircle className="h-3 w-3" /> {errors.loanAmount}
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="dueDate">
                  Due Date <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="dueDate"
                  type="date"
                  value={formData.dueDate}
                  onChange={(e) => onChange("dueDate", e.target.value)}
                  className={cn(errors.dueDate && "border-red-500")}
                  min={new Date(Date.now() + 86400000).toISOString().split("T")[0]} // Tomorrow
                />
                {errors.dueDate && (
                  <p className="text-red-500 text-sm flex items-center gap-1">
                    <AlertCircle className="h-3 w-3" /> {errors.dueDate}
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="loanPurpose">
                  Loan Purpose <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="loanPurpose"
                  value={formData.loanPurpose}
                  onChange={(e) => onChange("loanPurpose", e.target.value)}
                  placeholder=""
                  className={cn(errors.loanPurpose && "border-red-500")}
                />
                {errors.loanPurpose && (
                  <p className="text-red-500 text-sm flex items-center gap-1">
                    <AlertCircle className="h-3 w-3" /> {errors.loanPurpose}
                  </p>
                )}
              </div>
            </div>
          </div>
        )

      case 4:
        return (
          <div className="space-y-6 p-6">
            <h2 className="text-2xl font-semibold">Document Upload</h2>
            <p className="text-foreground/70">Please upload the required documents to support your application.</p>

            <div className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="identificationDoc">
                  ID/Passport Document <span className="text-red-500">*</span>
                </Label>
                <div
                  className="border-2 border-dashed border-border rounded-lg p-6 text-center hover:bg-foreground/5 transition-colors cursor-pointer"
                  onClick={() => document.getElementById("identificationDoc")?.click()}
                >
                  <div className="flex flex-col items-center justify-center">
                    <Upload className="h-10 w-10 text-foreground/40 mb-2" />
                    <p className="text-sm text-foreground/70 mb-1">Drag and drop your file here, or click to browse</p>
                    <p className="text-xs text-foreground/50">PDF, JPG, or PNG (Max 5MB)</p>
                    {formData.identificationDoc && (
                      <div className="mt-4 flex items-center gap-2 text-teal-500">
                        <Check className="h-4 w-4" />
                        <span className="text-sm">
                          {typeof formData.identificationDoc === "string"
                            ? formData.identificationDoc
                            : formData.identificationDoc.name || "File uploaded successfully"}
                        </span>
                      </div>
                    )}
                  </div>
                  <input
                    type="file"
                    id="identificationDoc"
                    className="hidden"
                    onChange={(e) => {
                      if (e.target.files && e.target.files[0]) {
                        onChange("identificationDoc", e.target.files[0])
                      }
                    }}
                  />
                </div>
                {errors.identificationDoc && (
                  <p className="text-red-500 text-sm flex items-center gap-1">
                    <AlertCircle className="h-3 w-3" /> {errors.identificationDoc}
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="bankStatementDoc">
                  3 Months Bank Statement <span className="text-red-500">*</span>
                </Label>
                <div
                  className="border-2 border-dashed border-border rounded-lg p-6 text-center hover:bg-foreground/5 transition-colors cursor-pointer"
                  onClick={() => document.getElementById("bankStatementDoc")?.click()}
                >
                  <div className="flex flex-col items-center justify-center">
                    <Upload className="h-10 w-10 text-foreground/40 mb-2" />
                    <p className="text-sm text-foreground/70 mb-1">Drag and drop your file here, or click to browse</p>
                    <p className="text-xs text-foreground/50">PDF, JPG, or PNG (Max 5MB)</p>
                    {formData.bankStatementDoc && (
                      <div className="mt-4 flex items-center gap-2 text-teal-500">
                        <Check className="h-4 w-4" />
                        <span className="text-sm">
                          {typeof formData.bankStatementDoc === "string"
                            ? formData.bankStatementDoc
                            : formData.bankStatementDoc.name || "File uploaded successfully"}
                        </span>
                      </div>
                    )}
                  </div>
                  <input
                    type="file"
                    id="bankStatementDoc"
                    className="hidden"
                    onChange={(e) => {
                      if (e.target.files && e.target.files[0]) {
                        onChange("bankStatementDoc", e.target.files[0])
                      }
                    }}
                  />
                </div>
                {errors.bankStatementDoc && (
                  <p className="text-red-500 text-sm flex items-center gap-1">
                    <AlertCircle className="h-3 w-3" /> {errors.bankStatementDoc}
                  </p>
                )}
              </div>

              <div className="bg-yellow-500/10 p-4 rounded-lg border border-yellow-500/20">
                <p className="text-sm text-yellow-500 flex items-start">
                  <AlertCircle className="h-4 w-4 mr-2 mt-0.5 flex-shrink-0" />
                  Document uploads are optional for this demo. In a real application, these would be required.
                </p>
              </div>
            </div>
          </div>
        )

      case 5:
        return (
          <div className="space-y-6 p-6">
            <h2 className="text-2xl font-semibold">Review & Submit</h2>
            <p className="text-foreground/70">Please review your application details before submitting.</p>

            <div className="space-y-6">
              <div className="bg-foreground/5 rounded-lg p-4">
                <h3 className="font-medium mb-2">Personal Details</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm">
                  <div>
                    <span className="text-foreground/70">Full Name:</span> {formData.fullName}
                  </div>
                  <div>
                    <span className="text-foreground/70">Email:</span> {formData.email}
                  </div>
                  <div>
                    <span className="text-foreground/70">Phone:</span> {formData.phone}
                  </div>
                  <div>
                    <span className="text-foreground/70">Date of Birth:</span> {formData.dateOfBirth}
                  </div>
                  <div>
                    <span className="text-foreground/70">Employment:</span> {formData.employmentStatus}
                  </div>
                  <div>
                    <span className="text-foreground/70">Monthly Income:</span> R{formData.monthlyIncome}
                  </div>
                </div>
              </div>

              <div className="bg-foreground/5 rounded-lg p-4">
                <h3 className="font-medium mb-2">Banking Information</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm">
                  <div>
                    <span className="text-foreground/70">Bank Name:</span> {formData.bankName}
                  </div>
                  <div>
                    <span className="text-foreground/70">Account Type:</span> {formData.accountType}
                  </div>
                  <div>
                    <span className="text-foreground/70">Account Number:</span>{" "}
                    {formData.accountNumber ? "••••" + formData.accountNumber.slice(-4) : ""}
                  </div>
                </div>
              </div>

              <div className="bg-foreground/5 rounded-lg p-4">
                <h3 className="font-medium mb-2">Physical Address</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm">
                  <div className="md:col-span-2">
                    <span className="text-foreground/70">Street Address:</span> {formData.streetAddress}
                  </div>
                  <div>
                    <span className="text-foreground/70">City:</span> {formData.city}
                  </div>
                  <div>
                    <span className="text-foreground/70">Province:</span> {formData.province}
                  </div>
                  <div>
                    <span className="text-foreground/70">ZIP Code:</span> {formData.zipCode}
                  </div>
                  <div>
                    <span className="text-foreground/70">Residence Type:</span> {formData.residenceType}
                  </div>
                </div>
              </div>

              <div className="bg-foreground/5 rounded-lg p-4">
                <h3 className="font-medium mb-2">Loan Details</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm">
                  <div>
                    <span className="text-foreground/70">Loan Type:</span> {formData.loanType}
                  </div>
                  <div>
                    <span className="text-foreground/70">Loan Amount:</span> R{formData.loanAmount.toLocaleString()}
                  </div>
                  <div>
                    <span className="text-foreground/70">Due Date:</span>{" "}
                    {formData.dueDate ? new Date(formData.dueDate).toLocaleDateString() : ""}
                  </div>
                  <div className="md:col-span-2">
                    <span className="text-foreground/70">Loan Purpose:</span> {formData.loanPurpose}
                  </div>
                </div>
              </div>

              <div className="bg-foreground/5 rounded-lg p-4">
                <h3 className="font-medium mb-2">Uploaded Documents</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm">
                  <div>
                    <span className="text-foreground/70">ID/Passport:</span>{" "}
                    {formData.identificationDoc ? (
                      <span className="text-green-500">Uploaded</span>
                    ) : (
                      <span className="text-red-500">Not uploaded</span>
                    )}
                  </div>
                  <div>
                    <span className="text-foreground/70">Bank Statement:</span>{" "}
                    {formData.bankStatementDoc ? (
                      <span className="text-green-500">Uploaded</span>
                    ) : (
                      <span className="text-red-500">Not uploaded</span>
                    )}
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex items-start space-x-2">
                  <Checkbox
                    id="agreeToTerms"
                    checked={formData.agreeToTerms}
                    onCheckedChange={(checked) => onChange("agreeToTerms", checked)}
                    className={cn(errors.agreeToTerms && "border-red-500")}
                  />
                  <div className="grid gap-1.5 leading-none">
                    <Label
                      htmlFor="agreeToTerms"
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      I agree to the terms and conditions <span className="text-red-500">*</span>
                    </Label>
                    <p className="text-sm text-foreground/70">
                      By checking this box, you agree to our{" "}
                      <a href="/terms" className="text-teal-500 hover:underline">
                        Terms of Service
                      </a>{" "}
                      and{" "}
                      <a href="/privacy" className="text-teal-500 hover:underline">
                        Privacy Policy
                      </a>
                      .
                    </p>
                    {errors.agreeToTerms && (
                      <p className="text-red-500 text-sm flex items-center gap-1">
                        <AlertCircle className="h-3 w-3" /> {errors.agreeToTerms}
                      </p>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )

      default:
        return null
    }
  }

  return (
    <div>
      {renderFormStep()}

      <div className="p-6 border-t flex justify-between">
        <Button
          type="button"
          variant="outline"
          onClick={handleBack}
          disabled={currentStep === 0}
          className="flex items-center gap-2"
        >
          <ArrowLeft className="h-4 w-4" /> Back
        </Button>

        {currentStep < steps.length - 1 ? (
          <Button
            type="button"
            onClick={handleNext}
            className="bg-gradient-to-r from-teal-500 to-blue-600 hover:from-teal-600 hover:to-blue-700 flex items-center gap-2"
          >
            Next <ArrowRight className="h-4 w-4" />
          </Button>
        ) : (
          <Button
            type="button"
            onClick={handleSubmitForm}
            disabled={isSubmitting}
            className="bg-gradient-to-r from-teal-500 to-blue-600 hover:from-teal-600 hover:to-blue-700 flex items-center gap-2"
          >
            {isSubmitting ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Submitting...
              </>
            ) : (
              <>Submit Application</>
            )}
          </Button>
        )}
      </div>
    </div>
  )
}

