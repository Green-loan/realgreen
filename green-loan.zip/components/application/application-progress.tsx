"use client"

import { motion } from "framer-motion"
import { Check } from "lucide-react"
import { cn } from "@/lib/utils"

interface Step {
  id: string
  title: string
}

interface ApplicationProgressProps {
  steps: Step[]
  currentStep: number
  onStepClick: (step: number) => void
}

export function ApplicationProgress({ steps, currentStep, onStepClick }: ApplicationProgressProps) {
  return (
    <div className="w-full">
      {/* Desktop progress bar */}
      <div className="hidden md:block">
        <div className="relative">
          {/* Progress line */}
          <div className="absolute top-1/2 left-0 right-0 h-0.5 -translate-y-1/2 bg-border">
            <motion.div
              className="absolute top-0 left-0 h-full bg-gradient-to-r from-teal-500 to-blue-600"
              initial={{ width: "0%" }}
              animate={{ width: `${(currentStep / (steps.length - 1)) * 100}%` }}
              transition={{ duration: 0.3 }}
            />
          </div>

          {/* Steps */}
          <div className="relative flex justify-between">
            {steps.map((step, index) => {
              const isCompleted = index < currentStep
              const isCurrent = index === currentStep
              const isClickable = index <= currentStep

              return (
                <div key={step.id} className="flex flex-col items-center">
                  <button
                    onClick={() => isClickable && onStepClick(index)}
                    disabled={!isClickable}
                    className={cn(
                      "relative z-10 flex h-10 w-10 items-center justify-center rounded-full border-2 transition-all duration-300",
                      isCompleted
                        ? "border-teal-500 bg-teal-500 text-white"
                        : isCurrent
                          ? "border-teal-500 bg-background text-teal-500"
                          : "border-border bg-background text-foreground/40",
                      isClickable ? "cursor-pointer hover:scale-110" : "cursor-not-allowed",
                    )}
                  >
                    {isCompleted ? <Check className="h-5 w-5" /> : <span>{index + 1}</span>}
                  </button>
                  <motion.span
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1, duration: 0.3 }}
                    className={cn(
                      "mt-2 text-sm font-medium",
                      isCurrent ? "text-teal-500" : isCompleted ? "text-foreground" : "text-foreground/40",
                    )}
                  >
                    {step.title}
                  </motion.span>
                </div>
              )
            })}
          </div>
        </div>
      </div>

      {/* Mobile progress */}
      <div className="md:hidden">
        <div className="flex items-center justify-between mb-4">
          <span className="text-sm font-medium">
            Step {currentStep + 1} of {steps.length}
          </span>
          <span className="text-sm font-medium text-teal-500">{steps[currentStep].title}</span>
        </div>
        <div className="h-2 w-full rounded-full bg-border overflow-hidden">
          <motion.div
            className="h-full bg-gradient-to-r from-teal-500 to-blue-600 rounded-full"
            initial={{ width: "0%" }}
            animate={{ width: `${((currentStep + 1) / steps.length) * 100}%` }}
            transition={{ duration: 0.3 }}
          />
        </div>
      </div>
    </div>
  )
}

