import { Bell, CheckCircle2, FileText, MessageSquare } from "lucide-react"

export default function UserNotifications() {
  const notifications = [
    {
      id: 1,
      title: "Application Update",
      description: "Your loan application has been reviewed",
      time: "2 hours ago",
      icon: FileText,
      iconColor: "text-blue-500",
      iconBg: "bg-blue-500/20",
    },
    {
      id: 2,
      title: "Document Verified",
      description: "Your ID document has been verified",
      time: "Yesterday",
      icon: CheckCircle2,
      iconColor: "text-green-500",
      iconBg: "bg-green-500/20",
    },
    {
      id: 3,
      title: "New Message",
      description: "You have a new message from support",
      time: "3 days ago",
      icon: MessageSquare,
      iconColor: "text-purple-500",
      iconBg: "bg-purple-500/20",
    },
  ]

  return (
    <div className="space-y-3">
      {notifications.map((notification) => (
        <div
          key={notification.id}
          className="flex items-start cursor-pointer hover:bg-gray-800/50 p-2 rounded-md transition-colors"
        >
          <div
            className={`flex-shrink-0 h-8 w-8 rounded-full flex items-center justify-center mr-3 ${notification.iconBg}`}
          >
            <notification.icon className={`h-4 w-4 ${notification.iconColor}`} />
          </div>
          <div className="flex-1">
            <div className="text-sm font-medium">{notification.title}</div>
            <div className="text-xs text-gray-400">{notification.description}</div>
            <div className="text-xs text-gray-500 mt-1">{notification.time}</div>
          </div>
        </div>
      ))}

      <div className="pt-2 mt-2 border-t border-gray-700">
        <button className="text-xs text-green-500 hover:text-green-400 flex items-center justify-center w-full">
          <Bell className="h-3 w-3 mr-1" />
          View all notifications
        </button>
      </div>
    </div>
  )
}

