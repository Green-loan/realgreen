"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  Bell,
  Calendar,
  CreditCard,
  DollarSign,
  Download,
  FileText,
  HelpCircle,
  Home,
  Leaf,
  MessageSquare,
  PieChart,
  ArrowUpRight,
  Users,
  TrendingUp,
  Briefcase,
} from "lucide-react"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip as RechartsTooltip,
  ResponsiveContainer,
  PieChart as RechartsPieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  Legend,
} from "recharts"
import UserSidebar from "./user-sidebar"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

export default function UserDashboardOverview() {
  // Mock user data
  const [user] = useState({
    name: "John Doe",
    email: "john.doe@example.com",
    avatar: "/placeholder.svg?height=40&width=40",
  })

  // Mock dashboard data
  const [dashboardData] = useState({
    loanApplications: [
      { id: 1, loan_type: "Solar Panel Installation", amount: 15000, status: "approved", created_at: "2023-10-15" },
      { id: 2, loan_type: "Electric Vehicle", amount: 35000, status: "pending", created_at: "2023-11-02" },
      { id: 3, loan_type: "Home Energy Efficiency", amount: 8000, status: "reviewing", created_at: "2023-11-10" },
    ],
    payments: [
      { id: 1, amount: 1200, payment_date: "2023-10-01", status: "completed" },
      { id: 2, amount: 1200, payment_date: "2023-11-01", status: "completed" },
      { id: 3, amount: 1200, payment_date: "2023-12-01", status: "upcoming" },
    ],
    notifications: [
      {
        id: 1,
        title: "Application Approved",
        message: "Your solar panel loan has been approved!",
        created_at: "2023-10-16",
        type: "success",
      },
      {
        id: 2,
        title: "Document Required",
        message: "Please upload your proof of income.",
        created_at: "2023-11-03",
        type: "warning",
      },
      {
        id: 3,
        title: "Payment Reminder",
        message: "Your next payment is due in 5 days.",
        created_at: "2023-11-25",
        type: "info",
      },
    ],
    stats: {
      totalLoans: 3,
      activeLoans: 1,
      totalRepaid: 2400,
      nextPayment: { payment_date: "2023-12-01", amount: 1200 },
    },
    stokvelMembers: [
      {
        id: 1,
        name: "Sarah Johnson",
        position: "Chairperson",
        contribution: 500,
        nextPayout: "2023-12-15",
        status: "active",
      },
      {
        id: 2,
        name: "Michael Brown",
        position: "Treasurer",
        contribution: 500,
        nextPayout: "2024-01-15",
        status: "active",
      },
      {
        id: 3,
        name: "David Smith",
        position: "Secretary",
        contribution: 500,
        nextPayout: "2024-02-15",
        status: "active",
      },
      {
        id: 4,
        name: "Emily Wilson",
        position: "Member",
        contribution: 500,
        nextPayout: "2024-03-15",
        status: "active",
      },
      { id: 5, name: "John Doe", position: "Member", contribution: 500, nextPayout: "2024-04-15", status: "active" },
    ],
    investments: [
      { id: 1, name: "Green Energy Fund", amount: 10000, returnRate: 8.5, type: "ESG", performance: "+12%" },
      { id: 2, name: "Solar Tech Stocks", amount: 5000, returnRate: 11.2, type: "Equity", performance: "+7.5%" },
      { id: 3, name: "Sustainable Bond", amount: 7500, returnRate: 6.8, type: "Fixed Income", performance: "+4.2%" },
    ],
  })

  // Sample data for charts
  const paymentHistoryData = [
    { month: "Jan", amount: 1200 },
    { month: "Feb", amount: 1200 },
    { month: "Mar", amount: 1200 },
    { month: "Apr", amount: 1200 },
    { month: "May", amount: 1200 },
    { month: "Jun", amount: 0 },
    { month: "Jul", amount: 0 },
  ]

  const loanDistributionData = [
    { name: "Solar", value: 45 },
    { name: "EV", value: 25 },
    { name: "Energy Efficiency", value: 20 },
    { name: "Other", value: 10 },
  ]

  const COLORS = ["#10B981", "#3B82F6", "#6366F1", "#8B5CF6"]

  const environmentalImpactData = [
    { month: "Jan", carbon: 120 },
    { month: "Feb", carbon: 240 },
    { month: "Mar", carbon: 380 },
    { month: "Apr", carbon: 530 },
    { month: "May", carbon: 690 },
    { month: "Jun", carbon: 830 },
    { month: "Jul", carbon: 950 },
  ]

  const investmentPerformanceData = [
    { month: "Jan", returns: 2.1 },
    { month: "Feb", returns: 3.5 },
    { month: "Mar", returns: 2.8 },
    { month: "Apr", returns: 4.2 },
    { month: "May", returns: 5.1 },
    { month: "Jun", returns: 4.8 },
    { month: "Jul", returns: 6.2 },
  ]

  const fadeIn = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 },
  }

  return (
    <div className="flex h-screen overflow-hidden">
      <UserSidebar />

      <div className="flex-1 overflow-y-auto">
        {/* Header */}
        <header className="sticky top-0 z-10 bg-gray-900/80 backdrop-blur-sm border-b border-gray-800 h-16 flex items-center justify-between px-6">
          <div className="flex items-center">
            <h1 className="text-xl font-bold text-white">Dashboard</h1>
          </div>

          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="icon" className="relative text-gray-400 hover:text-white">
              <Bell className="h-5 w-5" />
              <span className="absolute top-0 right-0 h-2 w-2 rounded-full bg-red-500"></span>
            </Button>

            <Button variant="ghost" size="icon" className="text-gray-400 hover:text-white">
              <MessageSquare className="h-5 w-5" />
            </Button>

            <div className="flex items-center space-x-2">
              <Avatar>
                <AvatarImage src={user.avatar} alt={user.name} />
                <AvatarFallback>JD</AvatarFallback>
              </Avatar>
              <div className="hidden md:block">
                <p className="text-sm font-medium text-white">{user.name}</p>
                <p className="text-xs text-gray-400">{user.email}</p>
              </div>
            </div>
          </div>
        </header>

        {/* Main content */}
        <main className="p-6">
          <motion.div
            className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6"
            initial="hidden"
            animate="visible"
            variants={{
              visible: {
                transition: {
                  staggerChildren: 0.1,
                },
              },
            }}
          >
            <motion.div variants={fadeIn}>
              <Card className="bg-gray-800/50 border-gray-700 backdrop-blur-sm overflow-hidden relative">
                <CardHeader className="pb-2">
                  <CardDescription className="text-gray-400">Total Loan Amount</CardDescription>
                  <CardTitle className="text-2xl font-bold text-white">$58,000</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center text-sm text-green-400">
                    <ArrowUpRight className="h-4 w-4 mr-1" />
                    <span>+12% from last month</span>
                  </div>
                  <div className="absolute bottom-0 right-0 h-16 w-16 opacity-10">
                    <DollarSign className="h-full w-full" />
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div variants={fadeIn}>
              <Card className="bg-gray-800/50 border-gray-700 backdrop-blur-sm overflow-hidden relative">
                <CardHeader className="pb-2">
                  <CardDescription className="text-gray-400">Monthly Payment</CardDescription>
                  <CardTitle className="text-2xl font-bold text-white">$1,200</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center text-sm text-gray-400">
                    <Calendar className="h-4 w-4 mr-1" />
                    <span>Next payment: Dec 1, 2023</span>
                  </div>
                  <div className="absolute bottom-0 right-0 h-16 w-16 opacity-10">
                    <CreditCard className="h-full w-full" />
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div variants={fadeIn}>
              <Card className="bg-gray-800/50 border-gray-700 backdrop-blur-sm overflow-hidden relative">
                <CardHeader className="pb-2">
                  <CardDescription className="text-gray-400">Carbon Offset</CardDescription>
                  <CardTitle className="text-2xl font-bold text-white">950 kg</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center text-sm text-green-400">
                    <ArrowUpRight className="h-4 w-4 mr-1" />
                    <span>+120 kg this month</span>
                  </div>
                  <div className="absolute bottom-0 right-0 h-16 w-16 opacity-10">
                    <Leaf className="h-full w-full" />
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </motion.div>

          <motion.div
            className="mb-6"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            <Card className="bg-gray-800/50 border-gray-700 backdrop-blur-sm">
              <CardHeader>
                <CardTitle>Loan Application Status</CardTitle>
                <CardDescription>Track the progress of your loan applications</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {dashboardData.loanApplications.map((application) => (
                    <div key={application.id} className="space-y-2">
                      <div className="flex justify-between items-center">
                        <div>
                          <h3 className="font-medium text-white">{application.loan_type}</h3>
                          <p className="text-sm text-gray-400">${application.amount.toLocaleString()}</p>
                        </div>
                        <Badge
                          className={
                            application.status === "approved"
                              ? "bg-green-500/20 text-green-400 hover:bg-green-500/30"
                              : application.status === "pending"
                                ? "bg-yellow-500/20 text-yellow-400 hover:bg-yellow-500/30"
                                : "bg-blue-500/20 text-blue-400 hover:bg-blue-500/30"
                          }
                        >
                          {application.status.charAt(0).toUpperCase() + application.status.slice(1)}
                        </Badge>
                      </div>

                      <div className="space-y-1">
                        <div className="flex justify-between text-xs text-gray-400">
                          <span>Application</span>
                          <span>Verification</span>
                          <span>Review</span>
                          <span>Decision</span>
                          <span>Funding</span>
                        </div>
                        <Progress
                          value={
                            application.status === "approved"
                              ? 100
                              : application.status === "reviewing"
                                ? 60
                                : application.status === "pending"
                                  ? 40
                                  : 20
                          }
                          className="h-2 bg-gray-700"
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
            <Tabs defaultValue="overview" className="space-y-4">
              <TabsList className="bg-gray-800/50 border border-gray-700">
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="loans">Loans</TabsTrigger>
                <TabsTrigger value="stokvel">Stokvel</TabsTrigger>
                <TabsTrigger value="investments">Investments</TabsTrigger>
                <TabsTrigger value="impact">Environmental Impact</TabsTrigger>
              </TabsList>

              <TabsContent value="overview" className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Card className="bg-gray-800/50 border-gray-700 backdrop-blur-sm">
                    <CardHeader>
                      <CardTitle>Loan Distribution</CardTitle>
                      <CardDescription>Breakdown of your green loans by category</CardDescription>
                    </CardHeader>
                    <CardContent className="flex justify-center">
                      <div className="h-64 w-full max-w-md">
                        <ResponsiveContainer width="100%" height="100%">
                          <RechartsPieChart>
                            <Pie
                              data={loanDistributionData}
                              cx="50%"
                              cy="50%"
                              innerRadius={60}
                              outerRadius={80}
                              paddingAngle={5}
                              dataKey="value"
                              label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                              labelLine={false}
                            >
                              {loanDistributionData.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                              ))}
                            </Pie>
                            <Legend />
                          </RechartsPieChart>
                        </ResponsiveContainer>
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="bg-gray-800/50 border-gray-700 backdrop-blur-sm">
                    <CardHeader>
                      <CardTitle>Recent Activity</CardTitle>
                      <CardDescription>Latest updates on your account</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {dashboardData.notifications.map((notification) => (
                          <div key={notification.id} className="flex items-start space-x-4">
                            <div
                              className={`mt-0.5 rounded-full p-1.5 
                              ${
                                notification.type === "success"
                                  ? "bg-green-500/20 text-green-400"
                                  : notification.type === "warning"
                                    ? "bg-yellow-500/20 text-yellow-400"
                                    : "bg-blue-500/20 text-blue-400"
                              }`}
                            >
                              {notification.type === "success" ? (
                                <FileText className="h-4 w-4" />
                              ) : notification.type === "warning" ? (
                                <HelpCircle className="h-4 w-4" />
                              ) : (
                                <Bell className="h-4 w-4" />
                              )}
                            </div>
                            <div className="space-y-1">
                              <p className="text-sm font-medium text-white">{notification.title}</p>
                              <p className="text-xs text-gray-400">{notification.message}</p>
                              <p className="text-xs text-gray-500">
                                {new Date(notification.created_at).toLocaleDateString()}
                              </p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </div>

                <Card className="bg-gray-800/50 border-gray-700 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle>Quick Actions</CardTitle>
                    <CardDescription>Common tasks you might want to perform</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <Button
                        variant="outline"
                        className="h-auto flex flex-col items-center justify-center p-4 space-y-2 border-gray-700 hover:bg-gray-700/50"
                      >
                        <FileText className="h-6 w-6" />
                        <span className="text-xs">New Application</span>
                      </Button>
                      <Button
                        variant="outline"
                        className="h-auto flex flex-col items-center justify-center p-4 space-y-2 border-gray-700 hover:bg-gray-700/50"
                      >
                        <CreditCard className="h-6 w-6" />
                        <span className="text-xs">Make Payment</span>
                      </Button>
                      <Button
                        variant="outline"
                        className="h-auto flex flex-col items-center justify-center p-4 space-y-2 border-gray-700 hover:bg-gray-700/50"
                      >
                        <Download className="h-6 w-6" />
                        <span className="text-xs">Download Statement</span>
                      </Button>
                      <Button
                        variant="outline"
                        className="h-auto flex flex-col items-center justify-center p-4 space-y-2 border-gray-700 hover:bg-gray-700/50"
                      >
                        <MessageSquare className="h-6 w-6" />
                        <span className="text-xs">Contact Support</span>
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="loans" className="space-y-4">
                <Card className="bg-gray-800/50 border-gray-700 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle>Your Loans</CardTitle>
                    <CardDescription>All your active and pending loan applications</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Table>
                      <TableHeader>
                        <TableRow className="border-gray-700">
                          <TableHead>Loan Type</TableHead>
                          <TableHead>Amount</TableHead>
                          <TableHead>Application Date</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {dashboardData.loanApplications.map((loan) => (
                          <TableRow key={loan.id} className="border-gray-700">
                            <TableCell className="font-medium">{loan.loan_type}</TableCell>
                            <TableCell>${loan.amount.toLocaleString()}</TableCell>
                            <TableCell>{new Date(loan.created_at).toLocaleDateString()}</TableCell>
                            <TableCell>
                              <Badge
                                className={
                                  loan.status === "approved"
                                    ? "bg-green-500/20 text-green-400 hover:bg-green-500/30"
                                    : loan.status === "pending"
                                      ? "bg-yellow-500/20 text-yellow-400 hover:bg-yellow-500/30"
                                      : "bg-blue-500/20 text-blue-400 hover:bg-blue-500/30"
                                }
                              >
                                {loan.status.charAt(0).toUpperCase() + loan.status.slice(1)}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <Button variant="outline" size="sm" className="border-gray-700 hover:bg-gray-700/50">
                                View Details
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>

                    <div className="mt-6">
                      <Button className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700">
                        Apply for New Loan
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-gray-800/50 border-gray-700 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle>Payment Schedule</CardTitle>
                    <CardDescription>Upcoming and recent loan payments</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <h3 className="text-lg font-medium text-white">Upcoming Payments</h3>
                      <div className="space-y-2">
                        {dashboardData.payments
                          .filter((p) => p.status === "upcoming")
                          .map((payment) => (
                            <Card key={payment.id} className="bg-gray-700/50 border-gray-600">
                              <CardContent className="p-4 flex justify-between items-center">
                                <div>
                                  <p className="font-medium text-white">Monthly Payment</p>
                                  <p className="text-sm text-gray-400">
                                    Due on {new Date(payment.payment_date).toLocaleDateString()}
                                  </p>
                                </div>
                                <div className="text-right">
                                  <p className="font-bold text-white">${payment.amount}</p>
                                  <Button size="sm" className="mt-2 bg-green-600 hover:bg-green-700">
                                    Pay Now
                                  </Button>
                                </div>
                              </CardContent>
                            </Card>
                          ))}
                      </div>

                      <h3 className="text-lg font-medium text-white mt-6">Payment History</h3>
                      <div className="h-64">
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart data={paymentHistoryData}>
                            <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                            <XAxis dataKey="month" stroke="#9CA3AF" />
                            <YAxis stroke="#9CA3AF" />
                            <RechartsTooltip
                              contentStyle={{ backgroundColor: "#1F2937", borderColor: "#374151" }}
                              itemStyle={{ color: "#E5E7EB" }}
                              formatter={(value) => [`$${value}`, "Amount"]}
                            />
                            <Bar dataKey="amount" fill="#10B981" radius={[4, 4, 0, 0]} />
                          </BarChart>
                        </ResponsiveContainer>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="stokvel" className="space-y-4">
                <Card className="bg-gray-800/50 border-gray-700 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle>Stokvel Membership</CardTitle>
                    <CardDescription>Your rotating savings club details</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                      <Card className="bg-gray-700/50 border-gray-600">
                        <CardContent className="p-4 text-center">
                          <Users className="h-8 w-8 mx-auto mb-2 text-blue-400" />
                          <p className="text-2xl font-bold text-white">5</p>
                          <p className="text-sm text-gray-400">Total Members</p>
                        </CardContent>
                      </Card>

                      <Card className="bg-gray-700/50 border-gray-600">
                        <CardContent className="p-4 text-center">
                          <DollarSign className="h-8 w-8 mx-auto mb-2 text-green-400" />
                          <p className="text-2xl font-bold text-white">$2,500</p>
                          <p className="text-sm text-gray-400">Monthly Pool</p>
                        </CardContent>
                      </Card>

                      <Card className="bg-gray-700/50 border-gray-600">
                        <CardContent className="p-4 text-center">
                          <Calendar className="h-8 w-8 mx-auto mb-2 text-purple-400" />
                          <p className="text-2xl font-bold text-white">Apr 15, 2024</p>
                          <p className="text-sm text-gray-400">Your Payout Date</p>
                        </CardContent>
                      </Card>
                    </div>

                    <h3 className="text-lg font-medium text-white mb-4">Member List</h3>
                    <Table>
                      <TableHeader>
                        <TableRow className="border-gray-700">
                          <TableHead>Name</TableHead>
                          <TableHead>Position</TableHead>
                          <TableHead>Contribution</TableHead>
                          <TableHead>Next Payout</TableHead>
                          <TableHead>Status</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {dashboardData.stokvelMembers.map((member) => (
                          <TableRow key={member.id} className="border-gray-700">
                            <TableCell className="font-medium">{member.name}</TableCell>
                            <TableCell>{member.position}</TableCell>
                            <TableCell>${member.contribution}</TableCell>
                            <TableCell>{new Date(member.nextPayout).toLocaleDateString()}</TableCell>
                            <TableCell>
                              <Badge
                                className={
                                  member.status === "active"
                                    ? "bg-green-500/20 text-green-400 hover:bg-green-500/30"
                                    : "bg-yellow-500/20 text-yellow-400 hover:bg-yellow-500/30"
                                }
                              >
                                {member.status.charAt(0).toUpperCase() + member.status.slice(1)}
                              </Badge>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>

                    <div className="mt-6 space-y-4">
                      <h3 className="text-lg font-medium text-white">Stokvel Rules</h3>
                      <div className="space-y-2 text-gray-400">
                        <p>• Monthly contributions of $500 are due by the 5th of each month</p>
                        <p>• Payouts are distributed on the 15th of each month</p>
                        <p>• Members receive payouts in the order listed above</p>
                        <p>• Missing a payment will result in penalties and possible removal</p>
                        <p>• New members can only join at the beginning of a new cycle</p>
                      </div>

                      <div className="flex space-x-4 mt-4">
                        <Button variant="outline" className="border-gray-700 hover:bg-gray-700/50">
                          View Full Rules
                        </Button>
                        <Button className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700">
                          Make Contribution
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="investments" className="space-y-4">
                <Card className="bg-gray-800/50 border-gray-700 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle>Investment Portfolio</CardTitle>
                    <CardDescription>Your green investment performance</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                      <Card className="bg-gray-700/50 border-gray-600">
                        <CardContent className="p-4 text-center">
                          <Briefcase className="h-8 w-8 mx-auto mb-2 text-blue-400" />
                          <p className="text-2xl font-bold text-white">$22,500</p>
                          <p className="text-sm text-gray-400">Total Invested</p>
                        </CardContent>
                      </Card>

                      <Card className="bg-gray-700/50 border-gray-600">
                        <CardContent className="p-4 text-center">
                          <TrendingUp className="h-8 w-8 mx-auto mb-2 text-green-400" />
                          <p className="text-2xl font-bold text-white">8.7%</p>
                          <p className="text-sm text-gray-400">Average Return</p>
                        </CardContent>
                      </Card>

                      <Card className="bg-gray-700/50 border-gray-600">
                        <CardContent className="p-4 text-center">
                          <Leaf className="h-8 w-8 mx-auto mb-2 text-emerald-400" />
                          <p className="text-2xl font-bold text-white">100%</p>
                          <p className="text-sm text-gray-400">Sustainable Investments</p>
                        </CardContent>
                      </Card>
                    </div>

                    <h3 className="text-lg font-medium text-white mb-4">Investment Performance</h3>
                    <div className="h-64 mb-6">
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart data={investmentPerformanceData}>
                          <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                          <XAxis dataKey="month" stroke="#9CA3AF" />
                          <YAxis stroke="#9CA3AF" />
                          <RechartsTooltip
                            contentStyle={{ backgroundColor: "#1F2937", borderColor: "#374151" }}
                            itemStyle={{ color: "#E5E7EB" }}
                            formatter={(value) => [`${value}%`, "Returns"]}
                          />
                          <Line
                            type="monotone"
                            dataKey="returns"
                            stroke="#10B981"
                            strokeWidth={2}
                            dot={{ fill: "#10B981", strokeWidth: 2 }}
                            activeDot={{ r: 8 }}
                          />
                        </LineChart>
                      </ResponsiveContainer>
                    </div>

                    <h3 className="text-lg font-medium text-white mb-4">Your Investments</h3>
                    <Table>
                      <TableHeader>
                        <TableRow className="border-gray-700">
                          <TableHead>Investment</TableHead>
                          <TableHead>Amount</TableHead>
                          <TableHead>Return Rate</TableHead>
                          <TableHead>Type</TableHead>
                          <TableHead>Performance</TableHead>
                          <TableHead>Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {dashboardData.investments.map((investment) => (
                          <TableRow key={investment.id} className="border-gray-700">
                            <TableCell className="font-medium">{investment.name}</TableCell>
                            <TableCell>${investment.amount.toLocaleString()}</TableCell>
                            <TableCell>{investment.returnRate}%</TableCell>
                            <TableCell>{investment.type}</TableCell>
                            <TableCell className="text-green-400">{investment.performance}</TableCell>
                            <TableCell>
                              <Button variant="outline" size="sm" className="border-gray-700 hover:bg-gray-700/50">
                                View Details
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>

                    <div className="mt-6">
                      <Button className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700">
                        Add New Investment
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="impact" className="space-y-4">
                <Card className="bg-gray-800/50 border-gray-700 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle>Environmental Impact</CardTitle>
                    <CardDescription>Track your contribution to a greener planet</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-80">
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart data={environmentalImpactData}>
                          <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                          <XAxis dataKey="month" stroke="#9CA3AF" />
                          <YAxis stroke="#9CA3AF" />
                          <RechartsTooltip
                            contentStyle={{ backgroundColor: "#1F2937", borderColor: "#374151" }}
                            itemStyle={{ color: "#E5E7EB" }}
                            formatter={(value) => [`${value} kg`, "Carbon Offset"]}
                          />
                          <Line
                            type="monotone"
                            dataKey="carbon"
                            stroke="#10B981"
                            strokeWidth={2}
                            dot={{ fill: "#10B981", strokeWidth: 2 }}
                            activeDot={{ r: 8 }}
                          />
                        </LineChart>
                      </ResponsiveContainer>
                    </div>

                    <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
                      <Card className="bg-gray-700/50 border-gray-600">
                        <CardContent className="p-4 text-center">
                          <Leaf className="h-8 w-8 mx-auto mb-2 text-green-400" />
                          <p className="text-2xl font-bold text-white">950 kg</p>
                          <p className="text-sm text-gray-400">Carbon Offset</p>
                        </CardContent>
                      </Card>

                      <Card className="bg-gray-700/50 border-gray-600">
                        <CardContent className="p-4 text-center">
                          <Home className="h-8 w-8 mx-auto mb-2 text-blue-400" />
                          <p className="text-2xl font-bold text-white">15,000 kWh</p>
                          <p className="text-sm text-gray-400">Clean Energy Generated</p>
                        </CardContent>
                      </Card>

                      <Card className="bg-gray-700/50 border-gray-600">
                        <CardContent className="p-4 text-center">
                          <PieChart className="h-8 w-8 mx-auto mb-2 text-purple-400" />
                          <p className="text-2xl font-bold text-white">42</p>
                          <p className="text-sm text-gray-400">Trees Equivalent</p>
                        </CardContent>
                      </Card>
                    </div>

                    <div className="mt-6">
                      <h3 className="text-lg font-medium text-white mb-4">Impact Breakdown</h3>
                      <div className="space-y-4">
                        <div className="space-y-2">
                          <div className="flex justify-between items-center">
                            <p className="text-sm text-white">Solar Panel Installation</p>
                            <p className="text-sm font-medium text-white">650 kg CO₂</p>
                          </div>
                          <Progress value={68} className="h-2 bg-gray-700" />
                        </div>

                        <div className="space-y-2">
                          <div className="flex justify-between items-center">
                            <p className="text-sm text-white">Electric Vehicle</p>
                            <p className="text-sm font-medium text-white">250 kg CO₂</p>
                          </div>
                          <Progress value={26} className="h-2 bg-gray-700" />
                        </div>

                        <div className="space-y-2">
                          <div className="flex justify-between items-center">
                            <p className="text-sm text-white">Home Energy Efficiency</p>
                            <p className="text-sm font-medium text-white">50 kg CO₂</p>
                          </div>
                          <Progress value={6} className="h-2 bg-gray-700" />
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </motion.div>
        </main>
      </div>
    </div>
  )
}

