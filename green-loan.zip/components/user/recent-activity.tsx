import { CheckCircle2, FileText, Upload, MessageSquare, AlertCircle } from "lucide-react"

export default function RecentActivity() {
  const activities = [
    {
      id: 1,
      type: "document",
      title: "ID Document Uploaded",
      description: "You uploaded your ID document",
      time: "Today, 10:30 AM",
      icon: Upload,
      iconColor: "text-blue-500",
      iconBg: "bg-blue-500/20",
    },
    {
      id: 2,
      type: "verification",
      title: "Bank Statement Verified",
      description: "Your bank statement was verified successfully",
      time: "Yesterday, 2:45 PM",
      icon: CheckCircle2,
      iconColor: "text-green-500",
      iconBg: "bg-green-500/20",
    },
    {
      id: 3,
      type: "application",
      title: "Loan Application Updated",
      description: "Your loan application status was updated",
      time: "Yesterday, 11:20 AM",
      icon: FileText,
      iconColor: "text-amber-500",
      iconBg: "bg-amber-500/20",
    },
    {
      id: 4,
      type: "message",
      title: "New Message Received",
      description: "You received a message from the loan officer",
      time: "Jun 12, 2023",
      icon: MessageSquare,
      iconColor: "text-purple-500",
      iconBg: "bg-purple-500/20",
    },
    {
      id: 5,
      type: "alert",
      title: "Missing Document",
      description: "Please upload your proof of residence",
      time: "Jun 10, 2023",
      icon: AlertCircle,
      iconColor: "text-red-500",
      iconBg: "bg-red-500/20",
    },
  ]

  return (
    <div className="space-y-4">
      {activities.map((activity) => (
        <div key={activity.id} className="flex items-start">
          <div
            className={`flex-shrink-0 h-8 w-8 rounded-full flex items-center justify-center mr-3 ${activity.iconBg}`}
          >
            <activity.icon className={`h-4 w-4 ${activity.iconColor}`} />
          </div>
          <div className="flex-1">
            <div className="flex items-center justify-between">
              <div className="text-sm font-medium">{activity.title}</div>
              <div className="text-xs text-gray-500">{activity.time}</div>
            </div>
            <div className="text-xs text-gray-400 mt-1">{activity.description}</div>
          </div>
        </div>
      ))}
    </div>
  )
}

