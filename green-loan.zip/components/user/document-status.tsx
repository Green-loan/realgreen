import { CheckCircle2, Clock, XCircle } from "lucide-react"

export default function DocumentStatus() {
  const documents = [
    {
      id: 1,
      name: "ID Document",
      status: "verified",
      icon: CheckCircle2,
      iconColor: "text-green-500",
    },
    {
      id: 2,
      name: "Bank Statements",
      status: "verified",
      icon: CheckCircle2,
      iconColor: "text-green-500",
    },
    {
      id: 3,
      name: "Proof of Income",
      status: "pending",
      icon: Clock,
      iconColor: "text-amber-500",
    },
    {
      id: 4,
      name: "Proof of Residence",
      status: "missing",
      icon: XCircle,
      iconColor: "text-red-500",
    },
  ]

  return (
    <div className="space-y-3">
      {documents.map((doc) => (
        <div key={doc.id} className="flex items-center justify-between">
          <div className="text-sm">{doc.name}</div>
          <div className="flex items-center">
            <doc.icon className={`h-4 w-4 ${doc.iconColor} mr-1`} />
            <span className="text-xs capitalize">{doc.status}</span>
          </div>
        </div>
      ))}
    </div>
  )
}

