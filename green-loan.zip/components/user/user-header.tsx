"use client"

import { cn } from "@/lib/utils"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ThemeToggle } from "@/components/theme-toggle"
import { Bell } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Badge } from "@/components/ui/badge"

export function UserHeader() {
  return (
    <header className="fixed top-0 z-40 w-full border-b border-white/10 bg-black/60 backdrop-blur-md">
      <div className="flex h-16 items-center justify-between px-4 md:px-6">
        <div className="flex items-center gap-2 md:gap-4">
          <Link href="/dashboard" className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-full bg-gradient-to-br from-green-400 to-blue-600" />
            <span className="font-semibold text-lg hidden md:inline-flex">GreenFina</span>
          </Link>
        </div>
        <div className="flex items-center gap-2">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="relative">
                <Bell className="h-5 w-5" />
                <span className="absolute top-1 right-1 flex h-2 w-2 items-center justify-center rounded-full bg-green-500 text-xs font-medium" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-80 bg-black/90 backdrop-blur-md border-white/10">
              <DropdownMenuLabel>Notifications</DropdownMenuLabel>
              <DropdownMenuSeparator className="bg-white/10" />
              {[
                {
                  title: "Loan payment due",
                  description: "Your loan payment of R2,500 is due in 3 days",
                  time: "Just now",
                  type: "payment",
                },
                {
                  title: "Loan application update",
                  description: "Your loan application has been approved",
                  time: "2 hours ago",
                  type: "application",
                },
                {
                  title: "Stokvel payout",
                  description: "Your stokvel group has a payout scheduled next week",
                  time: "1 day ago",
                  type: "stokvel",
                },
              ].map((notification, i) => (
                <DropdownMenuItem key={i} className="flex flex-col items-start p-4 gap-1 cursor-pointer">
                  <div className="flex items-center gap-2">
                    <span className="font-medium">{notification.title}</span>
                    <Badge
                      variant="outline"
                      className={cn(
                        "ml-auto",
                        notification.type === "payment"
                          ? "bg-amber-500/10 text-amber-500 border-amber-500/20"
                          : notification.type === "application"
                            ? "bg-green-500/10 text-green-500 border-green-500/20"
                            : "bg-blue-500/10 text-blue-500 border-blue-500/20",
                      )}
                    >
                      {notification.type}
                    </Badge>
                  </div>
                  <p className="text-sm text-muted-foreground">{notification.description}</p>
                  <p className="text-xs text-muted-foreground mt-1">{notification.time}</p>
                </DropdownMenuItem>
              ))}
              <DropdownMenuItem className="flex justify-center p-2 cursor-pointer">
                <Button variant="ghost" className="w-full text-center text-sm">
                  View all notifications
                </Button>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          <ThemeToggle />
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="rounded-full">
                <Avatar className="h-8 w-8">
                  <AvatarImage src="/placeholder.svg?height=32&width=32" alt="User" />
                  <AvatarFallback className="bg-green-500/20 text-green-500">JD</AvatarFallback>
                </Avatar>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="bg-black/90 backdrop-blur-md border-white/10">
              <DropdownMenuLabel>My Account</DropdownMenuLabel>
              <DropdownMenuSeparator className="bg-white/10" />
              <DropdownMenuItem>Profile</DropdownMenuItem>
              <DropdownMenuItem>Settings</DropdownMenuItem>
              <DropdownMenuSeparator className="bg-white/10" />
              <DropdownMenuItem>Log out</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  )
}

