"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { LayoutDashboard, FileText, Users2, CreditCard, Leaf, Bell, Settings, LogOut, History } from "lucide-react"

export function UserSidebar() {
  const pathname = usePathname()

  const navItems = [
    {
      title: "Dashboard",
      href: "/dashboard",
      icon: LayoutDashboard,
    },
    {
      title: "Loan Applications",
      href: "/dashboard/applications",
      icon: FileText,
    },
    {
      title: "Stokvel Groups",
      href: "/dashboard/stokvel",
      icon: Users2,
    },
    {
      title: "Payments",
      href: "/dashboard/payments",
      icon: CreditCard,
    },
    {
      title: "Loan History",
      href: "/dashboard/history",
      icon: History,
    },
    {
      title: "Environmental Impact",
      href: "/dashboard/impact",
      icon: Leaf,
    },
    {
      title: "Notifications",
      href: "/dashboard/notifications",
      icon: Bell,
    },
    {
      title: "Settings",
      href: "/dashboard/settings",
      icon: Settings,
    },
  ]

  return (
    <div className="fixed inset-y-0 left-0 z-20 hidden w-64 flex-col border-r border-white/10 bg-black/60 backdrop-blur-md pt-16 md:flex">
      <ScrollArea className="flex-1">
        <div className="flex flex-col gap-2 p-4">
          {navItems.map((item) => {
            const isActive = pathname === item.href || pathname?.startsWith(`${item.href}/`)
            return (
              <Button
                key={item.href}
                asChild
                variant="ghost"
                className={cn(
                  "justify-start gap-2 h-12",
                  isActive
                    ? "bg-gradient-to-r from-green-500/20 to-blue-500/20 text-white border-l-2 border-green-500"
                    : "text-muted-foreground hover:bg-white/5",
                )}
              >
                <Link href={item.href}>
                  <item.icon className="h-5 w-5" />
                  <span>{item.title}</span>
                  {item.title === "Notifications" && (
                    <span className="ml-auto flex h-6 w-6 items-center justify-center rounded-full bg-green-500/20 text-xs font-medium text-green-500">
                      3
                    </span>
                  )}
                </Link>
              </Button>
            )
          })}
        </div>
      </ScrollArea>
      <div className="border-t border-white/10 p-4">
        <Button variant="ghost" className="w-full justify-start gap-2 text-muted-foreground hover:bg-white/5">
          <LogOut className="h-5 w-5" />
          <span>Log out</span>
        </Button>
      </div>
    </div>
  )
}

