import { CheckCircle2, Clock, FileText } from "lucide-react"
import { Progress } from "@/components/ui/progress"

export default function LoanApplicationStatus() {
  const steps = [
    { id: 1, name: "Application Submitted", status: "complete", icon: FileText },
    { id: 2, name: "Document Verification", status: "complete", icon: CheckCircle2 },
    { id: 3, name: "Credit Assessment", status: "current", icon: Clock },
    { id: 4, name: "Final Approval", status: "upcoming", icon: CheckCircle2 },
  ]

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between mb-2">
        <div className="text-sm font-medium">Application #GF-2023-1234</div>
        <div className="text-xs px-2 py-1 rounded-full bg-amber-500/20 text-amber-400">In Progress</div>
      </div>

      <Progress value={75} className="h-2" />

      <div className="space-y-3 mt-4">
        {steps.map((step) => (
          <div key={step.id} className="flex items-start">
            <div
              className={`
              flex-shrink-0 h-6 w-6 rounded-full flex items-center justify-center mr-3
              ${
                step.status === "complete"
                  ? "bg-green-500/20 text-green-500"
                  : step.status === "current"
                    ? "bg-amber-500/20 text-amber-500"
                    : "bg-gray-700/50 text-gray-500"
              }
            `}
            >
              <step.icon className="h-4 w-4" />
            </div>
            <div>
              <div className="text-sm font-medium">{step.name}</div>
              <div className="text-xs text-gray-400">
                {step.status === "complete" ? "Completed" : step.status === "current" ? "In Progress" : "Pending"}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

