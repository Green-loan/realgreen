"use client"

import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from "recharts"

export default function FinancialOverview() {
  const data = [
    { name: "Income", value: 25000, color: "#10b981" },
    { name: "Expenses", value: 15000, color: "#f59e0b" },
    { name: "Debt", value: 8000, color: "#ef4444" },
  ]

  return (
    <div className="space-y-4">
      <div className="h-32">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie data={data} cx="50%" cy="50%" innerRadius={30} outerRadius={60} paddingAngle={5} dataKey="value">
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.color} />
              ))}
            </Pie>
            <Tooltip
              contentStyle={{ backgroundColor: "#1f2937", border: "none", borderRadius: "0.5rem", color: "white" }}
              formatter={(value) => [`R${value}`, ""]}
            />
          </PieChart>
        </ResponsiveContainer>
      </div>

      <div className="grid grid-cols-3 gap-2">
        {data.map((item) => (
          <div key={item.name} className="text-center">
            <div className="text-xs text-gray-400">{item.name}</div>
            <div className="text-sm font-medium">R{item.value.toLocaleString()}</div>
            <div className="h-1 w-full mt-1 rounded-full" style={{ backgroundColor: item.color }}></div>
          </div>
        ))}
      </div>

      <div className="text-xs text-center text-gray-400 mt-2">Debt-to-Income Ratio: 32%</div>
    </div>
  )
}

