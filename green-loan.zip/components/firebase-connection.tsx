"use client"

import { useState } from "react"
import { db, rtdb } from "@/lib/firebase"
import { collection, addDoc, getDocs } from "firebase/firestore"
import { ref, set, onValue } from "firebase/database"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { CheckCircle, XCircle } from "lucide-react"

export default function FirebaseConnection() {
  const [firestoreStatus, setFirestoreStatus] = useState<"idle" | "loading" | "success" | "error">("idle")
  const [realtimeStatus, setRealtimeStatus] = useState<"idle" | "loading" | "success" | "error">("idle")
  const [firestoreMessage, setFirestoreMessage] = useState<string>("")
  const [realtimeMessage, setRealtimeMessage] = useState<string>("")

  const testFirestore = async () => {
    if (!db) {
      setFirestoreStatus("error")
      setFirestoreMessage("Firestore is not initialized")
      return
    }

    setFirestoreStatus("loading")
    try {
      // Write a test document
      const testCollection = collection(db, "connection_tests")
      const docRef = await addDoc(testCollection, {
        timestamp: new Date().toISOString(),
        message: "Connection test successful",
      })

      // Read documents to verify connection
      const querySnapshot = await getDocs(testCollection)
      const docsCount = querySnapshot.size

      setFirestoreStatus("success")
      setFirestoreMessage(
        `Connected successfully! Added document with ID: ${docRef.id}. Collection has ${docsCount} documents.`,
      )
    } catch (error) {
      console.error("Firestore test error:", error)
      setFirestoreStatus("error")
      setFirestoreMessage(`Error: ${error instanceof Error ? error.message : "Unknown error"}`)
    }
  }

  const testRealtimeDB = async () => {
    if (!rtdb) {
      setRealtimeStatus("error")
      setRealtimeMessage("Realtime Database is not initialized")
      return
    }

    setRealtimeStatus("loading")
    try {
      // Write test data
      const testRef = ref(rtdb, "connection_tests/" + Date.now())
      await set(testRef, {
        timestamp: new Date().toISOString(),
        message: "Connection test successful",
      })

      // Read data to verify connection
      onValue(
        testRef,
        (snapshot) => {
          const data = snapshot.val()
          setRealtimeStatus("success")
          setRealtimeMessage(`Connected successfully! Data: ${JSON.stringify(data)}`)
        },
        {
          onlyOnce: true,
        },
      )
    } catch (error) {
      console.error("Realtime DB test error:", error)
      setRealtimeStatus("error")
      setRealtimeMessage(`Error: ${error instanceof Error ? error.message : "Unknown error"}`)
    }
  }

  return (
    <Card className="w-full max-w-lg">
      <CardHeader>
        <CardTitle>Firebase Connection Test</CardTitle>
        <CardDescription>Test your Firebase connection using the exact configuration you provided</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <h3 className="text-lg font-medium">Firestore Status</h3>
          {firestoreStatus === "success" && (
            <Alert className="bg-green-50 border-green-200">
              <CheckCircle className="h-4 w-4 text-green-500" />
              <AlertTitle>Success</AlertTitle>
              <AlertDescription>{firestoreMessage}</AlertDescription>
            </Alert>
          )}
          {firestoreStatus === "error" && (
            <Alert className="bg-red-50 border-red-200">
              <XCircle className="h-4 w-4 text-red-500" />
              <AlertTitle>Error</AlertTitle>
              <AlertDescription>{firestoreMessage}</AlertDescription>
            </Alert>
          )}
          {firestoreStatus === "idle" && (
            <p className="text-sm text-gray-500">Click the button below to test Firestore connection</p>
          )}
          {firestoreStatus === "loading" && <p className="text-sm text-gray-500">Testing Firestore connection...</p>}
        </div>

        <div className="space-y-2">
          <h3 className="text-lg font-medium">Realtime Database Status</h3>
          {realtimeStatus === "success" && (
            <Alert className="bg-green-50 border-green-200">
              <CheckCircle className="h-4 w-4 text-green-500" />
              <AlertTitle>Success</AlertTitle>
              <AlertDescription>{realtimeMessage}</AlertDescription>
            </Alert>
          )}
          {realtimeStatus === "error" && (
            <Alert className="bg-red-50 border-red-200">
              <XCircle className="h-4 w-4 text-red-500" />
              <AlertTitle>Error</AlertTitle>
              <AlertDescription>{realtimeMessage}</AlertDescription>
            </Alert>
          )}
          {realtimeStatus === "idle" && (
            <p className="text-sm text-gray-500">Click the button below to test Realtime Database connection</p>
          )}
          {realtimeStatus === "loading" && (
            <p className="text-sm text-gray-500">Testing Realtime Database connection...</p>
          )}
        </div>
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button onClick={testFirestore} disabled={firestoreStatus === "loading"}>
          Test Firestore
        </Button>
        <Button onClick={testRealtimeDB} disabled={realtimeStatus === "loading"}>
          Test Realtime DB
        </Button>
      </CardFooter>
    </Card>
  )
}

