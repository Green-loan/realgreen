"use client"

import type React from "react"

import { useState } from "react"
import { motion } from "framer-motion"
import { LandingNavbar } from "@/components/landing/navbar"
import { LandingFooter } from "@/components/landing/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent } from "@/components/ui/card"
import { useToast } from "@/components/ui/use-toast"
import { Mail, MapPin, Phone, Send, CheckCircle } from "lucide-react"

export default function ContactPage() {
  const { toast } = useToast()
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: "",
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    })
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulate form submission
    await new Promise((resolve) => setTimeout(resolve, 1500))

    toast({
      title: "Message sent!",
      description: "We'll get back to you as soon as possible.",
    })

    setIsSubmitting(false)
    setIsSubmitted(true)
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-background/80">
      <LandingNavbar />
      <div className="container mx-auto px-4 py-32">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-12">
            <motion.h1
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="text-3xl md:text-4xl font-bold mb-4"
            >
              Contact{" "}
              <span className="bg-clip-text text-transparent bg-gradient-to-r from-teal-500 to-blue-600">
                GreenLoan
              </span>
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="text-lg text-foreground/70 max-w-2xl mx-auto"
            >
              Have questions or need assistance? We're here to help you with your sustainable financing needs.
            </motion.p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="lg:col-span-5"
            >
              <Card className="border-border/50 bg-background/50 backdrop-blur-sm h-full">
                <CardContent className="p-6">
                  <h2 className="text-xl font-semibold mb-6">Get in Touch</h2>

                  <div className="space-y-6">
                    <div className="flex items-start">
                      <div className="mr-4 mt-1">
                        <div className="w-10 h-10 rounded-full bg-gradient-to-br from-teal-500/20 to-blue-600/20 flex items-center justify-center">
                          <Mail className="w-5 h-5 text-teal-500" />
                        </div>
                      </div>
                      <div>
                        <h3 className="font-medium mb-1">Email</h3>
                        <p className="text-foreground/70">greenfinance.loan@gmail.com</p>
                        <a href="mailto:greenfinance.loan@gmail.com" className="text-sm text-teal-500 hover:underline">
                          Send an email
                        </a>
                      </div>
                    </div>

                    <div className="flex items-start">
                      <div className="mr-4 mt-1">
                        <div className="w-10 h-10 rounded-full bg-gradient-to-br from-teal-500/20 to-blue-600/20 flex items-center justify-center">
                          <MapPin className="w-5 h-5 text-teal-500" />
                        </div>
                      </div>
                      <div>
                        <h3 className="font-medium mb-1">Location</h3>
                        <p className="text-foreground/70">Gauteng, Pretoria</p>
                        <p className="text-foreground/70">South Africa</p>
                      </div>
                    </div>

                    <div className="flex items-start">
                      <div className="mr-4 mt-1">
                        <div className="w-10 h-10 rounded-full bg-gradient-to-br from-teal-500/20 to-blue-600/20 flex items-center justify-center">
                          <Phone className="w-5 h-5 text-teal-500" />
                        </div>
                      </div>
                      <div>
                        <h3 className="font-medium mb-1">Phone</h3>
                        <p className="text-foreground/70">+27 12 345 6789</p>
                        <p className="text-xs text-foreground/50">Monday to Friday, 8am to 5pm</p>
                      </div>
                    </div>
                  </div>

                  <div className="mt-8">
                    <h3 className="font-medium mb-4">Our Location</h3>
                    <div className="rounded-lg overflow-hidden border border-border/50 h-[200px] bg-foreground/5">
                      {/* Map placeholder - in a real app, you would integrate Google Maps or similar */}
                      <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-teal-500/5 to-blue-600/5">
                        <MapPin className="w-8 h-8 text-teal-500/50" />
                        <span className="ml-2 text-foreground/50">Pretoria, Gauteng</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="lg:col-span-7"
            >
              <Card className="border-border/50 bg-background/50 backdrop-blur-sm">
                <CardContent className="p-6">
                  <h2 className="text-xl font-semibold mb-6">Send Us a Message</h2>

                  {isSubmitted ? (
                    <div className="flex flex-col items-center justify-center py-12 text-center">
                      <div className="w-16 h-16 rounded-full bg-green-500/20 flex items-center justify-center mb-4">
                        <CheckCircle className="w-8 h-8 text-green-500" />
                      </div>
                      <h3 className="text-xl font-medium mb-2">Message Sent!</h3>
                      <p className="text-foreground/70 mb-6 max-w-md">
                        Thank you for contacting us. We've received your message and will get back to you as soon as
                        possible.
                      </p>
                      <Button
                        onClick={() => {
                          setIsSubmitted(false)
                          setFormData({
                            name: "",
                            email: "",
                            subject: "",
                            message: "",
                          })
                        }}
                      >
                        Send Another Message
                      </Button>
                    </div>
                  ) : (
                    <form onSubmit={handleSubmit} className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <label htmlFor="name" className="text-sm font-medium">
                            Your Name <span className="text-red-500">*</span>
                          </label>
                          <Input
                            id="name"
                            name="name"
                            value={formData.name}
                            onChange={handleChange}
                            placeholder="John Doe"
                            required
                          />
                        </div>

                        <div className="space-y-2">
                          <label htmlFor="email" className="text-sm font-medium">
                            Your Email <span className="text-red-500">*</span>
                          </label>
                          <Input
                            id="email"
                            name="email"
                            type="email"
                            value={formData.email}
                            onChange={handleChange}
                            placeholder="john.doe@example.com"
                            required
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <label htmlFor="subject" className="text-sm font-medium">
                          Subject <span className="text-red-500">*</span>
                        </label>
                        <Input
                          id="subject"
                          name="subject"
                          value={formData.subject}
                          onChange={handleChange}
                          placeholder="How can we help you?"
                          required
                        />
                      </div>

                      <div className="space-y-2">
                        <label htmlFor="message" className="text-sm font-medium">
                          Message <span className="text-red-500">*</span>
                        </label>
                        <Textarea
                          id="message"
                          name="message"
                          value={formData.message}
                          onChange={handleChange}
                          placeholder="Write your message here..."
                          rows={6}
                          required
                        />
                      </div>

                      <Button
                        type="submit"
                        className="w-full bg-gradient-to-r from-teal-500 to-blue-600 hover:from-teal-600 hover:to-blue-700"
                        disabled={isSubmitting}
                      >
                        {isSubmitting ? (
                          <>
                            <span className="mr-2">Sending...</span>
                          </>
                        ) : (
                          <>
                            <Send className="mr-2 h-4 w-4" /> Send Message
                          </>
                        )}
                      </Button>
                    </form>
                  )}
                </CardContent>
              </Card>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.4 }}
                className="mt-8"
              >
                <Card className="border-border/50 bg-background/50 backdrop-blur-sm">
                  <CardContent className="p-6">
                    <h2 className="text-xl font-semibold mb-4">Frequently Asked Questions</h2>
                    <div className="space-y-4">
                      <div>
                        <h3 className="font-medium mb-1">What types of green projects do you finance?</h3>
                        <p className="text-sm text-foreground/70">
                          We finance a wide range of sustainable projects including solar installations, electric
                          vehicles, energy efficiency upgrades, and sustainable business initiatives.
                        </p>
                      </div>
                      <div>
                        <h3 className="font-medium mb-1">How long does the application process take?</h3>
                        <p className="text-sm text-foreground/70">
                          Our streamlined application process typically takes 24-48 hours for approval, with funds
                          disbursed within 3-5 business days after approval.
                        </p>
                      </div>
                      <div>
                        <h3 className="font-medium mb-1">Do you offer consultations before applying?</h3>
                        <p className="text-sm text-foreground/70">
                          Yes, we offer free consultations to discuss your project needs and help you determine the best
                          financing options. Contact us to schedule a consultation.
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </motion.div>
          </div>
        </div>
      </div>
      <LandingFooter />
    </div>
  )
}

