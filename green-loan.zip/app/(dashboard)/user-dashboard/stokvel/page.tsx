"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { DonutChart } from "@/components/charts/donut-chart"
import { UserDashboardNav } from "@/components/user-dashboard-nav"
import { Separator } from "@/components/ui/separator"
import { Stokvel3DCarousel } from "@/components/stokvel/stokvel-3d-carousel"

// Sample data for the Stokvel members
const stokvelMembers = [
  {
    id: "1",
    name: "Thabo Mbeki",
    position: 1,
    profileImage: "/placeholder.svg?height=80&width=80&text=TM",
    payoutDate: "15 Apr 2023",
    amountPaid: 5000,
    paymentSpeedRating: "Fast" as const,
    amountToReceive: 60000,
  },
  {
    id: "2",
    name: "Nelson Mandela",
    position: 2,
    profileImage: "/placeholder.svg?height=80&width=80&text=NM",
    payoutDate: "15 May 2023",
    amountPaid: 5000,
    paymentSpeedRating: "Fast" as const,
    amountToReceive: 60000,
  },
  {
    id: "3",
    name: "Winnie Mandela",
    position: 3,
    profileImage: "/placeholder.svg?height=80&width=80&text=WM",
    payoutDate: "15 Jun 2023",
    amountPaid: 4500,
    paymentSpeedRating: "Average" as const,
    amountToReceive: 60000,
  },
  {
    id: "4",
    name: "Cyril Ramaphosa",
    position: 4,
    profileImage: "/placeholder.svg?height=80&width=80&text=CR",
    payoutDate: "15 Jul 2023",
    amountPaid: 3000,
    paymentSpeedRating: "Slow" as const,
    amountToReceive: 60000,
  },
  {
    id: "5",
    name: "Patrice Motsepe",
    position: 5,
    profileImage: "/placeholder.svg?height=80&width=80&text=PM",
    payoutDate: "15 Aug 2023",
    amountPaid: 5000,
    paymentSpeedRating: "Fast" as const,
    amountToReceive: 60000,
  },
  {
    id: "6",
    name: "Trevor Noah",
    position: 6,
    profileImage: "/placeholder.svg?height=80&width=80&text=TN",
    payoutDate: "15 Sep 2023",
    amountPaid: 4000,
    paymentSpeedRating: "Average" as const,
    amountToReceive: 60000,
  },
  {
    id: "7",
    name: "Desmond Tutu",
    position: 7,
    profileImage: "/placeholder.svg?height=80&width=80&text=DT",
    payoutDate: "15 Oct 2023",
    amountPaid: 5000,
    paymentSpeedRating: "Fast" as const,
    amountToReceive: 60000,
  },
  {
    id: "8",
    name: "Elon Musk",
    position: 8,
    profileImage: "/placeholder.svg?height=80&width=80&text=EM",
    payoutDate: "15 Nov 2023",
    amountPaid: 4200,
    paymentSpeedRating: "Average" as const,
    amountToReceive: 60000,
  },
  {
    id: "9",
    name: "Chris Barnard",
    position: 9,
    profileImage: "/placeholder.svg?height=80&width=80&text=CB",
    payoutDate: "15 Dec 2023",
    amountPaid: 2800,
    paymentSpeedRating: "Slow" as const,
    amountToReceive: 60000,
  },
  {
    id: "10",
    name: "Caster Semenya",
    position: 10,
    profileImage: "/placeholder.svg?height=80&width=80&text=CS",
    payoutDate: "15 Jan 2024",
    amountPaid: 5000,
    paymentSpeedRating: "Fast" as const,
    amountToReceive: 60000,
  },
  {
    id: "11",
    name: "Siya Kolisi",
    position: 11,
    profileImage: "/placeholder.svg?height=80&width=80&text=SK",
    payoutDate: "15 Feb 2024",
    amountPaid: 4700,
    paymentSpeedRating: "Average" as const,
    amountToReceive: 60000,
  },
  {
    id: "12",
    name: "Charlize Theron",
    position: 12,
    profileImage: "/placeholder.svg?height=80&width=80&text=CT",
    payoutDate: "15 Mar 2024",
    amountPaid: 5000,
    paymentSpeedRating: "Fast" as const,
    amountToReceive: 60000,
  },
]

const contributionData = [
  { name: "Paid", value: 4500 },
  { name: "Remaining", value: 500 },
]

export default function StokvelPage() {
  const [activeTab, setActiveTab] = useState("overview")

  return (
    <>
      <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-3xl font-bold tracking-tight">Stokvel Management</h2>
            <p className="text-muted-foreground">Manage your stokvel contributions and view member rotation</p>
          </div>
          <UserDashboardNav />
        </div>

        <Tabs defaultValue="overview" className="space-y-4" onValueChange={setActiveTab}>
          <TabsList>
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="payments">Payments</TabsTrigger>
            <TabsTrigger value="members">Members</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Your Position</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">3rd</div>
                  <p className="text-xs text-muted-foreground">Payout in 2 months</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Monthly Contribution</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">R5,000</div>
                  <p className="text-xs text-muted-foreground">Due by 5th of each month</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Your Payout</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">R60,000</div>
                  <p className="text-xs text-muted-foreground">Expected on June 15, 2023</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Current Month Status</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">R4,500</div>
                  <p className="text-xs text-muted-foreground">Paid for April 2023</p>
                </CardContent>
              </Card>
            </div>

            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
              <Card className="col-span-3">
                <CardHeader>
                  <CardTitle>This Month's Contribution</CardTitle>
                  <CardDescription>Your contribution progress for April 2023</CardDescription>
                </CardHeader>
                <CardContent className="pl-2">
                  <DonutChart
                    data={contributionData}
                    colors={["#4ade80", "#e11d48"]}
                    label="R4,500"
                    labelColor="#000000"
                  />
                </CardContent>
              </Card>

              <Card className="col-span-4">
                <CardHeader>
                  <CardTitle>Member Schedule</CardTitle>
                  <CardDescription>Upcoming member payouts and status</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center">
                      <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center mr-3">2</div>
                      <div className="flex-1">
                        <p className="text-sm font-medium">Nelson Mandela</p>
                        <p className="text-xs text-muted-foreground">May 15, 2023</p>
                      </div>
                      <div className="bg-green-100 text-green-800 px-2 py-1 rounded text-xs">Next</div>
                    </div>
                    <Separator />
                    <div className="flex items-center">
                      <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center mr-3 text-white">
                        3
                      </div>
                      <div className="flex-1">
                        <p className="text-sm font-medium">Winnie Mandela (You)</p>
                        <p className="text-xs text-muted-foreground">Jun 15, 2023</p>
                      </div>
                      <div className="bg-blue-100 text-blue-800 px-2 py-1 rounded text-xs">Your Turn</div>
                    </div>
                    <Separator />
                    <div className="flex items-center">
                      <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center mr-3">4</div>
                      <div className="flex-1">
                        <p className="text-sm font-medium">Cyril Ramaphosa</p>
                        <p className="text-xs text-muted-foreground">Jul 15, 2023</p>
                      </div>
                    </div>
                    <Separator />
                    <div className="flex items-center">
                      <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center mr-3">5</div>
                      <div className="flex-1">
                        <p className="text-sm font-medium">Patrice Motsepe</p>
                        <p className="text-xs text-muted-foreground">Aug 15, 2023</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="payments" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Payment History</CardTitle>
                <CardDescription>View your stokvel payment history and upcoming dues</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-4 text-sm font-medium">
                    <div>Month</div>
                    <div>Due Date</div>
                    <div>Amount</div>
                    <div>Status</div>
                  </div>
                  <Separator />
                  <div className="grid grid-cols-4 text-sm">
                    <div>April 2023</div>
                    <div>Apr 5, 2023</div>
                    <div>R5,000</div>
                    <div>
                      <span className="bg-yellow-100 text-yellow-800 px-2 py-1 rounded text-xs">Partial</span>
                    </div>
                  </div>
                  <Separator />
                  <div className="grid grid-cols-4 text-sm">
                    <div>March 2023</div>
                    <div>Mar 5, 2023</div>
                    <div>R5,000</div>
                    <div>
                      <span className="bg-green-100 text-green-800 px-2 py-1 rounded text-xs">Paid</span>
                    </div>
                  </div>
                  <Separator />
                  <div className="grid grid-cols-4 text-sm">
                    <div>February 2023</div>
                    <div>Feb 5, 2023</div>
                    <div>R5,000</div>
                    <div>
                      <span className="bg-green-100 text-green-800 px-2 py-1 rounded text-xs">Paid</span>
                    </div>
                  </div>
                  <Separator />
                  <div className="grid grid-cols-4 text-sm">
                    <div>January 2023</div>
                    <div>Jan 5, 2023</div>
                    <div>R5,000</div>
                    <div>
                      <span className="bg-green-100 text-green-800 px-2 py-1 rounded text-xs">Paid</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="members" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Member Rotation</CardTitle>
                <CardDescription>View the stokvel member rotation and payment schedule</CardDescription>
              </CardHeader>
              <CardContent>
                <Stokvel3DCarousel members={stokvelMembers} />
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </>
  )
}

