import { HeroGeometric } from "@/components/ui/shape-landing-hero"
import { LandingFeatures } from "@/components/landing/features"
import { LandingTestimonials } from "@/components/landing/testimonials"
import { LandingCTA } from "@/components/landing/cta"
import { LandingNavbar } from "@/components/landing/navbar"
import { LandingFooter } from "@/components/landing/footer"
import { GlobeDemo } from "@/components/globe-demo"

export default function Home() {
  return (
    <div className="min-h-screen bg-background">
      <LandingNavbar />
      <main>
        <section>
          <HeroGeometric
            badge="" // Removed the "Green Loan" badge text
            title1="Sustainable"
            title2="Financial Solutions"
          />
        </section>
        <LandingFeatures />
        <LandingTestimonials />
        <GlobeDemo />
        <LandingCTA />
      </main>
      <LandingFooter />
    </div>
  )
}

