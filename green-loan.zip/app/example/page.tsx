import { createClient } from "@/utils/supabase/server"
import { cookies } from "next/headers"

export default async function Page() {
  const cookieStore = cookies()
  const supabase = createClient(cookieStore)

  // Improved database query with error handling and type safety
  const { data: todos, error } = await supabase
    .from("todos")
    .select("id, title, completed")
    .order("created_at", { ascending: false })
    .limit(10)

  if (error) {
    console.error("Error fetching todos:", error)
    return <div>Error loading todos. Please try again later.</div>
  }

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-2xl font-bold mb-4">Todos</h1>
      {todos && todos.length > 0 ? (
        <ul className="space-y-2">
          {todos.map((todo) => (
            <li key={todo.id} className="p-4 bg-card rounded-lg shadow">
              <div className="flex items-center gap-2">
                <input type="checkbox" checked={todo.completed} readOnly className="h-4 w-4" />
                <span className={todo.completed ? "line-through text-muted-foreground" : ""}>{todo.title}</span>
              </div>
            </li>
          ))}
        </ul>
      ) : (
        <p>No todos found.</p>
      )}
    </div>
  )
}

