"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { useSupabase } from "@/components/supabase-provider"
import { motion, AnimatePresence } from "framer-motion"
import { useToast } from "@/components/ui/use-toast"
import { LandingNavbar } from "@/components/landing/navbar"
import { LandingFooter } from "@/components/landing/footer"
import { ApplicationForm } from "@/components/application/application-form"
import { ApplicationProgress } from "@/components/application/application-progress"
import { Card, CardContent } from "@/components/ui/card"
import { Loader2 } from "lucide-react"
import { analyzeApplication } from "@/lib/ai-verification"

// Define the application steps
export const applicationSteps = [
  { id: "personal", title: "Personal Details" },
  { id: "banking", title: "Banking Information" },
  { id: "address", title: "Physical Address" },
  { id: "loan", title: "Loan Details" },
  { id: "documents", title: "Document Upload" },
  { id: "review", title: "Review & Submit" },
]

// Define the initial form state
const initialFormState = {
  // Personal Details
  fullName: "",
  email: "",
  phone: "",
  dateOfBirth: "",
  employmentStatus: "employed",
  monthlyIncome: "",

  // Banking Information
  bankName: "",
  accountNumber: "",
  accountType: "checking",

  // Physical Address
  streetAddress: "",
  city: "",
  province: "",
  zipCode: "",
  residenceType: "own",

  // Loan Details
  loanAmount: "", // Changed from 5000 to empty string
  loanPurpose: "",
  loanType: "personal",
  dueDate: "",
  projectDescription: "",

  // Documents
  identificationDoc: null,
  bankStatementDoc: null,

  // Terms
  agreeToTerms: false,
}

export default function ApplyPage() {
  const router = useRouter()
  const { supabase, user, loading: userLoading } = useSupabase()
  const { toast } = useToast()
  const [currentStep, setCurrentStep] = useState(0)
  const [formData, setFormData] = useState(initialFormState)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isLoading, setIsLoading] = useState(true)

  // Pre-fill form with user data if logged in
  useEffect(() => {
    const fetchUserData = async () => {
      if (user) {
        try {
          const { data, error } = await supabase.from("profiles").select("*").eq("id", user.id).single()

          if (data && !error) {
            setFormData((prev) => ({
              ...prev,
              fullName: data.full_name || prev.fullName,
              email: data.email || prev.email,
              phone: data.phone || prev.phone,
            }))
          }
        } catch (error) {
          console.error("Error fetching user data:", error)
        }
      }
      setIsLoading(false)
    }

    if (!userLoading) {
      fetchUserData()
    }
  }, [user, userLoading, supabase])

  const handleStepChange = (step: number) => {
    // Only allow moving to steps that are accessible (current or previous)
    if (step <= currentStep + 1 && step >= 0 && step < applicationSteps.length) {
      setCurrentStep(step)

      // Scroll to top when changing steps
      window.scrollTo({ top: 0, behavior: "smooth" })
    }
  }

  const handleFormChange = (field: string, value: any) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  const handleSubmit = async () => {
    setIsSubmitting(true)

    try {
      // If user is not logged in, create a guest application
      let userId = user?.id

      if (!userId) {
        // Create a temporary user record for non-logged in applicants
        const { data: tempUser, error: tempUserError } = await supabase
          .from("temp_users")
          .insert([
            {
              full_name: formData.fullName,
              email: formData.email,
              phone: formData.phone,
            },
          ])
          .select()

        if (tempUserError) {
          throw tempUserError
        }

        userId = tempUser[0].id
      }

      // Run AI verification on the application
      const aiAnalysis = await analyzeApplication({
        ...formData,
        userId,
      })

      // Submit the loan application
      const { error } = await supabase.from("loan_applications").insert([
        {
          user_id: userId,
          full_name: formData.fullName,
          email: formData.email,
          phone: formData.phone,
          loan_amount: formData.loanAmount,
          loan_purpose: formData.loanPurpose,
          loan_type: formData.loanType,
          due_date: formData.dueDate,
          employment_status: formData.employmentStatus,
          monthly_income: Number.parseFloat(formData.monthlyIncome),
          project_description: formData.projectDescription,
          ai_verification_result: aiAnalysis.result,
          ai_verification_score: aiAnalysis.score,
          ai_verification_notes: aiAnalysis.notes,
          status: "pending",
        },
      ])

      if (error) {
        throw error
      }

      toast({
        title: "Application submitted successfully!",
        description: "We'll review your application and get back to you soon.",
      })

      // Redirect to confirmation page
      router.push("/apply/confirmation")
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Application submission failed",
        description: error.message || "An error occurred. Please try again.",
      })
      setIsSubmitting(false)
    }
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-background to-background/80 flex items-center justify-center">
        <LandingNavbar />
        <div className="flex flex-col items-center justify-center">
          <Loader2 className="h-12 w-12 animate-spin text-teal-500 mb-4" />
          <p className="text-lg">Loading application form...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-background/80">
      <LandingNavbar />
      <div className="container mx-auto px-4 py-32">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-8">
            <motion.h1
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="text-3xl md:text-4xl font-bold mb-4"
            >
              Apply for a{" "}
              <span className="bg-clip-text text-transparent bg-gradient-to-r from-teal-500 to-blue-600">
                Green Loan
              </span>
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="text-lg text-foreground/70"
            >
              Complete the application form below to apply for financing for your sustainable project.
            </motion.p>
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <ApplicationProgress steps={applicationSteps} currentStep={currentStep} onStepClick={handleStepChange} />
          </motion.div>

          <Card className="border-border/50 bg-background/50 backdrop-blur-sm mt-8">
            <CardContent className="p-0">
              <AnimatePresence mode="wait">
                <motion.div
                  key={currentStep}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.3 }}
                >
                  <ApplicationForm
                    currentStep={currentStep}
                    formData={formData}
                    onChange={handleFormChange}
                    onStepChange={handleStepChange}
                    onSubmit={handleSubmit}
                    isSubmitting={isSubmitting}
                    steps={applicationSteps}
                  />
                </motion.div>
              </AnimatePresence>
            </CardContent>
          </Card>
        </div>
      </div>
      <LandingFooter />
    </div>
  )
}

