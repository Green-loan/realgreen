"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { CheckCircle2 } from "lucide-react"
import { LandingNavbar } from "@/components/landing/navbar"
import { LandingFooter } from "@/components/landing/footer"
import { motion } from "framer-motion"

export default function ConfirmationPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-background/80">
      <LandingNavbar />
      <div className="container mx-auto px-4 py-32">
        <div className="max-w-2xl mx-auto">
          <Card className="border-border/50 bg-background/50 backdrop-blur-sm overflow-hidden">
            <div className="absolute inset-0 -z-10">
              <div className="absolute top-0 right-0 w-64 h-64 bg-green-500/10 rounded-full blur-3xl" />
              <div className="absolute bottom-0 left-0 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl" />
            </div>

            <CardHeader className="text-center pb-2">
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{
                  type: "spring",
                  stiffness: 260,
                  damping: 20,
                  delay: 0.1,
                }}
                className="mx-auto mb-4"
              >
                <CheckCircle2 className="w-16 h-16 text-green-500" />
              </motion.div>
              <CardTitle className="text-2xl md:text-3xl">Application Submitted!</CardTitle>
              <CardDescription className="text-lg">Thank you for applying for a Green Loan</CardDescription>
            </CardHeader>
            <CardContent className="text-center space-y-4">
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
                <p className="text-foreground/80">
                  Your application has been received and is now being processed. Our team will review your information
                  and our AI system will analyze your application.
                </p>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 }}
                className="bg-foreground/5 rounded-lg p-6 mt-6"
              >
                <h3 className="font-medium text-lg mb-2">What happens next?</h3>
                <ul className="space-y-2 text-sm text-left">
                  <li className="flex items-start">
                    <span className="bg-green-500/20 text-green-500 rounded-full p-1 mr-2 mt-0.5">
                      <CheckCircle2 className="w-4 h-4" />
                    </span>
                    <span>Our AI system will verify your application details</span>
                  </li>
                  <li className="flex items-start">
                    <span className="bg-green-500/20 text-green-500 rounded-full p-1 mr-2 mt-0.5">
                      <CheckCircle2 className="w-4 h-4" />
                    </span>
                    <span>A loan officer will review your application within 1-2 business days</span>
                  </li>
                  <li className="flex items-start">
                    <span className="bg-green-500/20 text-green-500 rounded-full p-1 mr-2 mt-0.5">
                      <CheckCircle2 className="w-4 h-4" />
                    </span>
                    <span>You'll receive an email notification about your application status</span>
                  </li>
                  <li className="flex items-start">
                    <span className="bg-green-500/20 text-green-500 rounded-full p-1 mr-2 mt-0.5">
                      <CheckCircle2 className="w-4 h-4" />
                    </span>
                    <span>If approved, funds will be disbursed within 3-5 business days</span>
                  </li>
                </ul>
              </motion.div>
            </CardContent>
            <CardFooter className="flex flex-col space-y-4 pt-2">
              <p className="text-sm text-foreground/70 text-center">
                Application Reference: <span className="font-mono font-medium">{generateRandomId()}</span>
              </p>
              <div className="flex flex-col sm:flex-row gap-4 w-full">
                <Button asChild variant="outline" className="flex-1">
                  <Link href="/">Return to Home</Link>
                </Button>
                <Button
                  asChild
                  className="flex-1 bg-gradient-to-r from-green-400 to-emerald-600 hover:from-green-500 hover:to-emerald-700"
                >
                  <Link href="/dashboard">Go to Dashboard</Link>
                </Button>
              </div>
            </CardFooter>
          </Card>
        </div>
      </div>
      <LandingFooter />
    </div>
  )
}

function generateRandomId() {
  return `GL-${Math.random().toString(36).substring(2, 8).toUpperCase()}-${new Date().getFullYear()}`
}

