"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { LandingNavbar } from "@/components/landing/navbar"
import { LandingFooter } from "@/components/landing/footer"
import { GreenLoanCalculator } from "@/components/calculator/green-loan-calculator"
import { CalculatorResults } from "@/components/calculator/calculator-results"
import { EnvironmentalImpact } from "@/components/calculator/environmental-impact"
import { AmortizationTable } from "@/components/calculator/amortization-table"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"
import Link from "next/link"

export default function CalculatorPage() {
  const [calculatorValues, setCalculatorValues] = useState({
    loanAmount: 25000,
    loanTerm: 60,
    interestRate: 4.5,
    projectType: "solar",
  })

  const [monthlyPayment, setMonthlyPayment] = useState(0)
  const [totalInterest, setTotalInterest] = useState(0)
  const [totalCost, setTotalCost] = useState(0)
  const [amortizationSchedule, setAmortizationSchedule] = useState<any[]>([])

  // Calculate loan details when calculator values change
  useEffect(() => {
    calculateLoan(calculatorValues.loanAmount, calculatorValues.loanTerm, calculatorValues.interestRate)
  }, [calculatorValues.loanAmount, calculatorValues.loanTerm, calculatorValues.interestRate])

  const calculateLoan = (amount: number, months: number, rate: number) => {
    // Calculate simple interest
    const totalInterest = amount * (rate / 100) * (months / 12)

    // Calculate monthly payment (principal + interest divided by months)
    const payment = (amount + totalInterest) / months

    // Calculate total cost
    const totalCostPaid = amount + totalInterest

    // Generate amortization schedule
    const schedule = []
    let remainingBalance = amount + totalInterest
    let totalPrincipal = 0
    let totalInterestPayment = 0
    const monthlyInterest = totalInterest / months
    const monthlyPrincipal = amount / months

    for (let i = 1; i <= months; i++) {
      totalPrincipal += monthlyPrincipal
      totalInterestPayment += monthlyInterest
      remainingBalance -= payment

      if (i <= 12 || i % 12 === 0 || i === months) {
        schedule.push({
          period: i,
          payment: payment,
          principal: monthlyPrincipal,
          interest: monthlyInterest,
          totalPrincipal: totalPrincipal,
          totalInterest: totalInterestPayment,
          balance: Math.max(0, remainingBalance),
        })
      }
    }

    setMonthlyPayment(payment)
    setTotalInterest(totalInterest)
    setTotalCost(totalCostPaid)
    setAmortizationSchedule(schedule)
  }

  const handleCalculatorChange = (values: any) => {
    setCalculatorValues(values)
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-background/80">
      <LandingNavbar />
      <div className="container mx-auto px-4 py-32">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-12">
            <motion.h1
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="text-3xl md:text-4xl font-bold mb-4"
            >
              Green Loan{" "}
              <span className="bg-clip-text text-transparent bg-gradient-to-r from-teal-500 to-blue-600">
                Calculator (ZAR)
              </span>
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="text-lg text-foreground/70 max-w-2xl mx-auto"
            >
              Estimate your monthly payments, total interest, and environmental impact for your sustainable project
              financing in South African Rand.
            </motion.p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="lg:col-span-5"
            >
              <Card className="border-border/50 bg-background/50 backdrop-blur-sm h-full">
                <CardContent className="p-6">
                  <GreenLoanCalculator values={calculatorValues} onChange={handleCalculatorChange} />

                  <div className="mt-8">
                    <Button
                      asChild
                      className="w-full bg-gradient-to-r from-teal-500 to-blue-600 hover:from-teal-600 hover:to-blue-700"
                    >
                      <Link href="/apply">
                        Apply for This Green Loan <ArrowRight className="ml-2 h-4 w-4" />
                      </Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="lg:col-span-7"
            >
              <Card className="border-border/50 bg-background/50 backdrop-blur-sm">
                <CardContent className="p-6">
                  <CalculatorResults
                    loanAmount={calculatorValues.loanAmount}
                    monthlyPayment={monthlyPayment}
                    totalInterest={totalInterest}
                    totalCost={totalCost}
                    loanTerm={calculatorValues.loanTerm}
                  />
                </CardContent>
              </Card>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.4 }}
                className="mt-8"
              >
                <Tabs defaultValue="impact" className="w-full">
                  <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="impact">Environmental Impact</TabsTrigger>
                    <TabsTrigger value="schedule">Amortization Schedule</TabsTrigger>
                  </TabsList>
                  <TabsContent value="impact">
                    <Card className="border-border/50 bg-background/50 backdrop-blur-sm">
                      <CardContent className="p-6">
                        <EnvironmentalImpact
                          loanAmount={calculatorValues.loanAmount}
                          projectType={calculatorValues.projectType}
                        />
                      </CardContent>
                    </Card>
                  </TabsContent>
                  <TabsContent value="schedule">
                    <Card className="border-border/50 bg-background/50 backdrop-blur-sm">
                      <CardContent className="p-6">
                        <AmortizationTable schedule={amortizationSchedule} />
                      </CardContent>
                    </Card>
                  </TabsContent>
                </Tabs>
              </motion.div>
            </motion.div>
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.5 }}
            className="mt-12 bg-gradient-to-r from-teal-500/10 to-blue-600/10 rounded-xl p-6 border border-teal-500/20"
          >
            <h2 className="text-xl font-semibold mb-4">Loan Terms</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="space-y-2">
                <h3 className="font-medium">Fixed 39.99% Interest Rate</h3>
                <p className="text-sm text-foreground/70">
                  Our loans come with a fixed 39.99% interest rate. We believe in complete transparency about our loan
                  terms.
                </p>
              </div>
              <div className="space-y-2">
                <h3 className="font-medium">Flexible Loan Amounts</h3>
                <p className="text-sm text-foreground/70">
                  Borrow between R1,000 and R100,000 based on your project needs and financial situation.
                </p>
              </div>
              <div className="space-y-2">
                <h3 className="font-medium">Repayment Terms</h3>
                <p className="text-sm text-foreground/70">
                  Choose repayment terms from 12 to 120 months to fit your budget and financial goals.
                </p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
      <LandingFooter />
    </div>
  )
}

