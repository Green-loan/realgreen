"use client"

import { LandingNavbar } from "@/components/landing/navbar"
import { LandingFooter } from "@/components/landing/footer"
import { Card, CardContent } from "@/components/ui/card"

export default function PrivacyPolicyPage() {
  return (
    <div className="min-h-screen bg-background">
      <LandingNavbar />
      <div className="container mx-auto px-4 py-32">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-3xl md:text-4xl font-bold mb-8">Privacy Policy</h1>

          <Card className="mb-8">
            <CardContent className="p-6">
              <div className="prose prose-gray dark:prose-invert max-w-none">
                <h2 className="text-xl font-semibold mb-4">1. Introduction</h2>
                <p>
                  At GreenLoan, we are committed to protecting your privacy and ensuring the security of your personal
                  information. This Privacy Policy explains how we collect, use, disclose, and safeguard your
                  information when you visit our website or use our services.
                </p>
                <p>
                  By accessing or using our services, you consent to the practices described in this Privacy Policy. If
                  you do not agree with our policies and practices, please do not use our services.
                </p>

                <h2 className="text-xl font-semibold mb-4 mt-8">2. Information We Collect</h2>
                <p>
                  <strong>2.1 Personal Information:</strong> We collect personal information that you voluntarily
                  provide to us when you:
                </p>
                <ul className="list-disc pl-6 mb-4">
                  <li>Register for an account</li>
                  <li>Apply for a loan</li>
                  <li>Complete forms on our website</li>
                  <li>Contact our customer service</li>
                  <li>Subscribe to our communications</li>
                </ul>
                <p>This information may include:</p>
                <ul className="list-disc pl-6 mb-4">
                  <li>Full name</li>
                  <li>Email address</li>
                  <li>Phone number</li>
                  <li>Physical address</li>
                  <li>Date of birth</li>
                  <li>ID or passport number</li>
                  <li>Employment information</li>
                  <li>Income details</li>
                  <li>Banking information</li>
                </ul>
                <p>
                  <strong>2.2 Automatically Collected Information:</strong> When you visit our website, we may
                  automatically collect certain information about your device and browsing actions, including:
                </p>
                <ul className="list-disc pl-6 mb-4">
                  <li>IP address</li>
                  <li>Browser type and version</li>
                  <li>Operating system</li>
                  <li>Referring website</li>
                  <li>Pages you view</li>
                  <li>Time and date of your visit</li>
                </ul>

                <h2 className="text-xl font-semibold mb-4 mt-8">3. How We Use Your Information</h2>
                <p>We use the information we collect for various purposes, including to:</p>
                <ul className="list-disc pl-6 mb-4">
                  <li>Process and evaluate loan applications</li>
                  <li>Verify your identity</li>
                  <li>Assess creditworthiness</li>
                  <li>Provide, maintain, and improve our services</li>
                  <li>Communicate with you about your account or loan</li>
                  <li>Send important notices and updates</li>
                  <li>Respond to your inquiries and support requests</li>
                  <li>Detect, prevent, and address fraud or security issues</li>
                  <li>Comply with legal obligations</li>
                </ul>

                <h2 className="text-xl font-semibold mb-4 mt-8">4. Information Sharing and Disclosure</h2>
                <p>We may share your personal information with:</p>
                <ul className="list-disc pl-6 mb-4">
                  <li>
                    <strong>Service Providers:</strong> Third-party vendors who perform services on our behalf, such as
                    payment processing, data analysis, and customer service.
                  </li>
                  <li>
                    <strong>Credit Bureaus:</strong> To report loan performance and payment history.
                  </li>
                  <li>
                    <strong>Legal Authorities:</strong> When required by law, court order, or governmental regulation.
                  </li>
                  <li>
                    <strong>Business Partners:</strong> With your consent, we may share your information with trusted
                    partners to offer you certain products or services.
                  </li>
                </ul>
                <p>We do not sell your personal information to third parties.</p>

                <h2 className="text-xl font-semibold mb-4 mt-8">5. Data Security</h2>
                <p>
                  We implement appropriate technical and organizational measures to protect your personal information
                  from unauthorized access, disclosure, alteration, or destruction. However, no method of transmission
                  over the Internet or electronic storage is 100% secure, and we cannot guarantee absolute security.
                </p>

                <h2 className="text-xl font-semibold mb-4 mt-8">6. Data Retention</h2>
                <p>
                  We retain your personal information for as long as necessary to fulfill the purposes outlined in this
                  Privacy Policy, unless a longer retention period is required or permitted by law. When determining the
                  retention period, we consider the amount, nature, and sensitivity of the information, the potential
                  risk of harm from unauthorized use or disclosure, and applicable legal requirements.
                </p>

                <h2 className="text-xl font-semibold mb-4 mt-8">7. Your Rights</h2>
                <p>
                  Depending on your location, you may have certain rights regarding your personal information,
                  including:
                </p>
                <ul className="list-disc pl-6 mb-4">
                  <li>The right to access your personal information</li>
                  <li>The right to correct inaccurate or incomplete information</li>
                  <li>The right to request deletion of your personal information</li>
                  <li>The right to restrict or object to processing</li>
                  <li>The right to data portability</li>
                </ul>
                <p>To exercise these rights, please contact us using the information provided in Section 10.</p>

                <h2 className="text-xl font-semibold mb-4 mt-8">8. Children's Privacy</h2>
                <p>
                  Our services are not intended for individuals under the age of 18. We do not knowingly collect
                  personal information from children. If you are a parent or guardian and believe that your child has
                  provided us with personal information, please contact us immediately.
                </p>

                <h2 className="text-xl font-semibold mb-4 mt-8">9. Changes to This Privacy Policy</h2>
                <p>
                  We may update this Privacy Policy from time to time to reflect changes in our practices or for other
                  operational, legal, or regulatory reasons. We will notify you of any material changes by posting the
                  updated Privacy Policy on our website and updating the "Last Updated" date. Your continued use of our
                  services after such modifications constitutes your acknowledgment of the modified Privacy Policy.
                </p>

                <h2 className="text-xl font-semibold mb-4 mt-8">10. Contact Information</h2>
                <p>
                  If you have any questions, concerns, or requests regarding this Privacy Policy or our privacy
                  practices, please contact us at:
                </p>
                <p>
                  Email: greenfinance.loan@gmail.com
                  <br />
                  Phone: +2764 0519593
                  <br />
                  Address: Gauteng, Pretoria, South Africa
                </p>

                <p className="mt-8">Last Updated: March 21, 2024</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
      <LandingFooter />
    </div>
  )
}

