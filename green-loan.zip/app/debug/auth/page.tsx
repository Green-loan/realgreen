"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useSupabase } from "@/components/supabase-provider"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import { Loader2 } from "lucide-react"

export default function DebugAuthPage() {
  const { supabase } = useSupabase()
  const [user, setUser] = useState<any>(null)
  const [profile, setProfile] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [fullName, setFullName] = useState("")
  const [fixingProfile, setFixingProfile] = useState(false)

  useEffect(() => {
    async function loadUserAndProfile() {
      setLoading(true)
      setError(null)

      try {
        // Get current user
        const {
          data: { user },
          error: userError,
        } = await supabase.auth.getUser()

        if (userError) {
          throw userError
        }

        setUser(user)

        if (user) {
          // Check if profiles table exists
          const { data: tableInfo, error: tableError } = await supabase.from("profiles").select("*").limit(1)

          if (tableError) {
            if (tableError.message.includes('relation "profiles" does not exist')) {
              setError("The profiles table does not exist in the database")
            } else {
              setError(`Error checking profiles table: ${tableError.message}`)
            }
            setLoading(false)
            return
          }

          // Try to get user's profile
          const { data: profileData, error: profileError } = await supabase
            .from("profiles")
            .select("*")
            .eq("id", user.id)
            .single()

          if (profileError) {
            if (profileError.message.includes("No rows found")) {
              setError("Profile not found for current user")
            } else {
              setError(`Error fetching profile: ${profileError.message}`)
            }
          } else {
            setProfile(profileData)
          }
        }
      } catch (err: any) {
        setError(`Error: ${err.message}`)
      } finally {
        setLoading(false)
      }
    }

    loadUserAndProfile()
  }, [supabase])

  const handleFixProfile = async () => {
    if (!user) return

    setFixingProfile(true)
    setError(null)
    setSuccess(null)

    try {
      // Try to create profile using our API route
      const response = await fetch("/api/debug/fix-profile", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          userId: user.id,
          userData: {
            full_name: user.user_metadata?.full_name || "User",
            email: user.email,
          },
        }),
      })

      const result = await response.json()

      if (!response.ok) {
        throw new Error(result.error || "Failed to fix profile")
      }

      setSuccess("Profile fixed successfully! Refreshing data...")

      // Refresh profile data
      const { data: profileData } = await supabase.from("profiles").select("*").eq("id", user.id).single()

      setProfile(profileData)
    } catch (err: any) {
      setError(`Failed to fix profile: ${err.message}`)
    } finally {
      setFixingProfile(false)
    }
  }

  const handleSimpleRegister = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)
    setSuccess(null)

    try {
      if (!email || !password || !fullName) {
        throw new Error("Please fill in all fields")
      }

      // Register with Supabase
      const { data, error: signUpError } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            full_name: fullName,
          },
        },
      })

      if (signUpError) throw signUpError

      if (data.user) {
        // Try to manually create profile
        const { error: profileError } = await supabase.from("profiles").insert([
          {
            id: data.user.id,
            full_name: fullName,
            email: email,
            updated_at: new Date().toISOString(),
          },
        ])

        if (profileError) {
          setSuccess("User created but profile creation failed. Trying API fallback...")

          // Try API fallback
          const response = await fetch("/api/debug/fix-profile", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              userId: data.user.id,
              userData: {
                full_name: fullName,
                email: email,
              },
            }),
          })

          const result = await response.json()

          if (!response.ok) {
            throw new Error(`API fallback failed: ${result.error}`)
          }

          setSuccess("User created and profile fixed via API fallback!")
        } else {
          setSuccess("User and profile created successfully!")
        }

        // Clear form
        setEmail("")
        setPassword("")
        setFullName("")
      }
    } catch (err: any) {
      setError(`Registration error: ${err.message}`)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto py-10 space-y-8">
      <h1 className="text-3xl font-bold">Authentication Debug</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Current User</CardTitle>
            <CardDescription>Information about the currently authenticated user</CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="flex justify-center py-4">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : user ? (
              <div className="space-y-4">
                <div>
                  <Label>User ID</Label>
                  <div className="mt-1 p-2 bg-muted rounded-md text-sm font-mono break-all">{user.id}</div>
                </div>
                <div>
                  <Label>Email</Label>
                  <div className="mt-1 p-2 bg-muted rounded-md text-sm">{user.email}</div>
                </div>
                <div>
                  <Label>Email Verified</Label>
                  <div className="mt-1 p-2 bg-muted rounded-md text-sm">{user.email_confirmed_at ? "Yes" : "No"}</div>
                </div>
                <div>
                  <Label>User Metadata</Label>
                  <div className="mt-1 p-2 bg-muted rounded-md text-sm font-mono overflow-auto max-h-40">
                    <pre>{JSON.stringify(user.user_metadata, null, 2)}</pre>
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-center py-4 text-muted-foreground">Not signed in</div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>User Profile</CardTitle>
            <CardDescription>Profile data from the profiles table</CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="flex justify-center py-4">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : profile ? (
              <div className="space-y-4">
                <div>
                  <Label>Profile ID</Label>
                  <div className="mt-1 p-2 bg-muted rounded-md text-sm font-mono break-all">{profile.id}</div>
                </div>
                <div>
                  <Label>Full Name</Label>
                  <div className="mt-1 p-2 bg-muted rounded-md text-sm">{profile.full_name}</div>
                </div>
                <div>
                  <Label>Email</Label>
                  <div className="mt-1 p-2 bg-muted rounded-md text-sm">{profile.email}</div>
                </div>
                <div>
                  <Label>Updated At</Label>
                  <div className="mt-1 p-2 bg-muted rounded-md text-sm">
                    {new Date(profile.updated_at).toLocaleString()}
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-center py-4 text-muted-foreground">
                {user ? "No profile found for this user" : "Sign in to see profile data"}
              </div>
            )}
          </CardContent>
          {user && !profile && (
            <CardFooter>
              <Button onClick={handleFixProfile} disabled={fixingProfile} className="w-full">
                {fixingProfile ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Fixing Profile...
                  </>
                ) : (
                  "Fix Missing Profile"
                )}
              </Button>
            </CardFooter>
          )}
        </Card>
      </div>

      {error && (
        <div className="bg-destructive/10 border border-destructive text-destructive p-4 rounded-md">{error}</div>
      )}

      {success && <div className="bg-green-50 border border-green-200 text-green-700 p-4 rounded-md">{success}</div>}

      <Separator className="my-8" />

      <Card>
        <CardHeader>
          <CardTitle>Debug Registration</CardTitle>
          <CardDescription>Test user registration with direct profile creation</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSimpleRegister} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="fullName">Full Name</Label>
              <Input
                id="fullName"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder="John Doe"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                required
              />
            </div>
            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Registering...
                </>
              ) : (
                "Test Registration"
              )}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}

