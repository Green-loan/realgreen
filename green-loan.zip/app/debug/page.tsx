import { SupabaseConnectionDebug } from "@/components/debug/supabase-connection"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import Link from "next/link"

export default function DebugPage() {
  return (
    <div className="container mx-auto py-10 space-y-8">
      <h1 className="text-3xl font-bold">Debug Tools</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <SupabaseConnectionDebug />

        <Card>
          <CardHeader>
            <CardTitle>Debug Pages</CardTitle>
            <CardDescription>Access various debugging tools</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Button asChild className="w-full">
              <Link href="/debug/auth">Authentication Debug</Link>
            </Button>

            <Button asChild variant="outline" className="w-full">
              <Link href="/api/debug/fix-database" target="_blank">
                Run Database Fixes
              </Link>
            </Button>
          </CardContent>
        </Card>
      </div>

      <div className="bg-amber-50 border border-amber-200 text-amber-800 p-4 rounded-md">
        <h3 className="font-semibold mb-2">How to Fix Profile Issues</h3>
        <ol className="list-decimal list-inside space-y-2">
          <li>Check the connection status above to verify Supabase is working</li>
          <li>Visit the Authentication Debug page to see if your user account has a profile</li>
          <li>If no profile exists, use the "Fix Missing Profile" button</li>
          <li>
            If that doesn't work, run the Database Fixes to ensure the profiles table and triggers are set up correctly
          </li>
          <li>Try registering a new test user with the debug registration form</li>
        </ol>
      </div>
    </div>
  )
}

