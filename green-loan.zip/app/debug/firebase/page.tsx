import FirebaseDemo from "@/components/firebase-demo"

export default function FirebaseDebugPage() {
  return (
    <div className="container mx-auto py-10">
      <h1 className="text-2xl font-bold mb-6">Firebase Debug Page</h1>
      <FirebaseDemo />
    </div>
  )
}

