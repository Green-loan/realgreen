import { SupabaseDebug } from "@/components/debug/supabase-debug"

export default function SupabaseDebugPage() {
  return (
    <div className="container mx-auto py-10">
      <h1 className="text-2xl font-bold mb-6">Supabase Connection Debug</h1>
      <SupabaseDebug />
    </div>
  )
}

