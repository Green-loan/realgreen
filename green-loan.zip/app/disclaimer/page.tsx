"use client"

import { LandingNavbar } from "@/components/landing/navbar"
import { LandingFooter } from "@/components/landing/footer"
import { Card, CardContent } from "@/components/ui/card"

export default function DisclaimerPage() {
  return (
    <div className="min-h-screen bg-background">
      <LandingNavbar />
      <div className="container mx-auto px-4 py-32">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-3xl md:text-4xl font-bold mb-8">Disclaimer</h1>

          <Card className="mb-8">
            <CardContent className="p-6">
              <div className="prose prose-gray dark:prose-invert max-w-none">
                <h2 className="text-xl font-semibold mb-4">1. General Information</h2>
                <p>
                  The information provided on the GreenLoan website is for general informational purposes only. All
                  information on this website is provided in good faith; however, we make no representation or warranty
                  of any kind, express or implied, regarding the accuracy, adequacy, validity, reliability,
                  availability, or completeness of any information on the website.
                </p>

                <h2 className="text-xl font-semibold mb-4 mt-8">2. Loan Terms Disclosure</h2>
                <p>
                  GreenLoan provides loans with a fixed interest rate of 39.99%. All loans must be repaid within one
                  month from the date of disbursement. Late payments will incur a penalty of 39.99% of the total amount
                  due for the previous month, which will be added to your outstanding balance. Clients may not take more
                  than three loans if they have any outstanding debt with GreenLoan.
                </p>
                <p>
                  While we strive to provide clear and transparent information about our loan products, the specific
                  terms of your loan will be detailed in your loan agreement. In case of any discrepancy between the
                  information on this website and your loan agreement, the terms of the loan agreement shall prevail.
                </p>

                <h2 className="text-xl font-semibold mb-4 mt-8">3. No Financial Advice</h2>
                <p>
                  The information provided on this website does not constitute financial advice. GreenLoan is not a
                  financial advisor, and the content of this website should not be considered financial advice. Before
                  making any financial decisions, including applying for a loan, you should consult with a qualified
                  financial advisor to discuss your specific situation and needs.
                </p>

                <h2 className="text-xl font-semibold mb-4 mt-8">4. Risk Warning</h2>
                <p>
                  Borrowing money involves risk. You should carefully consider whether taking a loan is appropriate for
                  your financial situation. Failure to repay a loan may result in additional fees, negative credit
                  reporting, and potential legal action. If you are experiencing financial difficulties, we recommend
                  seeking advice from a financial counselor before applying for a loan.
                </p>

                <h2 className="text-xl font-semibold mb-4 mt-8">5. External Links</h2>
                <p>
                  This website may contain links to external websites that are not provided or maintained by GreenLoan.
                  We do not guarantee the accuracy, relevance, timeliness, or completeness of any information on these
                  external websites.
                </p>

                <h2 className="text-xl font-semibold mb-4 mt-8">6. Limitation of Liability</h2>
                <p>
                  To the maximum extent permitted by applicable law, GreenLoan shall not be liable for any indirect,
                  incidental, special, consequential, or punitive damages, or any loss of profits or revenues, whether
                  incurred directly or indirectly, or any loss of data, use, goodwill, or other intangible losses,
                  resulting from:
                </p>
                <ul className="list-disc pl-6 mb-4">
                  <li>Your access to or use of or inability to access or use the website</li>
                  <li>Any conduct or content of any third party on the website</li>
                  <li>Any content obtained from the website</li>
                  <li>Unauthorized access, use, or alteration of your transmissions or content</li>
                </ul>

                <h2 className="text-xl font-semibold mb-4 mt-8">7. Indemnification</h2>
                <p>
                  You agree to defend, indemnify, and hold harmless GreenLoan, its officers, directors, employees, and
                  agents, from and against any claims, liabilities, damages, judgments, awards, losses, costs, expenses,
                  or fees (including reasonable attorneys' fees) arising out of or relating to your violation of these
                  terms or your use of the website.
                </p>

                <h2 className="text-xl font-semibold mb-4 mt-8">8. Governing Law</h2>
                <p>
                  This Disclaimer shall be governed by and construed in accordance with the laws of South Africa,
                  without regard to its conflict of law provisions.
                </p>

                <h2 className="text-xl font-semibold mb-4 mt-8">9. Changes to This Disclaimer</h2>
                <p>
                  We may update this Disclaimer from time to time. We will notify you of any changes by posting the new
                  Disclaimer on this page and updating the "Last Updated" date. You are advised to review this
                  Disclaimer periodically for any changes.
                </p>

                <h2 className="text-xl font-semibold mb-4 mt-8">10. Contact Information</h2>
                <p>If you have any questions about this Disclaimer, please contact us at:</p>
                <p>
                  Email: greenfinance.loan@gmail.com
                  <br />
                  Phone: +2764 0519593
                  <br />
                  Address: Gauteng, Pretoria, South Africa
                </p>

                <p className="mt-8">Last Updated: March 21, 2024</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
      <LandingFooter />
    </div>
  )
}

