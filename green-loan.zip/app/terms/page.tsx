"use client"

import { LandingNavbar } from "@/components/landing/navbar"
import { LandingFooter } from "@/components/landing/footer"
import { Card, CardContent } from "@/components/ui/card"

export default function TermsOfServicePage() {
  return (
    <div className="min-h-screen bg-background">
      <LandingNavbar />
      <div className="container mx-auto px-4 py-32">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-3xl md:text-4xl font-bold mb-8">Terms of Service</h1>

          <Card className="mb-8">
            <CardContent className="p-6">
              <div className="prose prose-gray dark:prose-invert max-w-none">
                <h2 className="text-xl font-semibold mb-4">1. Introduction</h2>
                <p>
                  Welcome to GreenLoan. These Terms of Service ("Terms") govern your use of our website, services, and
                  loan products. By accessing our website or applying for a loan, you agree to be bound by these Terms.
                  If you do not agree with any part of these Terms, you must not use our services.
                </p>

                <h2 className="text-xl font-semibold mb-4 mt-8">2. Loan Terms and Conditions</h2>
                <p>
                  <strong>2.1 Interest Rate:</strong> All loans provided by GreenLoan carry a fixed interest rate of
                  39.99%. This rate is applied to the principal amount and is non-negotiable.
                </p>
                <p>
                  <strong>2.2 Repayment Period:</strong> All loans must be repaid within one (1) month from the date of
                  disbursement. The exact due date will be specified in your loan agreement.
                </p>
                <p>
                  <strong>2.3 Late Payment Penalties:</strong> If you fail to make your payment by the due date, a late
                  payment penalty will be applied. This penalty is calculated as 39.99% of the total amount due for the
                  previous month (principal plus interest). This additional amount will be added to your outstanding
                  balance.
                </p>
                <p>
                  <strong>2.4 Loan Limit:</strong> Clients may not take more than three (3) loans if they have any
                  outstanding debt with GreenLoan. All previous loans must be fully repaid before a fourth loan can be
                  considered.
                </p>
                <p>
                  <strong>2.5 Early Repayment:</strong> Clients may repay their loans before the due date without any
                  early repayment penalties.
                </p>
                <p>
                  <strong>2.6 Default:</strong> A loan is considered in default if payment is not received within 14
                  days after the due date. In case of default, GreenLoan reserves the right to:
                </p>
                <ul className="list-disc pl-6 mb-4">
                  <li>Report the default to credit bureaus</li>
                  <li>Initiate collection proceedings</li>
                  <li>Charge additional collection fees</li>
                  <li>Take legal action to recover the debt</li>
                </ul>

                <h2 className="text-xl font-semibold mb-4 mt-8">3. Application Process</h2>
                <p>
                  <strong>3.1 Eligibility:</strong> To be eligible for a loan, applicants must:
                </p>
                <ul className="list-disc pl-6 mb-4">
                  <li>Be at least 18 years of age</li>
                  <li>Have a valid South African ID or passport</li>
                  <li>Have a regular source of income</li>
                  <li>Have an active bank account</li>
                  <li>Provide accurate and truthful information in their application</li>
                </ul>
                <p>
                  <strong>3.2 Approval:</strong> GreenLoan reserves the right to approve or deny loan applications at
                  its sole discretion. Approval is based on our assessment of the applicant's creditworthiness and
                  ability to repay.
                </p>
                <p>
                  <strong>3.3 Verification:</strong> GreenLoan may verify the information provided in your application
                  through various means, including credit checks, employment verification, and bank statement analysis.
                </p>

                <h2 className="text-xl font-semibold mb-4 mt-8">4. Disbursement and Repayment</h2>
                <p>
                  <strong>4.1 Disbursement:</strong> Upon approval, loan funds will be disbursed directly to the bank
                  account specified in your application, typically within 24-48 hours.
                </p>
                <p>
                  <strong>4.2 Repayment Methods:</strong> Repayments can be made through:
                </p>
                <ul className="list-disc pl-6 mb-4">
                  <li>Direct bank transfer to GreenLoan's account</li>
                  <li>Debit order (if authorized during application)</li>
                  <li>Other payment methods as specified in your loan agreement</li>
                </ul>

                <h2 className="text-xl font-semibold mb-4 mt-8">5. Account Management</h2>
                <p>
                  <strong>5.1 Account Security:</strong> You are responsible for maintaining the confidentiality of your
                  account credentials. Any activities that occur under your account are your responsibility.
                </p>
                <p>
                  <strong>5.2 Account Updates:</strong> You must promptly update your account information if there are
                  any changes to your contact details, employment status, or banking information.
                </p>

                <h2 className="text-xl font-semibold mb-4 mt-8">6. Termination</h2>
                <p>
                  GreenLoan reserves the right to terminate or suspend your account and access to our services at any
                  time, for any reason, without notice. Outstanding obligations will remain in effect despite
                  termination.
                </p>

                <h2 className="text-xl font-semibold mb-4 mt-8">7. Changes to Terms</h2>
                <p>
                  GreenLoan may modify these Terms at any time. We will notify users of any significant changes via
                  email or through our website. Your continued use of our services after such modifications constitutes
                  your acceptance of the updated Terms.
                </p>

                <h2 className="text-xl font-semibold mb-4 mt-8">8. Governing Law</h2>
                <p>
                  These Terms shall be governed by and construed in accordance with the laws of South Africa. Any
                  disputes arising under these Terms shall be subject to the exclusive jurisdiction of the courts of
                  South Africa.
                </p>

                <h2 className="text-xl font-semibold mb-4 mt-8">9. Contact Information</h2>
                <p>If you have any questions about these Terms, please contact us at:</p>
                <p>
                  Email: greenfinance.loan@gmail.com
                  <br />
                  Phone: +2764 0519593
                  <br />
                  Address: Gauteng, Pretoria, South Africa
                </p>

                <p className="mt-8">Last Updated: March 21, 2024</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
      <LandingFooter />
    </div>
  )
}

