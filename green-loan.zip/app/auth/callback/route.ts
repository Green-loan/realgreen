import { createRouteHandlerClient } from "@supabase/auth-helpers-nextjs"
import { cookies } from "next/headers"
import { NextResponse } from "next/server"
import { doc, setDoc, getDoc } from "firebase/firestore"
import { db } from "@/lib/firebase"

export async function GET(request: Request) {
  const requestUrl = new URL(request.url)
  const code = requestUrl.searchParams.get("code")

  if (code) {
    const cookieStore = cookies()
    const supabase = createRouteHandlerClient({ cookies: () => cookieStore })

    try {
      await supabase.auth.exchangeCodeForSession(code)

      // Get the user after authentication
      const {
        data: { user },
        error: userError,
      } = await supabase.auth.getUser()

      if (userError || !user) {
        console.error("Error getting user after code exchange:", userError)
      } else {
        // Check if user exists in Firebase
        try {
          const userDocRef = doc(db, "users", user.id)
          const userDoc = await getDoc(userDocRef)

          if (!userDoc.exists()) {
            // Create user in Firebase if not exists
            await setDoc(userDocRef, {
              id: user.id,
              email: user.email,
              fullName: user.user_metadata?.full_name || "New User",
              phone: user.user_metadata?.phone || null,
              createdAt: new Date().toISOString(),
              isVerified: user.email_confirmed_at ? true : false,
              role: "user",
            })
            console.log("User created in Firebase from callback")
          } else {
            // Update verification status if needed
            if (user.email_confirmed_at) {
              await setDoc(
                userDocRef,
                {
                  isVerified: true,
                  verifiedAt: new Date().toISOString(),
                },
                { merge: true },
              )
              console.log("User verification status updated in Firebase")
            }
          }
        } catch (firebaseError) {
          console.error("Firebase error in callback:", firebaseError)
        }
      }
    } catch (error) {
      console.error("Error in auth callback:", error)
    }
  }

  // URL to redirect to after sign in process completes
  return NextResponse.redirect(requestUrl.origin + "/dashboard")
}

