import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { createClient } from "@/utils/supabase/server"
import { cookies } from "next/headers"
import { DocumentVerification } from "@/components/admin/document-verification"
import { ApprovalPipeline } from "@/components/admin/approval-pipeline"
import { AIApplicationAnalysis } from "@/components/admin/ai-application-analysis"
import { CheckCircle, XCircle, Clock, Eye, FileText, Filter, Download, Search } from "lucide-react"
import { Input } from "@/components/ui/input"

export default async function AdminApplicationsPage() {
  const cookieStore = cookies()
  const supabase = createClient(cookieStore)

  // Fetch applications
  const { data: applications, error } = await supabase
    .from("loan_applications")
    .select(`
      *,
      profiles:user_id (
        full_name,
        email
      )
    `)
    .order("created_at", { ascending: false })

  // Mock document data
  const documents = [
    {
      id: 1,
      name: "ID Document",
      user: "John Doe",
      status: "verified",
      confidence: 95,
      date: "2023-12-10",
    },
    {
      id: 2,
      name: "Proof of Income",
      user: "Sarah Smith",
      status: "pending",
      confidence: 0,
      date: "2023-12-12",
    },
    {
      id: 3,
      name: "Bank Statements",
      user: "Michael Johnson",
      status: "in_progress",
      confidence: 65,
      date: "2023-12-11",
    },
    {
      id: 4,
      name: "Proof of Address",
      user: "Emily Davis",
      status: "rejected",
      confidence: 30,
      date: "2023-12-09",
    },
    {
      id: 5,
      name: "ID Document",
      user: "Robert Wilson",
      status: "pending",
      confidence: 0,
      date: "2023-12-13",
    },
  ]

  return (
    <div className="flex-1 space-y-6 p-8 pt-6 animate-in fade-in duration-500">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-green-400 to-blue-500">
            Loan Applications
          </h2>
          <p className="text-muted-foreground">Review and manage all loan applications</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search applications..."
              className="pl-8 bg-black/40 border-white/10 w-[250px]"
            />
          </div>
          <Button variant="outline" className="border-white/10 bg-white/5">
            <Filter className="mr-2 h-4 w-4" />
            Filter
          </Button>
          <Button variant="outline" className="border-white/10 bg-white/5">
            <Download className="mr-2 h-4 w-4" />
            Export
          </Button>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card className="border border-green-500/20 bg-black/40 backdrop-blur-sm shadow-[0_0_15px_rgba(0,200,100,0.15)]">
          <CardHeader>
            <CardTitle className="text-xl font-bold">Application Pipeline</CardTitle>
            <CardDescription>Current status of all loan applications</CardDescription>
          </CardHeader>
          <CardContent>
            <ApprovalPipeline />
          </CardContent>
        </Card>

        <Card className="border border-green-500/20 bg-black/40 backdrop-blur-sm shadow-[0_0_15px_rgba(0,200,100,0.15)]">
          <CardHeader>
            <CardTitle className="text-xl font-bold">AI Risk Analysis</CardTitle>
            <CardDescription>AI-powered risk assessment of applications</CardDescription>
          </CardHeader>
          <CardContent>
            <AIApplicationAnalysis />
          </CardContent>
        </Card>
      </div>

      <DocumentVerification documents={documents} />

      <Card className="border border-green-500/20 bg-black/40 backdrop-blur-sm shadow-[0_0_15px_rgba(0,200,100,0.15)]">
        <CardHeader>
          <CardTitle className="text-xl font-bold">All Applications</CardTitle>
          <CardDescription>Manage and review all loan applications</CardDescription>
        </CardHeader>
        <CardContent>
          {applications && applications.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow className="hover:bg-green-500/5 border-green-500/20">
                  <TableHead>Applicant</TableHead>
                  <TableHead>Loan Amount</TableHead>
                  <TableHead>Purpose</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {applications.map((application) => (
                  <TableRow key={application.id} className="hover:bg-green-500/5 border-green-500/20">
                    <TableCell className="font-medium">
                      {application.profiles?.full_name || "Unknown"}
                      <div className="text-xs text-muted-foreground">{application.profiles?.email || "No email"}</div>
                    </TableCell>
                    <TableCell>${application.loan_amount?.toLocaleString() || "0"}</TableCell>
                    <TableCell>{application.loan_purpose || "N/A"}</TableCell>
                    <TableCell>
                      {application.status === "approved" && (
                        <Badge variant="outline" className="bg-green-500/10 text-green-500 border-green-500/20">
                          <CheckCircle className="mr-1 h-3 w-3" /> Approved
                        </Badge>
                      )}
                      {application.status === "pending" && (
                        <Badge variant="outline" className="bg-amber-500/10 text-amber-500 border-amber-500/20">
                          <Clock className="mr-1 h-3 w-3" /> Pending
                        </Badge>
                      )}
                      {application.status === "rejected" && (
                        <Badge variant="outline" className="bg-red-500/10 text-red-500 border-red-500/20">
                          <XCircle className="mr-1 h-3 w-3" /> Rejected
                        </Badge>
                      )}
                    </TableCell>
                    <TableCell>{new Date(application.created_at).toLocaleDateString()}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button variant="outline" size="sm" className="h-8 w-8 p-0">
                          <Eye className="h-4 w-4" />
                          <span className="sr-only">View</span>
                        </Button>
                        <Button variant="outline" size="sm" className="h-8 w-8 p-0">
                          <FileText className="h-4 w-4" />
                          <span className="sr-only">Documents</span>
                        </Button>
                        <Button variant="default" size="sm" className="h-8 bg-green-600 hover:bg-green-700">
                          <CheckCircle className="h-4 w-4" />
                          <span className="sr-only">Approve</span>
                        </Button>
                        <Button variant="destructive" size="sm" className="h-8">
                          <XCircle className="h-4 w-4" />
                          <span className="sr-only">Reject</span>
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="flex flex-col items-center justify-center p-8 text-center">
              <FileText className="h-12 w-12 text-muted-foreground mb-4" />
              <p className="text-lg font-medium">No applications found</p>
              <p className="text-sm text-muted-foreground">There are no loan applications to display</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

