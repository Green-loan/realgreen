import { createClient } from "@/utils/supabase/server"
import { cookies } from "next/headers"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { UserManagementTable } from "@/components/admin/user-management-table"
import { AddUserForm } from "@/components/admin/add-user-form"
import { Users, UserPlus } from "lucide-react"
import { Badge } from "@/components/ui/badge"

export default async function UsersPage() {
  const cookieStore = cookies()
  const supabase = createClient(cookieStore)

  // Fetch all users
  const { data: users, error } = await supabase.from("profiles").select("*").order("created_at", { ascending: false })

  if (error) {
    console.error("Error fetching users:", error)
  }

  // Get user statistics
  const totalUsers = users?.length || 0
  const newUsersToday =
    users?.filter((user) => {
      const createdAt = new Date(user.created_at)
      const today = new Date()
      return (
        createdAt.getDate() === today.getDate() &&
        createdAt.getMonth() === today.getMonth() &&
        createdAt.getFullYear() === today.getFullYear()
      )
    }).length || 0

  const adminUsers = users?.filter((user) => user.role === "admin").length || 0
  const regularUsers = totalUsers - adminUsers

  return (
    <div className="flex-1 space-y-6 p-8 pt-6 bg-gradient-to-br from-background to-background/80 animate-in fade-in duration-500">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-green-400 to-blue-500">
            User Management
          </h2>
          <p className="text-muted-foreground">Manage users and track registrations</p>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card className="border border-green-500/20 bg-black/40 backdrop-blur-sm shadow-[0_0_15px_rgba(0,200,100,0.15)]">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Users</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-2xl font-bold">{totalUsers}</div>
              <Users className="h-4 w-4 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="border border-green-500/20 bg-black/40 backdrop-blur-sm shadow-[0_0_15px_rgba(0,200,100,0.15)]">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">New Users Today</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-2xl font-bold">{newUsersToday}</div>
              <UserPlus className="h-4 w-4 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="border border-green-500/20 bg-black/40 backdrop-blur-sm shadow-[0_0_15px_rgba(0,200,100,0.15)]">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Admin Users</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-2xl font-bold">{adminUsers}</div>
              <Badge variant="outline" className="bg-purple-500/10 text-purple-500 border-purple-500/20">
                Admin
              </Badge>
            </div>
          </CardContent>
        </Card>

        <Card className="border border-green-500/20 bg-black/40 backdrop-blur-sm shadow-[0_0_15px_rgba(0,200,100,0.15)]">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Regular Users</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-2xl font-bold">{regularUsers}</div>
              <Badge variant="outline" className="bg-green-500/10 text-green-500 border-green-500/20">
                User
              </Badge>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="all-users" className="space-y-6">
        <TabsList className="bg-black/40 backdrop-blur-sm border border-green-500/20 p-1">
          <TabsTrigger
            value="all-users"
            className="data-[state=active]:bg-green-500/10 data-[state=active]:text-green-500"
          >
            <Users className="mr-2 h-4 w-4" />
            All Users
          </TabsTrigger>
          <TabsTrigger
            value="add-user"
            className="data-[state=active]:bg-green-500/10 data-[state=active]:text-green-500"
          >
            <UserPlus className="mr-2 h-4 w-4" />
            Add User
          </TabsTrigger>
        </TabsList>

        <TabsContent value="all-users" className="space-y-6 mt-6">
          <UserManagementTable users={users || []} />
        </TabsContent>

        <TabsContent value="add-user" className="space-y-6 mt-6">
          <AddUserForm />
        </TabsContent>
      </Tabs>
    </div>
  )
}

