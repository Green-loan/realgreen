import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { FuturisticMetricsGrid } from "@/components/admin/futuristic-metrics-grid"
import { FuturisticApplicationsTable } from "@/components/admin/futuristic-applications-table"
import { AIInsightsDashboard } from "@/components/admin/ai-insights-dashboard"
import { CompanyNetworth } from "@/components/admin/company-networth"
import { RealTimeVisitors } from "@/components/admin/real-time-visitors"
import { createClient } from "@/utils/supabase/server"
import { cookies } from "next/headers"
import {
  ArrowUpRight,
  Users,
  DollarSign,
  TrendingUp,
  Wallet,
  Calendar,
  CheckCircle,
  XCircle,
  Clock,
} from "lucide-react"

export default async function AdminDashboardPage() {
  const cookieStore = cookies()
  const supabase = createClient(cookieStore)

  // Fetch recent applications
  const { data: applications } = await supabase
    .from("loan_applications")
    .select("*")
    .order("created_at", { ascending: false })
    .limit(5)

  // Mock data for metrics
  const metrics = [
    {
      title: "Total Applications",
      value: "519",
      change: "+12.5%",
      icon: Users,
      color: "green",
    },
    {
      title: "Monthly Revenue",
      value: "R381,000",
      change: "+15.3%",
      icon: DollarSign,
      color: "blue",
    },
    {
      title: "Approval Rate",
      value: "78.3%",
      change: "+2.1%",
      icon: TrendingUp,
      color: "purple",
    },
    {
      title: "Total Loans",
      value: "R4.2M",
      change: "+8.7%",
      icon: Wallet,
      color: "amber",
    },
  ]

  // Mock data for AI insights
  const insights = [
    {
      id: 1,
      metric: "Risk Assessment",
      value: "Low Risk",
      change: "+5.2%",
      insight: "AI analysis shows decreasing risk profile across loan portfolio compared to last quarter.",
    },
    {
      id: 2,
      metric: "Approval Prediction",
      value: "82%",
      change: "+3.8%",
      insight: "Machine learning model predicts 82% of current applications will be approved.",
    },
    {
      id: 3,
      metric: "Default Probability",
      value: "3.2%",
      change: "-1.5%",
      insight: "Default risk has decreased by 1.5% due to improved applicant quality.",
    },
  ]

  // Mock data for company networth
  const networthData = {
    totalNetworth: 5250000,
    networthChange: 420000,
    networthChangePercentage: 8.7,
    historicalData: [
      { date: "2023-01", networth: 4200000, assets: 5100000, liabilities: 900000, revenue: 320000, expenses: 240000 },
      { date: "2023-02", networth: 4300000, assets: 5200000, liabilities: 900000, revenue: 330000, expenses: 245000 },
      { date: "2023-03", networth: 4350000, assets: 5250000, liabilities: 900000, revenue: 340000, expenses: 250000 },
      { date: "2023-04", networth: 4500000, assets: 5400000, liabilities: 900000, revenue: 350000, expenses: 255000 },
      { date: "2023-05", networth: 4600000, assets: 5500000, liabilities: 900000, revenue: 360000, expenses: 260000 },
      { date: "2023-06", networth: 4750000, assets: 5650000, liabilities: 900000, revenue: 370000, expenses: 265000 },
      { date: "2023-07", networth: 4830000, assets: 5730000, liabilities: 900000, revenue: 380000, expenses: 270000 },
      { date: "2023-08", networth: 4900000, assets: 5800000, liabilities: 900000, revenue: 390000, expenses: 275000 },
      { date: "2023-09", networth: 5000000, assets: 5900000, liabilities: 900000, revenue: 400000, expenses: 280000 },
      { date: "2023-10", networth: 5100000, assets: 6000000, liabilities: 900000, revenue: 410000, expenses: 285000 },
      { date: "2023-11", networth: 5200000, assets: 6100000, liabilities: 900000, revenue: 420000, expenses: 290000 },
      { date: "2023-12", networth: 5250000, assets: 6150000, liabilities: 900000, revenue: 430000, expenses: 295000 },
    ],
    breakdown: [
      { name: "Loan Portfolio", value: 3500000, percentage: 56.9, change: 9.2 },
      { name: "Cash Reserves", value: 1200000, percentage: 19.5, change: 5.3 },
      { name: "Investments", value: 950000, percentage: 15.4, change: 12.1 },
      { name: "Fixed Assets", value: 500000, percentage: 8.2, change: 0 },
    ],
    projections: [
      { date: "2024-01", projected: 5300000, optimistic: 5350000, conservative: 5250000 },
      { date: "2024-02", projected: 5400000, optimistic: 5500000, conservative: 5300000 },
      { date: "2024-03", projected: 5500000, optimistic: 5650000, conservative: 5350000 },
      { date: "2024-04", projected: 5600000, optimistic: 5800000, conservative: 5400000 },
      { date: "2024-05", projected: 5700000, optimistic: 5950000, conservative: 5450000 },
      { date: "2024-06", projected: 5800000, optimistic: 6100000, conservative: 5500000 },
    ],
  }

  return (
    <div className="flex-1 space-y-6 p-8 pt-6 animate-in fade-in duration-500">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-green-400 to-blue-500">
            Admin Dashboard
          </h2>
          <p className="text-muted-foreground">Welcome back! Here's an overview of your loan management system.</p>
        </div>
        <div className="flex items-center gap-2">
          <Card className="bg-black/40 backdrop-blur-sm border-white/10">
            <CardContent className="flex items-center gap-2 p-2">
              <Calendar className="h-4 w-4 text-green-500" />
              <span className="text-sm font-medium">{new Date().toLocaleDateString()}</span>
            </CardContent>
          </Card>
        </div>
      </div>

      <FuturisticMetricsGrid metrics={metrics} />

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        <Card className="border border-green-500/20 bg-black/40 backdrop-blur-sm shadow-[0_0_15px_rgba(0,200,100,0.15)] lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-xl font-bold flex items-center">
              <TrendingUp className="mr-2 h-5 w-5 text-green-500" />
              Loan Applications Overview
            </CardTitle>
            <CardDescription>Recent loan applications and their status</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-8">
              <div className="grid grid-cols-3 gap-4">
                <div className="flex flex-col items-center justify-center p-4 rounded-lg bg-green-500/10 border border-green-500/20">
                  <CheckCircle className="h-8 w-8 text-green-500 mb-2" />
                  <div className="text-2xl font-bold">78</div>
                  <div className="text-xs text-muted-foreground">Approved</div>
                </div>
                <div className="flex flex-col items-center justify-center p-4 rounded-lg bg-amber-500/10 border border-amber-500/20">
                  <Clock className="h-8 w-8 text-amber-500 mb-2" />
                  <div className="text-2xl font-bold">24</div>
                  <div className="text-xs text-muted-foreground">Pending</div>
                </div>
                <div className="flex flex-col items-center justify-center p-4 rounded-lg bg-red-500/10 border border-red-500/20">
                  <XCircle className="h-8 w-8 text-red-500 mb-2" />
                  <div className="text-2xl font-bold">12</div>
                  <div className="text-xs text-muted-foreground">Rejected</div>
                </div>
              </div>

              <div className="space-y-4">
                {applications?.map((application) => (
                  <div
                    key={application.id}
                    className="flex items-center justify-between p-4 rounded-lg bg-white/5 border border-white/10 hover:bg-white/10 transition-colors"
                  >
                    <div className="flex items-center gap-4">
                      <div
                        className={`h-10 w-10 rounded-full flex items-center justify-center ${
                          application.status === "approved"
                            ? "bg-green-500/20 text-green-500"
                            : application.status === "pending"
                              ? "bg-amber-500/20 text-amber-500"
                              : "bg-red-500/20 text-red-500"
                        }`}
                      >
                        {application.status === "approved" ? (
                          <CheckCircle className="h-5 w-5" />
                        ) : application.status === "pending" ? (
                          <Clock className="h-5 w-5" />
                        ) : (
                          <XCircle className="h-5 w-5" />
                        )}
                      </div>
                      <div>
                        <div className="font-medium">
                          Loan Application #{application.id}{" "}
                          <span className="text-muted-foreground">
                            - R{application.loan_amount?.toLocaleString() || "0"}
                          </span>
                        </div>
                        <div className="text-sm text-muted-foreground">
                          {new Date(application.created_at).toLocaleDateString()}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge
                        variant="outline"
                        className={
                          application.status === "approved"
                            ? "bg-green-500/10 text-green-500 border-green-500/20"
                            : application.status === "pending"
                              ? "bg-amber-500/10 text-amber-500 border-amber-500/20"
                              : "bg-red-500/10 text-red-500 border-red-500/20"
                        }
                      >
                        {application.status}
                      </Badge>
                      <ArrowUpRight className="h-4 w-4 text-muted-foreground" />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border border-green-500/20 bg-black/40 backdrop-blur-sm shadow-[0_0_15px_rgba(0,200,100,0.15)]">
          <CardHeader>
            <CardTitle className="text-xl font-bold flex items-center">
              <Calendar className="mr-2 h-5 w-5 text-green-500" />
              Upcoming Payments
            </CardTitle>
            <CardDescription>Next 7 days loan repayments</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                {
                  name: "John Doe",
                  amount: 5000,
                  date: "2023-12-20",
                  status: "on-time",
                },
                {
                  name: "Sarah Smith",
                  amount: 3500,
                  date: "2023-12-21",
                  status: "on-time",
                },
                {
                  name: "Michael Johnson",
                  amount: 7500,
                  date: "2023-12-22",
                  status: "at-risk",
                },
                {
                  name: "Emily Davis",
                  amount: 2000,
                  date: "2023-12-23",
                  status: "on-time",
                },
                {
                  name: "Robert Wilson",
                  amount: 10000,
                  date: "2023-12-24",
                  status: "late",
                },
              ].map((payment, index) => (
                <div
                  key={index}
                  className="flex items-center justify-between p-3 rounded-lg bg-white/5 border border-white/10"
                >
                  <div>
                    <div className="font-medium">{payment.name}</div>
                    <div className="text-sm text-muted-foreground">
                      Due: {new Date(payment.date).toLocaleDateString()}
                    </div>
                  </div>
                  <div className="flex flex-col items-end">
                    <div className="font-medium">R{payment.amount.toLocaleString()}</div>
                    <Badge
                      variant="outline"
                      className={
                        payment.status === "on-time"
                          ? "bg-green-500/10 text-green-500 border-green-500/20"
                          : payment.status === "at-risk"
                            ? "bg-amber-500/10 text-amber-500 border-amber-500/20"
                            : "bg-red-500/10 text-red-500 border-red-500/20"
                      }
                    >
                      {payment.status === "on-time" ? "On Time" : payment.status === "at-risk" ? "At Risk" : "Late"}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <AIInsightsDashboard insights={insights} />

      <div className="grid gap-6 md:grid-cols-2">
        <CompanyNetworth data={networthData} />
        <RealTimeVisitors />
      </div>

      <FuturisticApplicationsTable applications={applications || []} />
    </div>
  )
}

