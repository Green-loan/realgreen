import type { ReactNode } from "react"
import { redirect } from "next/navigation"
import { createClient } from "@/utils/supabase/server"
import { AdminSidebar } from "@/components/admin/admin-sidebar"
import { AdminHeader } from "@/components/admin/admin-header"
import { ThemeProvider } from "@/components/theme-provider"

export default async function AdminLayout({ children }: { children: ReactNode }) {
  const supabase = createClient()

  const {
    data: { session },
  } = await supabase.auth.getSession()

  if (!session) {
    redirect("/login")
  }

  // Get the user's role
  const { data: userProfile } = await supabase.from("profiles").select("role").eq("id", session.user.id).single()

  // If not an admin, redirect to user dashboard
  if (!userProfile || userProfile.role !== "admin") {
    redirect("/dashboard")
  }

  return (
    <ThemeProvider attribute="class" defaultTheme="dark" enableSystem={false}>
      <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-black text-white">
        <div className="relative flex min-h-screen">
          <AdminSidebar />
          <div className="flex-1 flex flex-col">
            <AdminHeader />
            <main className="flex-1 pt-16 md:pl-64">
              <div className="relative">
                {/* Futuristic background elements */}
                <div className="absolute inset-0 overflow-hidden pointer-events-none">
                  <div className="absolute top-0 left-0 w-full h-[500px] bg-gradient-to-br from-green-500/5 to-blue-500/5 rounded-full blur-3xl" />
                  <div className="absolute bottom-0 right-0 w-full h-[500px] bg-gradient-to-br from-purple-500/5 to-green-500/5 rounded-full blur-3xl" />
                  <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-gradient-to-br from-green-500/3 to-blue-500/3 rounded-full blur-3xl" />
                  <div className="grid grid-cols-8 h-screen w-screen">
                    {Array.from({ length: 8 }).map((_, i) => (
                      <div key={i} className="border-r border-white/5 h-full" />
                    ))}
                  </div>
                  <div className="grid grid-rows-8 h-screen w-screen">
                    {Array.from({ length: 8 }).map((_, i) => (
                      <div key={i} className="border-b border-white/5 w-full" />
                    ))}
                  </div>
                </div>
                {children}
              </div>
            </main>
          </div>
        </div>
      </div>
    </ThemeProvider>
  )
}

