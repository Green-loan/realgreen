import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { createClient } from "@/utils/supabase/server"
import { cookies } from "next/headers"
import { AlertTriangle, Shield, TrendingUp, TrendingDown, Eye, FileText, Settings } from "lucide-react"

export default async function RiskManagementPage() {
  const cookieStore = cookies()
  const supabase = createClient(cookieStore)

  // Mock risk alerts
  const riskAlerts = [
    {
      id: 1,
      type: "high_risk_application",
      description: "High risk application detected",
      applicant: "Michael Chen",
      severity: "high",
      date: "2023-03-15",
    },
    {
      id: 2,
      type: "unusual_activity",
      description: "Unusual activity on account",
      applicant: "Sarah Johnson",
      severity: "medium",
      date: "2023-03-14",
    },
    {
      id: 3,
      type: "verification_failed",
      description: "Document verification failed",
      applicant: "David Kim",
      severity: "high",
      date: "2023-03-13",
    },
    {
      id: 4,
      type: "multiple_applications",
      description: "Multiple applications from same IP",
      applicant: "Emma Rodriguez",
      severity: "medium",
      date: "2023-03-12",
    },
    {
      id: 5,
      type: "credit_score_drop",
      description: "Significant credit score drop",
      applicant: "James Wilson",
      severity: "low",
      date: "2023-03-11",
    },
  ]

  // Mock risk metrics
  const riskMetrics = [
    { name: "Default Rate", value: "2.3%", trend: "down", change: "0.5%" },
    { name: "High Risk Applications", value: "8.7%", trend: "up", change: "1.2%" },
    { name: "Fraud Detection Rate", value: "99.2%", trend: "up", change: "0.3%" },
    { name: "Average Risk Score", value: "76/100", trend: "up", change: "2 points" },
  ]

  return (
    <div className="flex-1 space-y-4 p-8 pt-6 animate-in fade-in duration-500">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold tracking-tight">Risk Management</h2>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm">
            <Settings className="mr-2 h-4 w-4" />
            Risk Settings
          </Button>
          <Button variant="outline" size="sm">
            <FileText className="mr-2 h-4 w-4" />
            Generate Report
          </Button>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {riskMetrics.map((metric, index) => (
          <Card key={index}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">{metric.name}</CardTitle>
              <Shield className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{metric.value}</div>
              <div className="flex items-center pt-1">
                {metric.trend === "up" ? (
                  <TrendingUp
                    className={`mr-1 h-3 w-3 ${
                      metric.name === "Default Rate" || metric.name === "High Risk Applications"
                        ? "text-red-500"
                        : "text-green-500"
                    }`}
                  />
                ) : (
                  <TrendingDown
                    className={`mr-1 h-3 w-3 ${
                      metric.name === "Default Rate" || metric.name === "High Risk Applications"
                        ? "text-green-500"
                        : "text-red-500"
                    }`}
                  />
                )}
                <span
                  className={`text-xs ${
                    (
                      metric.trend === "up" &&
                        (metric.name === "Default Rate" || metric.name === "High Risk Applications")
                    ) ||
                    (
                      metric.trend === "down" &&
                        !(metric.name === "Default Rate" || metric.name === "High Risk Applications")
                    )
                      ? "text-red-500"
                      : "text-green-500"
                  }`}
                >
                  {metric.trend === "up" ? "+" : "-"}
                  {metric.change} from last month
                </span>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Tabs defaultValue="alerts" className="space-y-4">
        <TabsList>
          <TabsTrigger value="alerts">Risk Alerts</TabsTrigger>
          <TabsTrigger value="analysis">Risk Analysis</TabsTrigger>
        </TabsList>

        <TabsContent value="alerts" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Active Risk Alerts</CardTitle>
              <CardDescription>Review and manage risk alerts</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Alert Type</TableHead>
                    <TableHead>Description</TableHead>
                    <TableHead>Applicant</TableHead>
                    <TableHead>Severity</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {riskAlerts.map((alert) => (
                    <TableRow key={alert.id}>
                      <TableCell className="font-medium">
                        {alert.type
                          .split("_")
                          .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
                          .join(" ")}
                      </TableCell>
                      <TableCell>{alert.description}</TableCell>
                      <TableCell>{alert.applicant}</TableCell>
                      <TableCell>
                        <Badge
                          variant="outline"
                          className={`
                          ${
                            alert.severity === "high"
                              ? "bg-red-500/10 text-red-500"
                              : alert.severity === "medium"
                                ? "bg-yellow-500/10 text-yellow-500"
                                : "bg-blue-500/10 text-blue-500"
                          }
                        `}
                        >
                          <AlertTriangle className="mr-1 h-3 w-3" />
                          {alert.severity.charAt(0).toUpperCase() + alert.severity.slice(1)}
                        </Badge>
                      </TableCell>
                      <TableCell>{alert.date}</TableCell>
                      <TableCell className="text-right">
                        <Button variant="outline" size="sm">
                          <Eye className="mr-1 h-4 w-4" />
                          Review
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analysis" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Risk Factors</CardTitle>
                <CardDescription>Key factors affecting risk assessment</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <div className="flex items-center">
                        <div className="h-3 w-3 rounded-full bg-red-500 mr-2" />
                        <span>Credit Score</span>
                      </div>
                      <span className="font-medium">35%</span>
                    </div>
                    <Progress value={35} className="h-2 bg-muted" indicatorClassName="bg-red-500" />
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <div className="flex items-center">
                        <div className="h-3 w-3 rounded-full bg-yellow-500 mr-2" />
                        <span>Income Verification</span>
                      </div>
                      <span className="font-medium">25%</span>
                    </div>
                    <Progress value={25} className="h-2 bg-muted" indicatorClassName="bg-yellow-500" />
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <div className="flex items-center">
                        <div className="h-3 w-3 rounded-full bg-blue-500 mr-2" />
                        <span>Debt-to-Income Ratio</span>
                      </div>
                      <span className="font-medium">20%</span>
                    </div>
                    <Progress value={20} className="h-2 bg-muted" indicatorClassName="bg-blue-500" />
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <div className="flex items-center">
                        <div className="h-3 w-3 rounded-full bg-green-500 mr-2" />
                        <span>Employment History</span>
                      </div>
                      <span className="font-medium">15%</span>
                    </div>
                    <Progress value={15} className="h-2 bg-muted" indicatorClassName="bg-green-500" />
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <div className="flex items-center">
                        <div className="h-3 w-3 rounded-full bg-purple-500 mr-2" />
                        <span>Previous Loans</span>
                      </div>
                      <span className="font-medium">5%</span>
                    </div>
                    <Progress value={5} className="h-2 bg-muted" indicatorClassName="bg-purple-500" />
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Risk Threshold Analysis</CardTitle>
                <CardDescription>Current risk thresholds and recommendations</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Low Risk Threshold</span>
                      <Badge variant="outline" className="bg-green-500/10 text-green-500">
                        80+ Score
                      </Badge>
                    </div>
                    <div className="text-sm text-muted-foreground">
                      Applications with a risk score of 80 or higher are considered low risk and are recommended for
                      automatic approval.
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Medium Risk Threshold</span>
                      <Badge variant="outline" className="bg-yellow-500/10 text-yellow-500">
                        60-79 Score
                      </Badge>
                    </div>
                    <div className="text-sm text-muted-foreground">
                      Applications with a risk score between 60 and 79 require manual review before approval.
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">High Risk Threshold</span>
                      <Badge variant="outline" className="bg-red-500/10 text-red-500">
                        Below 60 Score
                      </Badge>
                    </div>
                    <div className="text-sm text-muted-foreground">
                      Applications with a risk score below 60 are considered high risk and are recommended for rejection
                      or additional verification.
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

