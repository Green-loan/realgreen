"use server"

import { createClient } from "@/utils/supabase/server"
import { cookies } from "next/headers"
import { revalidatePath } from "next/cache"

export async function addStokvelMember(formData: FormData) {
  const cookieStore = cookies()
  const supabase = createClient(cookieStore)

  const name = formData.get("name") as string
  const email = formData.get("email") as string
  const phone = formData.get("phone") as string

  // Get the current highest position number
  const { data: members } = await supabase
    .from("stokvel_members")
    .select("position_number")
    .order("position_number", { ascending: false })
    .limit(1)

  const nextPosition = members && members.length > 0 ? members[0].position_number + 1 : 1

  // Insert the new member
  const { error } = await supabase.from("stokvel_members").insert({
    name,
    email,
    phone,
    position_number: nextPosition,
    total_contribution: 0,
    last_payment_date: new Date().toISOString(),
    last_payment_amount: 0,
    payout_status: "pending",
    next_payout_date: null,
    notes: "",
  })

  if (error) {
    return { success: false, error: error.message }
  }

  revalidatePath("/admin/stokvel")
  return { success: true }
}

export async function updateStokvelMember(memberId: number, data: any) {
  const cookieStore = cookies()
  const supabase = createClient(cookieStore)

  const { error } = await supabase.from("stokvel_members").update(data).eq("id", memberId)

  if (error) {
    return { success: false, error: error.message }
  }

  revalidatePath("/admin/stokvel")
  return { success: true }
}

export async function deleteStokvelMember(memberId: number) {
  const cookieStore = cookies()
  const supabase = createClient(cookieStore)

  const { error } = await supabase.from("stokvel_members").delete().eq("id", memberId)

  if (error) {
    return { success: false, error: error.message }
  }

  revalidatePath("/admin/stokvel")
  return { success: true }
}

export async function rotateStokvelPositions() {
  const cookieStore = cookies()
  const supabase = createClient(cookieStore)

  // Get all members ordered by position
  const { data: members, error: fetchError } = await supabase
    .from("stokvel_members")
    .select("id, position_number")
    .order("position_number")

  if (fetchError || !members) {
    return { success: false, error: fetchError?.message || "Failed to fetch members" }
  }

  const maxPosition = members.length

  // Update each member's position
  for (const member of members) {
    const newPosition = member.position_number === maxPosition ? 1 : member.position_number + 1

    const { error } = await supabase
      .from("stokvel_members")
      .update({ position_number: newPosition })
      .eq("id", member.id)

    if (error) {
      return { success: false, error: error.message }
    }
  }

  revalidatePath("/admin/stokvel")
  return { success: true }
}

export async function addStokvelPayment(memberId: number, amount: number, date: string) {
  const cookieStore = cookies()
  const supabase = createClient(cookieStore)

  // Get the current member data
  const { data: member, error: fetchError } = await supabase
    .from("stokvel_members")
    .select("total_contribution")
    .eq("id", memberId)
    .single()

  if (fetchError || !member) {
    return { success: false, error: fetchError?.message || "Failed to fetch member" }
  }

  // Update the member with the new payment
  const { error } = await supabase
    .from("stokvel_members")
    .update({
      total_contribution: member.total_contribution + amount,
      last_payment_date: date,
      last_payment_amount: amount,
    })
    .eq("id", memberId)

  if (error) {
    return { success: false, error: error.message }
  }

  // Add to payment history
  const { error: historyError } = await supabase.from("stokvel_payments").insert({
    member_id: memberId,
    amount,
    payment_date: date,
    payment_type: "contribution",
  })

  if (historyError) {
    return { success: false, error: historyError.message }
  }

  revalidatePath("/admin/stokvel")
  return { success: true }
}

export async function changeStokvelPosition(memberId: number, newPosition: number) {
  const cookieStore = cookies()
  const supabase = createClient(cookieStore)

  // Get the current position of the member
  const { data: member, error: fetchError } = await supabase
    .from("stokvel_members")
    .select("position_number")
    .eq("id", memberId)
    .single()

  if (fetchError || !member) {
    return { success: false, error: fetchError?.message || "Failed to fetch member" }
  }

  const oldPosition = member.position_number

  // If the position is the same, do nothing
  if (oldPosition === newPosition) {
    return { success: true }
  }

  // Update all affected members
  if (newPosition < oldPosition) {
    // Moving up - increment positions for members in between
    const { error } = await supabase
      .from("stokvel_members")
      .update({ position_number: supabase.sql`position_number + 1` })
      .gte("position_number", newPosition)
      .lt("position_number", oldPosition)

    if (error) {
      return { success: false, error: error.message }
    }
  } else {
    // Moving down - decrement positions for members in between
    const { error } = await supabase
      .from("stokvel_members")
      .update({ position_number: supabase.sql`position_number - 1` })
      .gt("position_number", oldPosition)
      .lte("position_number", newPosition)

    if (error) {
      return { success: false, error: error.message }
    }
  }

  // Update the member's position
  const { error } = await supabase.from("stokvel_members").update({ position_number: newPosition }).eq("id", memberId)

  if (error) {
    return { success: false, error: error.message }
  }

  revalidatePath("/admin/stokvel")
  return { success: true }
}

