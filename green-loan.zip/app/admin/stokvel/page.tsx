import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { createClient } from "@/utils/supabase/server"
import { cookies } from "next/headers"
import { StokvelMembersTable } from "@/components/admin/stokvel-members-table"
import { Button } from "@/components/ui/button"
import { Plus, RotateCcw, Download, Upload } from "lucide-react"

export default async function StokvelPage() {
  const cookieStore = cookies()
  const supabase = createClient(cookieStore)

  // Fetch stokvel members data
  const { data: members } = await supabase.from("stokvel_members").select("*").order("position_number")

  // If the table doesn't exist yet, we'll use mock data
  const stokvelMembers = members || [
    {
      id: 1,
      name: "John Doe",
      email: "john@example.com",
      phone: "+27 71 234 5678",
      position_number: 1,
      total_contribution: 5000,
      last_payment_date: "2023-12-15",
      last_payment_amount: 500,
      payout_status: "pending",
      next_payout_date: "2024-06-15",
      notes: "Founding member",
      created_at: "2023-01-10T08:30:00Z",
    },
    {
      id: 2,
      name: "Sarah Johnson",
      email: "sarah@example.com",
      phone: "+27 82 345 6789",
      position_number: 2,
      total_contribution: 4500,
      last_payment_date: "2023-12-14",
      last_payment_amount: 500,
      payout_status: "pending",
      next_payout_date: "2024-07-15",
      notes: "Referred by John",
      created_at: "2023-01-15T10:15:00Z",
    },
    {
      id: 3,
      name: "Michael Ndlovu",
      email: "michael@example.com",
      phone: "+27 73 456 7890",
      position_number: 3,
      total_contribution: 5000,
      last_payment_date: "2023-12-16",
      last_payment_amount: 500,
      payout_status: "pending",
      next_payout_date: "2024-08-15",
      notes: "",
      created_at: "2023-01-20T09:45:00Z",
    },
    {
      id: 4,
      name: "Thabo Molefe",
      email: "thabo@example.com",
      phone: "+27 84 567 8901",
      position_number: 4,
      total_contribution: 4000,
      last_payment_date: "2023-12-10",
      last_payment_amount: 500,
      payout_status: "pending",
      next_payout_date: "2024-09-15",
      notes: "Late payment in November",
      created_at: "2023-02-05T11:30:00Z",
    },
    {
      id: 5,
      name: "Lerato Khumalo",
      email: "lerato@example.com",
      phone: "+27 76 678 9012",
      position_number: 5,
      total_contribution: 5000,
      last_payment_date: "2023-12-15",
      last_payment_amount: 500,
      payout_status: "completed",
      next_payout_date: null,
      notes: "Received payout in May",
      created_at: "2023-02-10T14:20:00Z",
    },
    {
      id: 6,
      name: "Nomsa Dlamini",
      email: "nomsa@example.com",
      phone: "+27 83 789 0123",
      position_number: 6,
      total_contribution: 4500,
      last_payment_date: "2023-12-14",
      last_payment_amount: 500,
      payout_status: "pending",
      next_payout_date: "2024-11-15",
      notes: "",
      created_at: "2023-02-15T08:45:00Z",
    },
    {
      id: 7,
      name: "David Smith",
      email: "david@example.com",
      phone: "+27 74 890 1234",
      position_number: 7,
      total_contribution: 4000,
      last_payment_date: "2023-12-13",
      last_payment_amount: 500,
      payout_status: "pending",
      next_payout_date: "2024-12-15",
      notes: "New member",
      created_at: "2023-03-01T13:10:00Z",
    },
    {
      id: 8,
      name: "Precious Nkosi",
      email: "precious@example.com",
      phone: "+27 78 901 2345",
      position_number: 8,
      total_contribution: 3500,
      last_payment_date: "2023-12-12",
      last_payment_amount: 500,
      payout_status: "pending",
      next_payout_date: "2025-01-15",
      notes: "",
      created_at: "2023-03-10T15:30:00Z",
    },
    {
      id: 9,
      name: "Sipho Mabaso",
      email: "sipho@example.com",
      phone: "+27 79 012 3456",
      position_number: 9,
      total_contribution: 4500,
      last_payment_date: "2023-12-15",
      last_payment_amount: 500,
      payout_status: "pending",
      next_payout_date: "2025-02-15",
      notes: "",
      created_at: "2023-03-15T09:20:00Z",
    },
    {
      id: 10,
      name: "Zanele Zulu",
      email: "zanele@example.com",
      phone: "+27 72 123 4567",
      position_number: 10,
      total_contribution: 5000,
      last_payment_date: "2023-12-16",
      last_payment_amount: 500,
      payout_status: "pending",
      next_payout_date: "2025-03-15",
      notes: "Group treasurer",
      created_at: "2023-03-20T10:45:00Z",
    },
  ]

  return (
    <div className="flex-1 space-y-6 p-8 pt-6 bg-gradient-to-br from-background to-background/80 animate-in fade-in duration-500">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-green-400 to-blue-500">
            Stokvel Management
          </h2>
          <p className="text-muted-foreground">Manage members, positions, and payments for the savings group</p>
        </div>
        <div className="flex items-center space-x-2">
          <Button
            variant="outline"
            className="border-green-500/20 bg-green-500/10 text-green-500 hover:bg-green-500/20"
          >
            <Upload className="mr-2 h-4 w-4" />
            Import
          </Button>
          <Button
            variant="outline"
            className="border-green-500/20 bg-green-500/10 text-green-500 hover:bg-green-500/20"
          >
            <Download className="mr-2 h-4 w-4" />
            Export
          </Button>
          <Button>
            <Plus className="mr-2 h-4 w-4" />
            Add Member
          </Button>
        </div>
      </div>

      <Card className="border border-green-500/20 bg-black/40 backdrop-blur-sm shadow-[0_0_15px_rgba(0,200,100,0.15)]">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-xl font-bold">Stokvel Members</CardTitle>
              <CardDescription>Manage member positions, contributions, and payouts</CardDescription>
            </div>
            <Button
              variant="outline"
              className="border-green-500/20 bg-green-500/10 text-green-500 hover:bg-green-500/20"
            >
              <RotateCcw className="mr-2 h-4 w-4" />
              Rotate Positions
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <StokvelMembersTable members={stokvelMembers} />
        </CardContent>
      </Card>

      <div className="grid gap-6 md:grid-cols-2">
        <Card className="border border-green-500/20 bg-black/40 backdrop-blur-sm shadow-[0_0_15px_rgba(0,200,100,0.15)]">
          <CardHeader>
            <CardTitle className="text-xl font-bold">Stokvel Overview</CardTitle>
            <CardDescription>Key metrics and information about the savings group</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <p className="text-sm text-muted-foreground">Total Members</p>
                  <p className="text-2xl font-bold">{stokvelMembers.length}</p>
                </div>
                <div className="space-y-2">
                  <p className="text-sm text-muted-foreground">Total Contributions</p>
                  <p className="text-2xl font-bold">
                    R{stokvelMembers.reduce((sum, member) => sum + member.total_contribution, 0).toLocaleString()}
                  </p>
                </div>
                <div className="space-y-2">
                  <p className="text-sm text-muted-foreground">Monthly Contribution</p>
                  <p className="text-2xl font-bold">R500</p>
                </div>
                <div className="space-y-2">
                  <p className="text-sm text-muted-foreground">Next Payout Date</p>
                  <p className="text-2xl font-bold">Jan 15, 2024</p>
                </div>
              </div>
              <div className="pt-4">
                <h4 className="text-sm font-medium mb-2">Payout Schedule</h4>
                <div className="space-y-2">
                  {stokvelMembers
                    .filter((member) => member.payout_status === "pending" && member.next_payout_date)
                    .sort((a, b) => new Date(a.next_payout_date).getTime() - new Date(b.next_payout_date).getTime())
                    .slice(0, 3)
                    .map((member) => (
                      <div
                        key={member.id}
                        className="flex items-center justify-between p-2 rounded-md bg-green-500/5 border border-green-500/10"
                      >
                        <div className="flex items-center gap-2">
                          <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary">
                            <span className="text-xs font-bold text-primary-foreground">{member.position_number}</span>
                          </div>
                          <span>{member.name}</span>
                        </div>
                        <span className="text-sm">
                          {new Date(member.next_payout_date).toLocaleDateString("en-ZA", {
                            year: "numeric",
                            month: "short",
                            day: "numeric",
                          })}
                        </span>
                      </div>
                    ))}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border border-green-500/20 bg-black/40 backdrop-blur-sm shadow-[0_0_15px_rgba(0,200,100,0.15)]">
          <CardHeader>
            <CardTitle className="text-xl font-bold">Recent Activity</CardTitle>
            <CardDescription>Latest payments and position changes</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                {
                  id: 1,
                  type: "payment",
                  member: "John Doe",
                  amount: 500,
                  date: "Dec 15, 2023",
                  note: "Monthly contribution",
                },
                {
                  id: 2,
                  type: "position",
                  member: "Sarah Johnson",
                  from: 3,
                  to: 2,
                  date: "Dec 10, 2023",
                  note: "Position swap with Michael",
                },
                {
                  id: 3,
                  type: "payment",
                  member: "Michael Ndlovu",
                  amount: 500,
                  date: "Dec 16, 2023",
                  note: "Monthly contribution",
                },
                {
                  id: 4,
                  type: "payout",
                  member: "Lerato Khumalo",
                  amount: 5000,
                  date: "May 15, 2023",
                  note: "Regular payout",
                },
                {
                  id: 5,
                  type: "payment",
                  member: "Thabo Molefe",
                  amount: 500,
                  date: "Dec 10, 2023",
                  note: "Monthly contribution",
                },
              ].map((activity) => (
                <div
                  key={activity.id}
                  className="flex items-start space-x-3 p-3 rounded-lg bg-green-500/5 border border-green-500/10"
                >
                  <div
                    className={`p-2 rounded-full ${
                      activity.type === "payment"
                        ? "bg-blue-500/10 text-blue-500"
                        : activity.type === "position"
                          ? "bg-amber-500/10 text-amber-500"
                          : "bg-green-500/10 text-green-500"
                    }`}
                  >
                    {activity.type === "payment" ? (
                      <Plus className="h-4 w-4" />
                    ) : activity.type === "position" ? (
                      <RotateCcw className="h-4 w-4" />
                    ) : (
                      <Download className="h-4 w-4" />
                    )}
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium">
                      {activity.type === "payment"
                        ? `${activity.member} paid R${activity.amount}`
                        : activity.type === "position"
                          ? `${activity.member} moved from position ${activity.from} to ${activity.to}`
                          : `${activity.member} received R${activity.amount} payout`}
                    </p>
                    <div className="flex justify-between">
                      <p className="text-xs text-muted-foreground">{activity.note}</p>
                      <p className="text-xs text-muted-foreground">{activity.date}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

