import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { createClient } from "@/utils/supabase/server"
import { cookies } from "next/headers"
import { CheckCircle, XCircle, AlertTriangle, Clock, Eye, ThumbsUp, ThumbsDown } from "lucide-react"

export default async function ApprovalsPage() {
  const cookieStore = cookies()
  const supabase = createClient(cookieStore)

  // Fetch pending applications
  const { data: pendingApplications } = await supabase
    .from("loan_applications")
    .select(`
      *,
      profiles:user_id (
        full_name,
        email
      )
    `)
    .eq("status", "pending")
    .order("created_at", { ascending: false })

  // Mock risk assessment data
  const riskAssessments = [
    { id: 1, score: 85, recommendation: "approve", flags: 0 },
    { id: 2, score: 72, recommendation: "approve", flags: 1 },
    { id: 3, score: 65, recommendation: "review", flags: 2 },
    { id: 4, score: 45, recommendation: "reject", flags: 3 },
    { id: 5, score: 92, recommendation: "approve", flags: 0 },
  ]

  return (
    <div className="flex-1 space-y-4 p-8 pt-6 animate-in fade-in duration-500">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold tracking-tight">Loan Approvals</h2>
        <div className="flex items-center gap-2">
          <Badge variant="outline" className="bg-green-500/10 text-green-500">
            <CheckCircle className="mr-1 h-3 w-3" /> 24 Approved Today
          </Badge>
          <Badge variant="outline" className="bg-red-500/10 text-red-500">
            <XCircle className="mr-1 h-3 w-3" /> 8 Rejected Today
          </Badge>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Pending Approvals</CardTitle>
          <CardDescription>Review and approve pending loan applications</CardDescription>
        </CardHeader>
        <CardContent>
          {pendingApplications && pendingApplications.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Applicant</TableHead>
                  <TableHead>Loan Details</TableHead>
                  <TableHead>Risk Score</TableHead>
                  <TableHead>AI Recommendation</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {pendingApplications.map((application, index) => {
                  const riskAssessment = riskAssessments[index % riskAssessments.length]

                  return (
                    <TableRow key={application.id}>
                      <TableCell className="font-medium">
                        {application.profiles?.full_name || "Unknown"}
                        <div className="text-xs text-muted-foreground">{application.profiles?.email || "No email"}</div>
                      </TableCell>
                      <TableCell>
                        <div className="font-medium">${application.loan_amount?.toLocaleString() || "0"}</div>
                        <div className="text-xs text-muted-foreground">{application.loan_purpose || "N/A"}</div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center">
                          <div
                            className={`h-6 w-6 rounded-full flex items-center justify-center text-xs font-medium ${
                              riskAssessment.score >= 80
                                ? "bg-green-500/20 text-green-600"
                                : riskAssessment.score >= 60
                                  ? "bg-yellow-500/20 text-yellow-600"
                                  : "bg-red-500/20 text-red-600"
                            }`}
                          >
                            {riskAssessment.score}
                          </div>
                          <div className="ml-2">
                            {riskAssessment.flags > 0 && (
                              <Badge variant="outline" className="bg-yellow-500/10 text-yellow-500">
                                <AlertTriangle className="mr-1 h-3 w-3" /> {riskAssessment.flags} flags
                              </Badge>
                            )}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        {riskAssessment.recommendation === "approve" ? (
                          <Badge variant="outline" className="bg-green-500/10 text-green-500">
                            <ThumbsUp className="mr-1 h-3 w-3" /> Approve
                          </Badge>
                        ) : riskAssessment.recommendation === "review" ? (
                          <Badge variant="outline" className="bg-yellow-500/10 text-yellow-500">
                            <Clock className="mr-1 h-3 w-3" /> Review
                          </Badge>
                        ) : (
                          <Badge variant="outline" className="bg-red-500/10 text-red-500">
                            <ThumbsDown className="mr-1 h-3 w-3" /> Reject
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell>{new Date(application.created_at).toLocaleDateString()}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button variant="outline" size="sm">
                            <Eye className="mr-1 h-4 w-4" />
                            Review
                          </Button>
                          <Button variant="default" size="sm" className="bg-green-600 hover:bg-green-700">
                            <CheckCircle className="mr-1 h-4 w-4" />
                            Approve
                          </Button>
                          <Button variant="destructive" size="sm">
                            <XCircle className="mr-1 h-4 w-4" />
                            Reject
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  )
                })}
              </TableBody>
            </Table>
          ) : (
            <div className="flex flex-col items-center justify-center p-8 text-center">
              <CheckCircle className="h-12 w-12 text-green-500 mb-4" />
              <p className="text-lg font-medium">All caught up!</p>
              <p className="text-sm text-muted-foreground">No pending applications to review</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

