"use client"

import { useSearchParams } from "next/navigation"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { Mail } from "lucide-react"

export default function VerifyPage() {
  const searchParams = useSearchParams()
  const email = searchParams.get("email") || ""

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-teal-600/5 via-transparent to-blue-600/5">
      <Card className="max-w-md w-full p-8 shadow-lg border-teal-600/20">
        <div className="flex flex-col items-center text-center space-y-6">
          <div className="w-16 h-16 bg-teal-100 rounded-full flex items-center justify-center">
            <Mail className="h-8 w-8 text-teal-600" />
          </div>

          <div className="space-y-2">
            <h1 className="text-2xl font-bold">Check your email</h1>
            <p className="text-muted-foreground">
              We've sent a verification link to <span className="font-medium text-foreground">{email}</span>
            </p>
          </div>

          <div className="space-y-4 w-full">
            <p className="text-sm text-muted-foreground">
              Click the link in the email to verify your account. If you don't see it, check your spam folder.
            </p>

            <Button asChild className="w-full">
              <Link href="/signin">Return to Sign In</Link>
            </Button>
          </div>
        </div>
      </Card>
    </div>
  )
}

