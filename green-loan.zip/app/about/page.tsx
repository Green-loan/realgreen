"use client"

import { motion } from "framer-motion"
import { LandingNavbar } from "@/components/landing/navbar"
import { LandingFooter } from "@/components/landing/footer"
import { Leaf, Globe, Users, Lightbulb, Recycle, Shield, TrendingUp, ChevronRight } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { AnimatedBackground } from "@/components/about/animated-background"

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      <AnimatedBackground />

      <LandingNavbar />

      <main className="pt-32 pb-20 relative z-10">
        {/* Hero Section */}
        <section className="container mx-auto px-4 mb-20">
          <div className="max-w-4xl mx-auto text-center">
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6">
                About{" "}
                <span className="bg-clip-text text-transparent bg-gradient-to-r from-teal-500 to-blue-600">
                  GreenLoan
                </span>
              </h1>

              <p className="text-xl text-foreground/70 mb-8">
                We're on a mission to make financing accessible to everyone, driving positive impact through innovative
                financial solutions.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="relative rounded-2xl overflow-hidden aspect-video max-w-3xl mx-auto"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-teal-500/20 to-blue-600/20 rounded-2xl blur-xl" />
              <div className="relative bg-background/50 backdrop-blur-sm border border-border/50 rounded-2xl p-6 shadow-xl">
                <div className="aspect-video bg-foreground/5 rounded-lg flex items-center justify-center">
                  <motion.div
                    animate={{ scale: [1, 1.05, 1] }}
                    transition={{ duration: 4, repeat: Number.POSITIVE_INFINITY }}
                  >
                    <Leaf className="w-16 h-16 text-teal-500 opacity-50" />
                  </motion.div>
                </div>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Our Story Section */}
        <section className="container mx-auto px-4 mb-20">
          <div className="max-w-4xl mx-auto">
            <motion.div
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              className="mb-12 text-center"
            >
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Story</h2>
              <div className="w-20 h-1 bg-gradient-to-r from-teal-500 to-blue-600 mx-auto rounded-full"></div>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
              <motion.div
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5 }}
              >
                <p className="text-lg mb-6 leading-relaxed">
                  Founded in 2024, GreenLoan was created to provide accessible financing options with transparent terms.
                </p>
                <p className="text-lg mb-6 leading-relaxed">
                  Our mission is to offer straightforward loans with clear terms and a fixed 39.99% interest rate.
                </p>
                <p className="text-lg leading-relaxed">
                  We believe in being upfront about our loan terms and providing quick approval processes to help you
                  get the funds you need.
                </p>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: 0.2 }}
                className="relative"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-teal-500/20 to-blue-600/20 rounded-2xl blur-xl" />
                <div className="relative bg-background/50 backdrop-blur-sm border border-border/50 rounded-2xl p-6 shadow-xl">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-foreground/5 rounded-lg p-6 text-center">
                      <motion.div
                        animate={{ y: [0, -10, 0] }}
                        transition={{ duration: 3, repeat: Number.POSITIVE_INFINITY }}
                        className="flex justify-center mb-4"
                      >
                        <TrendingUp className="w-10 h-10 text-teal-500" />
                      </motion.div>
                      <h3 className="text-2xl font-bold">100+</h3>
                      <p className="text-foreground/70">Projects Funded</p>
                    </div>
                    <div className="bg-foreground/5 rounded-lg p-6 text-center">
                      <motion.div
                        animate={{ y: [0, -10, 0] }}
                        transition={{ duration: 3, repeat: Number.POSITIVE_INFINITY, delay: 0.5 }}
                        className="flex justify-center mb-4"
                      >
                        <Recycle className="w-10 h-10 text-blue-600" />
                      </motion.div>
                      <h3 className="text-2xl font-bold">200+</h3>
                      <p className="text-foreground/70">Tons of CO₂ Saved</p>
                    </div>
                    <div className="bg-foreground/5 rounded-lg p-6 text-center">
                      <motion.div
                        animate={{ y: [0, -10, 0] }}
                        transition={{ duration: 3, repeat: Number.POSITIVE_INFINITY, delay: 1 }}
                        className="flex justify-center mb-4"
                      >
                        <Users className="w-10 h-10 text-teal-500" />
                      </motion.div>
                      <h3 className="text-2xl font-bold">150+</h3>
                      <p className="text-foreground/70">Happy Customers</p>
                    </div>
                  </div>
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Our Values Section */}
        <section className="container mx-auto px-4 mb-20">
          <div className="max-w-4xl mx-auto">
            <motion.div
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              className="mb-12 text-center"
            >
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Values</h2>
              <div className="w-20 h-1 bg-gradient-to-r from-teal-500 to-blue-600 mx-auto rounded-full"></div>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {[
                {
                  icon: Globe,
                  title: "Environmental Impact",
                  description: "Every financial decision we make is evaluated for its environmental impact.",
                },
                {
                  icon: Shield,
                  title: "Transparency",
                  description: "We believe in complete transparency in our operations and lending practices.",
                },
                {
                  icon: Lightbulb,
                  title: "Innovation",
                  description: "We continuously innovate to create better financial solutions for sustainability.",
                },
                {
                  icon: Users,
                  title: "Community",
                  description: "We're building a community of environmentally conscious individuals and businesses.",
                },
              ].map((value, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className="bg-background/50 backdrop-blur-sm border border-border/50 rounded-xl p-6 hover:border-teal-500/30 transition-all duration-300"
                >
                  <div className="flex items-start">
                    <div className="mr-4 mt-1">
                      <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-teal-500/20 to-blue-600/20 flex items-center justify-center">
                        <motion.div
                          animate={{ rotate: [0, 10, 0] }}
                          transition={{ duration: 5, repeat: Number.POSITIVE_INFINITY, repeatType: "reverse" }}
                        >
                          <value.icon className="w-6 h-6 text-teal-500" />
                        </motion.div>
                      </div>
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold mb-2">{value.title}</h3>
                      <p className="text-foreground/70">{value.description}</p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="max-w-4xl mx-auto relative overflow-hidden rounded-2xl"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-teal-500/20 to-blue-600/20 rounded-2xl blur-xl" />
            <div className="relative bg-background/50 backdrop-blur-sm border border-border/50 rounded-2xl p-8 md:p-12 text-center">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Join Our Green Finance Revolution</h2>
              <p className="text-xl text-foreground/70 mb-8 max-w-2xl mx-auto">
                Ready to make a difference? Apply for a green loan today and be part of the sustainable future we're
                building.
              </p>
              <Button
                asChild
                size="lg"
                className="bg-gradient-to-r from-teal-500 to-blue-600 hover:from-teal-600 hover:to-blue-700"
              >
                <Link href="/apply">
                  Apply Now
                  <ChevronRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </div>
          </motion.div>
        </section>
      </main>

      <LandingFooter />
    </div>
  )
}

