"use client"

import { useState } from "react"
import UserDashboardOverview from "@/components/user/dashboard-overview"

export default function DashboardClientPage() {
  // Mock data instead of fetching from Supabase
  const [dashboardData] = useState({
    loanApplications: [
      { id: 1, loan_type: "Solar Panel Installation", amount: 15000, status: "approved", created_at: "2023-10-15" },
      { id: 2, loan_type: "Electric Vehicle", amount: 35000, status: "pending", created_at: "2023-11-02" },
      { id: 3, loan_type: "Home Energy Efficiency", amount: 8000, status: "reviewing", created_at: "2023-11-10" },
    ],
    payments: [
      { id: 1, amount: 1200, payment_date: "2023-10-01", status: "completed" },
      { id: 2, amount: 1200, payment_date: "2023-11-01", status: "completed" },
      { id: 3, amount: 1200, payment_date: "2023-12-01", status: "upcoming" },
    ],
    notifications: [
      {
        id: 1,
        title: "Application Approved",
        message: "Your solar panel loan has been approved!",
        created_at: "2023-10-16",
        type: "success",
      },
      {
        id: 2,
        title: "Document Required",
        message: "Please upload your proof of income.",
        created_at: "2023-11-03",
        type: "warning",
      },
      {
        id: 3,
        title: "Payment Reminder",
        message: "Your next payment is due in 5 days.",
        created_at: "2023-11-25",
        type: "info",
      },
    ],
    stats: {
      totalLoans: 3,
      activeLoans: 1,
      totalRepaid: 2400,
      nextPayment: { payment_date: "2023-12-01", amount: 1200 },
    },
  })

  // Sample data for charts
  const paymentHistoryData = [
    { month: "Jan", amount: 1200 },
    { month: "Feb", amount: 1200 },
    { month: "Mar", amount: 1200 },
    { month: "Apr", amount: 1200 },
    { month: "May", amount: 1200 },
    { month: "Jun", amount: 0 },
    { month: "Jul", amount: 0 },
  ]

  const loanDistributionData = [
    { name: "Solar", value: 45 },
    { name: "EV", value: 25 },
    { name: "Energy Efficiency", value: 20 },
    { name: "Other", value: 10 },
  ]

  const COLORS = ["#10B981", "#3B82F6", "#6366F1", "#8B5CF6"]

  const environmentalImpactData = [
    { month: "Jan", carbon: 120 },
    { month: "Feb", carbon: 240 },
    { month: "Mar", carbon: 380 },
    { month: "Apr", carbon: 530 },
    { month: "May", carbon: 690 },
    { month: "Jun", carbon: 830 },
    { month: "Jul", carbon: 950 },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 to-gray-950 text-white">
      <UserDashboardOverview />
    </div>
  )
}

