import type { ReactNode } from "react"
import { redirect } from "next/navigation"
import { createClient } from "@/utils/supabase/server"
import { UserSidebar } from "@/components/user/user-sidebar"
import { UserHeader } from "@/components/user/user-header"
import { ThemeProvider } from "@/components/theme-provider"

export default async function DashboardLayout({ children }: { children: ReactNode }) {
  const supabase = createClient()

  const {
    data: { session },
  } = await supabase.auth.getSession()

  if (!session) {
    redirect("/login")
  }

  return (
    <ThemeProvider attribute="class" defaultTheme="dark" enableSystem={false}>
      <div className="min-h-screen bg-gradient-to-br from-gray-950 via-gray-900 to-gray-950 text-white">
        <div className="relative flex min-h-screen">
          <UserSidebar />
          <div className="flex-1 flex flex-col">
            <UserHeader />
            <main className="flex-1 pt-16 md:pl-64">
              <div className="relative">
                {/* Background elements */}
                <div className="absolute inset-0 overflow-hidden pointer-events-none">
                  <div className="absolute top-0 left-0 w-full h-[300px] bg-gradient-to-br from-green-500/5 to-blue-500/5 rounded-full blur-3xl" />
                  <div className="absolute bottom-0 right-0 w-full h-[300px] bg-gradient-to-br from-blue-500/5 to-green-500/5 rounded-full blur-3xl" />
                </div>
                {children}
              </div>
            </main>
          </div>
        </div>
      </div>
    </ThemeProvider>
  )
}

