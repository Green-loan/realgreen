import type { Metadata } from "next"
import { NotificationsPage } from "@/components/dashboard/notifications-page"

export const metadata: Metadata = {
  title: "Notifications | GreenFina",
  description: "View all your notifications",
}

export default function NotificationsRoute() {
  return <NotificationsPage />
}

