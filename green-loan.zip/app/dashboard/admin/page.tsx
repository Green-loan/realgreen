import { redirect } from "next/navigation"

export default function AdminDashboardPage() {
  // Directly redirect to the applications page without any auth checks
  redirect("/dashboard/admin/applications")
}

