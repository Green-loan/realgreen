"use client"

import { useState, useEffect } from "react"
import { useSupabase } from "@/components/supabase-provider"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  Legend,
  PieChart,
  Pie,
  Cell,
} from "recharts"
import { ArrowUpRight, ArrowDownRight, DollarSign, CreditCard, Calendar, Download, Loader2 } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"

export default function AdminRevenuePage() {
  const { supabase } = useSupabase()
  const { toast } = useToast()
  const [loading, setLoading] = useState(true)
  const [revenueData, setRevenueData] = useState<any>({
    totalLoans: 0,
    activeLoans: 0,
    totalRevenue: 0,
    totalRepaid: 0,
    pendingRepayments: 0,
    monthlyRevenue: [],
    loanTypeDistribution: [],
    repaymentTrends: [],
  })

  useEffect(() => {
    fetchRevenueData()
  }, [supabase])

  const fetchRevenueData = async () => {
    setLoading(true)
    try {
      // In a real application, these would be actual database queries
      // For this demo, we'll use mock data

      // Simulate API delay
      await new Promise((resolve) => setTimeout(resolve, 1000))

      const mockMonthlyRevenue = [
        { month: "Jan", revenue: 12500, expenses: 4200 },
        { month: "Feb", revenue: 14200, expenses: 4500 },
        { month: "Mar", revenue: 15800, expenses: 4800 },
        { month: "Apr", revenue: 16900, expenses: 5100 },
        { month: "May", revenue: 18500, expenses: 5400 },
        { month: "Jun", revenue: 21000, expenses: 5700 },
        { month: "Jul", revenue: 23500, expenses: 6000 },
      ]

      const mockLoanTypeDistribution = [
        { name: "Solar", value: 45 },
        { name: "EV", value: 25 },
        { name: "Energy Efficiency", value: 20 },
        { name: "Other", value: 10 },
      ]

      const mockRepaymentTrends = [
        { month: "Jan", onTime: 95, late: 5 },
        { month: "Feb", onTime: 93, late: 7 },
        { month: "Mar", onTime: 96, late: 4 },
        { month: "Apr", onTime: 98, late: 2 },
        { month: "May", onTime: 97, late: 3 },
        { month: "Jun", onTime: 96, late: 4 },
        { month: "Jul", onTime: 98, late: 2 },
      ]

      setRevenueData({
        totalLoans: 124,
        activeLoans: 98,
        totalRevenue: 122400,
        totalRepaid: 87500,
        pendingRepayments: 34900,
        monthlyRevenue: mockMonthlyRevenue,
        loanTypeDistribution: mockLoanTypeDistribution,
        repaymentTrends: mockRepaymentTrends,
      })
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error fetching revenue data",
        description: error.message,
      })
    } finally {
      setLoading(false)
    }
  }

  const COLORS = ["#10B981", "#3B82F6", "#6366F1", "#8B5CF6"]

  const handleExportData = () => {
    toast({
      title: "Export started",
      description: "Your data is being exported to CSV. It will be downloaded automatically when ready.",
    })

    // In a real application, this would generate and download a CSV file
    setTimeout(() => {
      const csvContent =
        "data:text/csv;charset=utf-8,Month,Revenue,Expenses\n" +
        revenueData.monthlyRevenue.map((item) => `${item.month},${item.revenue},${item.expenses}`).join("\n")

      const encodedUri = encodeURI(csvContent)
      const link = document.createElement("a")
      link.setAttribute("href", encodedUri)
      link.setAttribute("download", "revenue_report.csv")
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)

      toast({
        title: "Export complete",
        description: "Your revenue report has been downloaded successfully.",
      })
    }, 2000)
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Revenue Management</h2>
          <p className="text-muted-foreground">Track and analyze financial performance</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" onClick={fetchRevenueData} disabled={loading}>
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Refreshing...
              </>
            ) : (
              "Refresh Data"
            )}
          </Button>
          <Button onClick={handleExportData}>
            <Download className="mr-2 h-4 w-4" />
            Export Report
          </Button>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${revenueData.totalRevenue.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-green-500 inline-flex items-center">
                <ArrowUpRight className="mr-1 h-4 w-4" />
                +12.5%
              </span>{" "}
              from last month
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Repaid</CardTitle>
            <CreditCard className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${revenueData.totalRepaid.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-green-500 inline-flex items-center">
                <ArrowUpRight className="mr-1 h-4 w-4" />
                +8.2%
              </span>{" "}
              from last month
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending Repayments</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${revenueData.pendingRepayments.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-red-500 inline-flex items-center">
                <ArrowDownRight className="mr-1 h-4 w-4" />
                -2.5%
              </span>{" "}
              from last month
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Loans</CardTitle>
            <CreditCard className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{revenueData.activeLoans}</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-green-500 inline-flex items-center">
                <ArrowUpRight className="mr-1 h-4 w-4" />
                +5.3%
              </span>{" "}
              from last month
            </p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="revenue" className="space-y-4">
        <TabsList>
          <TabsTrigger value="revenue">Revenue</TabsTrigger>
          <TabsTrigger value="distribution">Loan Distribution</TabsTrigger>
          <TabsTrigger value="repayments">Repayment Trends</TabsTrigger>
        </TabsList>

        <TabsContent value="revenue" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Monthly Revenue</CardTitle>
              <CardDescription>Revenue and expenses over the past 7 months</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <BarChart data={revenueData.monthlyRevenue}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip formatter={(value) => `$${value.toLocaleString()}`} />
                  <Legend />
                  <Bar dataKey="revenue" name="Revenue" fill="#10B981" />
                  <Bar dataKey="expenses" name="Expenses" fill="#6366F1" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="distribution" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Loan Type Distribution</CardTitle>
              <CardDescription>Breakdown of loans by type</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <PieChart>
                  <Pie
                    data={revenueData.loanTypeDistribution}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    outerRadius={150}
                    fill="#8884d8"
                    dataKey="value"
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  >
                    {revenueData.loanTypeDistribution.map((entry: any, index: number) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value) => `${value}%`} />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="repayments" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Repayment Trends</CardTitle>
              <CardDescription>On-time vs. late repayments over time</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <LineChart data={revenueData.repaymentTrends}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip formatter={(value) => `${value}%`} />
                  <Legend />
                  <Line
                    type="monotone"
                    dataKey="onTime"
                    name="On-Time Payments"
                    stroke="#10B981"
                    strokeWidth={2}
                    activeDot={{ r: 8 }}
                  />
                  <Line
                    type="monotone"
                    dataKey="late"
                    name="Late Payments"
                    stroke="#EF4444"
                    strokeWidth={2}
                    activeDot={{ r: 8 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

