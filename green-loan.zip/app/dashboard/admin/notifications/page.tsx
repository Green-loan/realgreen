"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useSupabase } from "@/components/supabase-provider"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { useToast } from "@/components/ui/use-toast"
import { Search, Bell, Send, Loader2, CheckCircle, AlertCircle, Calendar, CreditCard, Info } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function AdminNotificationsPage() {
  const { supabase } = useSupabase()
  const { toast } = useToast()
  const [loading, setLoading] = useState(true)
  const [sending, setSending] = useState(false)
  const [notifications, setNotifications] = useState<any[]>([])
  const [searchQuery, setSearchQuery] = useState("")
  const [notificationForm, setNotificationForm] = useState({
    title: "",
    message: "",
    type: "info",
    recipients: "all",
  })

  useEffect(() => {
    fetchNotifications()
  }, [supabase])

  const fetchNotifications = async () => {
    setLoading(true)
    try {
      const { data, error } = await supabase
        .from("notifications")
        .select(`
          *,
          profiles:user_id (full_name, email)
        `)
        .order("created_at", { ascending: false })

      if (error) {
        throw error
      }

      setNotifications(data || [])
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error fetching notifications",
        description: error.message,
      })
    } finally {
      setLoading(false)
    }
  }

  const handleFormChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setNotificationForm({
      ...notificationForm,
      [e.target.name]: e.target.value,
    })
  }

  const handleSelectChange = (name: string, value: string) => {
    setNotificationForm({
      ...notificationForm,
      [name]: value,
    })
  }

  const handleSendNotification = async (e: React.FormEvent) => {
    e.preventDefault()
    setSending(true)

    try {
      // Get users based on recipient selection
      let userIds: string[] = []

      if (notificationForm.recipients === "all") {
        const { data } = await supabase.from("profiles").select("id")

        userIds = data?.map((user) => user.id) || []
      } else if (notificationForm.recipients === "active_loans") {
        const { data } = await supabase
          .from("loan_applications")
          .select("user_id")
          .eq("status", "approved")
          .order("created_at", { ascending: false })

        userIds = [...new Set(data?.map((app) => app.user_id) || [])]
      } else if (notificationForm.recipients === "pending_payments") {
        const { data } = await supabase.from("payments").select("user_id").eq("status", "pending")

        userIds = [...new Set(data?.map((payment) => payment.user_id) || [])]
      }

      // Create notifications for each user
      const notifications = userIds.map((userId) => ({
        user_id: userId,
        title: notificationForm.title,
        message: notificationForm.message,
        type: notificationForm.type,
        read: false,
      }))

      if (notifications.length > 0) {
        const { error } = await supabase.from("notifications").insert(notifications)

        if (error) {
          throw error
        }

        toast({
          title: "Notifications sent",
          description: `Successfully sent to ${notifications.length} recipients.`,
        })

        // Reset form
        setNotificationForm({
          title: "",
          message: "",
          type: "info",
          recipients: "all",
        })

        // Refresh notifications list
        fetchNotifications()
      } else {
        toast({
          variant: "destructive",
          title: "No recipients found",
          description: "There are no users matching your selected criteria.",
        })
      }
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error sending notifications",
        description: error.message,
      })
    } finally {
      setSending(false)
    }
  }

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case "approval":
        return <CheckCircle className="h-4 w-4 text-green-500" />
      case "rejection":
        return <AlertCircle className="h-4 w-4 text-red-500" />
      case "payment":
        return <CreditCard className="h-4 w-4 text-blue-500" />
      case "reminder":
        return <Calendar className="h-4 w-4 text-yellow-500" />
      default:
        return <Info className="h-4 w-4 text-gray-500" />
    }
  }

  const filteredNotifications = notifications.filter(
    (notification) =>
      notification.title?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      notification.message?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      notification.profiles?.full_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      notification.profiles?.email?.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Notifications</h2>
          <p className="text-muted-foreground">Manage and send notifications to users</p>
        </div>
        <Button onClick={fetchNotifications}>Refresh</Button>
      </div>

      <Tabs defaultValue="send" className="space-y-4">
        <TabsList>
          <TabsTrigger value="send">Send Notifications</TabsTrigger>
          <TabsTrigger value="history">Notification History</TabsTrigger>
        </TabsList>

        <TabsContent value="send" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Send New Notification</CardTitle>
              <CardDescription>Create and send notifications to users</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSendNotification} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label htmlFor="title" className="text-sm font-medium">
                      Notification Title
                    </label>
                    <Input
                      id="title"
                      name="title"
                      placeholder="Enter notification title"
                      value={notificationForm.title}
                      onChange={handleFormChange}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <label htmlFor="type" className="text-sm font-medium">
                      Notification Type
                    </label>
                    <Select value={notificationForm.type} onValueChange={(value) => handleSelectChange("type", value)}>
                      <SelectTrigger id="type">
                        <SelectValue placeholder="Select notification type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="info">Information</SelectItem>
                        <SelectItem value="payment">Payment</SelectItem>
                        <SelectItem value="reminder">Reminder</SelectItem>
                        <SelectItem value="approval">Approval</SelectItem>
                        <SelectItem value="rejection">Rejection</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <label htmlFor="message" className="text-sm font-medium">
                    Message
                  </label>
                  <Textarea
                    id="message"
                    name="message"
                    placeholder="Enter notification message"
                    value={notificationForm.message}
                    onChange={handleFormChange}
                    rows={4}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <label htmlFor="recipients" className="text-sm font-medium">
                    Recipients
                  </label>
                  <Select
                    value={notificationForm.recipients}
                    onValueChange={(value) => handleSelectChange("recipients", value)}
                  >
                    <SelectTrigger id="recipients">
                      <SelectValue placeholder="Select recipients" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Users</SelectItem>
                      <SelectItem value="active_loans">Users with Active Loans</SelectItem>
                      <SelectItem value="pending_payments">Users with Pending Payments</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <Button type="submit" className="w-full" disabled={sending}>
                  {sending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Sending...
                    </>
                  ) : (
                    <>
                      <Send className="mr-2 h-4 w-4" />
                      Send Notification
                    </>
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="history" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Notification History</CardTitle>
              <CardDescription>View all notifications sent to users</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="relative mb-4">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search notifications..."
                  className="pl-8"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>

              {loading ? (
                <div className="flex justify-center items-center py-12">
                  <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                </div>
              ) : filteredNotifications.length > 0 ? (
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Type</TableHead>
                        <TableHead>Title</TableHead>
                        <TableHead>Recipient</TableHead>
                        <TableHead>Date</TableHead>
                        <TableHead>Status</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredNotifications.map((notification) => (
                        <TableRow key={notification.id}>
                          <TableCell>
                            <div className="flex items-center">
                              {getNotificationIcon(notification.type)}
                              <span className="ml-2 capitalize">{notification.type}</span>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="font-medium">{notification.title}</div>
                            <div className="text-xs text-muted-foreground line-clamp-1">{notification.message}</div>
                          </TableCell>
                          <TableCell>
                            <div>{notification.profiles?.full_name || "Unknown"}</div>
                            <div className="text-xs text-muted-foreground">{notification.profiles?.email}</div>
                          </TableCell>
                          <TableCell>{new Date(notification.created_at).toLocaleDateString()}</TableCell>
                          <TableCell>
                            <div
                              className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                                notification.read ? "bg-green-500/20 text-green-500" : "bg-blue-500/20 text-blue-500"
                              }`}
                            >
                              {notification.read ? "Read" : "Unread"}
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center py-12 text-center">
                  <Bell className="h-12 w-12 text-muted-foreground mb-4" />
                  <h3 className="text-lg font-medium mb-2">No Notifications Found</h3>
                  <p className="text-muted-foreground max-w-md">
                    {searchQuery
                      ? "No notifications match your search criteria."
                      : "There are no notifications in the system yet."}
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

