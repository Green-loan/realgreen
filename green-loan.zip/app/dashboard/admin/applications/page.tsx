import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { createClient } from "@/utils/supabase/server"
import { cookies } from "next/headers"

export default async function AdminApplicationsPage() {
  // Create Supabase client
  const cookieStore = cookies()
  const supabase = createClient(cookieStore)

  // Fetch applications without requiring authentication
  const { data: applications, error } = await supabase
    .from("loan_applications")
    .select(`
      *,
      profiles:user_id (
        full_name,
        email
      )
    `)
    .order("created_at", { ascending: false })

  // Handle errors gracefully
  if (error) {
    console.error("Error fetching applications:", error)
  }

  return (
    <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold tracking-tight">Applications</h2>
      </div>
      <div className="grid gap-4">
        <Card>
          <CardHeader>
            <CardTitle>All Applications</CardTitle>
            <CardDescription>Manage and review all loan applications.</CardDescription>
          </CardHeader>
          <CardContent>
            {applications && applications.length > 0 ? (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Applicant</TableHead>
                    <TableHead>Loan Amount</TableHead>
                    <TableHead>Purpose</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Date</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {applications.map((application) => (
                    <TableRow key={application.id}>
                      <TableCell className="font-medium">{application.profiles?.full_name || "Unknown"}</TableCell>
                      <TableCell>${application.loan_amount.toLocaleString()}</TableCell>
                      <TableCell>{application.loan_purpose}</TableCell>
                      <TableCell>
                        <Badge
                          variant={
                            application.status === "approved"
                              ? "success"
                              : application.status === "pending"
                                ? "outline"
                                : "destructive"
                          }
                        >
                          {application.status}
                        </Badge>
                      </TableCell>
                      <TableCell>{new Date(application.created_at).toLocaleDateString()}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <div className="flex flex-col items-center justify-center p-8 text-center">
                <p className="text-sm text-muted-foreground">No applications found</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

