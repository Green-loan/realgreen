import { createClient } from "@/utils/supabase/server"
import { redirect } from "next/navigation"

export default async function ApplicationsPage() {
  const supabase = createClient()

  const {
    data: { session },
  } = await supabase.auth.getSession()

  if (!session) {
    redirect("/login")
  }

  return (
    <div className="bg-white shadow sm:rounded-lg">
      <div className="px-4 py-5 sm:p-6">
        <h3 className="text-lg font-medium leading-6 text-gray-900">Your Applications</h3>
        <div className="mt-2 max-w-xl text-sm text-gray-500">
          <p>You don't have any loan applications yet. Start a new application to get started.</p>
        </div>
        <div className="mt-5">
          <button
            type="button"
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
          >
            Start New Application
          </button>
        </div>
      </div>
    </div>
  )
}

