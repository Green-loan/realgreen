import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { DashboardOverview } from "@/components/user/dashboard-overview"
import { LoanApplicationStatus } from "@/components/user/loan-application-status"
import { FinancialOverview } from "@/components/user/financial-overview"
import { RecentActivity } from "@/components/user/recent-activity"
import { DocumentStatus } from "@/components/user/document-status"
import { UserNotifications } from "@/components/user/user-notifications"
import { createClient } from "@/utils/supabase/server"
import { cookies } from "next/headers"
import { Button } from "@/components/ui/button"
import { Plus, Users2, Calendar } from "lucide-react"
import Link from "next/link"

export default async function DashboardPage() {
  const cookieStore = cookies()
  const supabase = createClient(cookieStore)

  const {
    data: { session },
  } = await supabase.auth.getSession()

  // Get user profile
  const { data: profile } = await supabase.from("profiles").select("*").eq("id", session?.user.id).single()

  // Get user's loan applications
  const { data: applications } = await supabase
    .from("loan_applications")
    .select("*")
    .eq("user_id", session?.user.id)
    .order("created_at", { ascending: false })

  return (
    <div className="flex-1 space-y-6 p-8 pt-6 animate-in fade-in duration-500">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Welcome back, {profile?.full_name || "User"}</h2>
          <p className="text-muted-foreground">Here's an overview of your financial activities</p>
        </div>
        <div className="flex items-center gap-2">
          <Button asChild>
            <Link href="/dashboard/applications/new">
              <Plus className="mr-2 h-4 w-4" />
              New Loan Application
            </Link>
          </Button>
        </div>
      </div>

      <DashboardOverview />

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Loan Applications</CardTitle>
            <CardDescription>Status of your recent loan applications</CardDescription>
          </CardHeader>
          <CardContent>
            <LoanApplicationStatus applications={applications || []} />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Upcoming Payments</CardTitle>
            <CardDescription>Your scheduled loan repayments</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                {
                  loanId: "L-2023-001",
                  amount: 2500,
                  dueDate: "2023-12-20",
                  status: "upcoming",
                },
                {
                  loanId: "L-2023-001",
                  amount: 2500,
                  dueDate: "2024-01-20",
                  status: "upcoming",
                },
                {
                  loanId: "L-2022-045",
                  amount: 1800,
                  dueDate: "2023-12-15",
                  status: "overdue",
                },
              ].map((payment, index) => (
                <div
                  key={index}
                  className={`p-4 rounded-lg border ${
                    payment.status === "overdue" ? "bg-red-500/10 border-red-500/20" : "bg-white/5 border-white/10"
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-medium">
                        Loan {payment.loanId}{" "}
                        {payment.status === "overdue" && (
                          <span className="text-red-500 text-sm font-normal">(Overdue)</span>
                        )}
                      </div>
                      <div className="text-sm text-muted-foreground flex items-center mt-1">
                        <Calendar className="h-3 w-3 mr-1" />
                        Due: {new Date(payment.dueDate).toLocaleDateString()}
                      </div>
                    </div>
                    <div className="text-lg font-bold">R{payment.amount.toLocaleString()}</div>
                  </div>
                  {payment.status === "upcoming" && (
                    <div className="mt-3">
                      <Button size="sm" className="w-full">
                        Pay Now
                      </Button>
                    </div>
                  )}
                  {payment.status === "overdue" && (
                    <div className="mt-3">
                      <Button size="sm" variant="destructive" className="w-full">
                        Pay Immediately
                      </Button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Financial Overview</CardTitle>
            <CardDescription>Your loan and payment history</CardDescription>
          </CardHeader>
          <CardContent>
            <FinancialOverview />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Stokvel Group</CardTitle>
            <CardDescription>Your savings group information</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="p-4 rounded-lg bg-white/5 border border-white/10">
                <div className="flex items-center justify-between">
                  <div className="font-medium">Green Savers Group</div>
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-green-500/20 text-green-500">
                    <Users2 className="h-4 w-4" />
                  </div>
                </div>
                <div className="text-sm text-muted-foreground mt-1">10 members</div>
                <div className="mt-3 space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span>Your position:</span>
                    <span className="font-medium">3rd</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span>Monthly contribution:</span>
                    <span className="font-medium">R500</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span>Next payout:</span>
                    <span className="font-medium">March 2024</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span>Total contributed:</span>
                    <span className="font-medium">R4,500</span>
                  </div>
                </div>
                <div className="mt-4">
                  <Button size="sm" variant="outline" className="w-full" asChild>
                    <Link href="/dashboard/stokvel">View Group Details</Link>
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
            <CardDescription>Your recent financial activities</CardDescription>
          </CardHeader>
          <CardContent>
            <RecentActivity />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Document Status</CardTitle>
            <CardDescription>Status of your submitted documents</CardDescription>
          </CardHeader>
          <CardContent>
            <DocumentStatus />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Notifications</CardTitle>
            <CardDescription>Your recent notifications</CardDescription>
          </CardHeader>
          <CardContent>
            <UserNotifications />
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

