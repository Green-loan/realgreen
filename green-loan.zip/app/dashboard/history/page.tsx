import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { createClient } from "@/utils/supabase/server"
import { cookies } from "next/headers"
import { CheckCircle, XCircle, Clock, Eye, Download, FileText, Calendar, DollarSign } from "lucide-react"
import Link from "next/link"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default async function LoanHistoryPage() {
  const cookieStore = cookies()
  const supabase = createClient(cookieStore)

  const {
    data: { session },
  } = await supabase.auth.getSession()

  // Get user's loan applications
  const { data: loans } = await supabase
    .from("loan_applications")
    .select("*")
    .eq("user_id", session?.user.id)
    .order("created_at", { ascending: false })

  // Mock payment history data
  const paymentHistory = [
    {
      id: 1,
      loanId: "L-2023-001",
      amount: 2500,
      date: "2023-11-20",
      status: "completed",
    },
    {
      id: 2,
      loanId: "L-2023-001",
      amount: 2500,
      date: "2023-10-20",
      status: "completed",
    },
    {
      id: 3,
      loanId: "L-2022-045",
      amount: 1800,
      date: "2023-11-15",
      status: "completed",
    },
    {
      id: 4,
      loanId: "L-2022-045",
      amount: 1800,
      date: "2023-10-15",
      status: "late",
    },
    {
      id: 5,
      loanId: "L-2022-045",
      amount: 1800,
      date: "2023-09-15",
      status: "completed",
    },
  ]

  return (
    <div className="flex-1 space-y-6 p-8 pt-6 animate-in fade-in duration-500">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Loan History</h2>
          <p className="text-muted-foreground">View your loan applications and payment history</p>
        </div>
      </div>

      <Tabs defaultValue="loans" className="space-y-4">
        <TabsList>
          <TabsTrigger value="loans">Loan Applications</TabsTrigger>
          <TabsTrigger value="payments">Payment History</TabsTrigger>
        </TabsList>
        <TabsContent value="loans" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Loan Applications</CardTitle>
              <CardDescription>All your loan applications and their status</CardDescription>
            </CardHeader>
            <CardContent>
              {loans && loans.length > 0 ? (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Loan ID</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Purpose</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {loans.map((loan) => (
                      <TableRow key={loan.id}>
                        <TableCell className="font-medium">L-{loan.id}</TableCell>
                        <TableCell>R{loan.loan_amount?.toLocaleString() || "0"}</TableCell>
                        <TableCell>{loan.loan_purpose || "N/A"}</TableCell>
                        <TableCell>
                          {loan.status === "approved" && (
                            <Badge variant="outline" className="bg-green-500/10 text-green-500 border-green-500/20">
                              <CheckCircle className="mr-1 h-3 w-3" /> Approved
                            </Badge>
                          )}
                          {loan.status === "pending" && (
                            <Badge variant="outline" className="bg-amber-500/10 text-amber-500 border-amber-500/20">
                              <Clock className="mr-1 h-3 w-3" /> Pending
                            </Badge>
                          )}
                          {loan.status === "rejected" && (
                            <Badge variant="outline" className="bg-red-500/10 text-red-500 border-red-500/20">
                              <XCircle className="mr-1 h-3 w-3" /> Rejected
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell>{new Date(loan.created_at).toLocaleDateString()}</TableCell>
                        <TableCell className="text-right">
                          <Button variant="outline" size="sm" asChild>
                            <Link href={`/dashboard/applications/${loan.id}`}>
                              <Eye className="mr-2 h-4 w-4" />
                              View
                            </Link>
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              ) : (
                <div className="flex flex-col items-center justify-center p-8 text-center">
                  <FileText className="h-12 w-12 text-muted-foreground mb-4" />
                  <p className="text-lg font-medium">No loan applications found</p>
                  <p className="text-sm text-muted-foreground">You haven't applied for any loans yet</p>
                  <Button className="mt-4" asChild>
                    <Link href="/dashboard/applications/new">Apply for a Loan</Link>
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="payments" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Payment History</CardTitle>
              <CardDescription>All your loan payments and their status</CardDescription>
            </CardHeader>
            <CardContent>
              {paymentHistory.length > 0 ? (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Payment ID</TableHead>
                      <TableHead>Loan ID</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {paymentHistory.map((payment) => (
                      <TableRow key={payment.id}>
                        <TableCell className="font-medium">P-{payment.id}</TableCell>
                        <TableCell>{payment.loanId}</TableCell>
                        <TableCell>R{payment.amount.toLocaleString()}</TableCell>
                        <TableCell>{new Date(payment.date).toLocaleDateString()}</TableCell>
                        <TableCell>
                          {payment.status === "completed" && (
                            <Badge variant="outline" className="bg-green-500/10 text-green-500 border-green-500/20">
                              <CheckCircle className="mr-1 h-3 w-3" /> Completed
                            </Badge>
                          )}
                          {payment.status === "pending" && (
                            <Badge variant="outline" className="bg-amber-500/10 text-amber-500 border-amber-500/20">
                              <Clock className="mr-1 h-3 w-3" /> Pending
                            </Badge>
                          )}
                          {payment.status === "late" && (
                            <Badge variant="outline" className="bg-red-500/10 text-red-500 border-red-500/20">
                              <XCircle className="mr-1 h-3 w-3" /> Late
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell className="text-right">
                          <Button variant="outline" size="sm">
                            <Download className="mr-2 h-4 w-4" />
                            Receipt
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              ) : (
                <div className="flex flex-col items-center justify-center p-8 text-center">
                  <DollarSign className="h-12 w-12 text-muted-foreground mb-4" />
                  <p className="text-lg font-medium">No payment history found</p>
                  <p className="text-sm text-muted-foreground">You haven't made any loan payments yet</p>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Payment Schedule</CardTitle>
              <CardDescription>Upcoming loan payments</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  {
                    loanId: "L-2023-001",
                    amount: 2500,
                    dueDate: "2023-12-20",
                    status: "upcoming",
                  },
                  {
                    loanId: "L-2023-001",
                    amount: 2500,
                    dueDate: "2024-01-20",
                    status: "upcoming",
                  },
                  {
                    loanId: "L-2022-045",
                    amount: 1800,
                    dueDate: "2023-12-15",
                    status: "overdue",
                  },
                ].map((payment, index) => (
                  <div
                    key={index}
                    className={`p-4 rounded-lg border ${
                      payment.status === "overdue" ? "bg-red-500/10 border-red-500/20" : "bg-white/5 border-white/10"
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-medium">
                          Loan {payment.loanId}{" "}
                          {payment.status === "overdue" && (
                            <span className="text-red-500 text-sm font-normal">(Overdue)</span>
                          )}
                        </div>
                        <div className="text-sm text-muted-foreground flex items-center mt-1">
                          <Calendar className="h-3 w-3 mr-1" />
                          Due: {new Date(payment.dueDate).toLocaleDateString()}
                        </div>
                      </div>
                      <div className="text-lg font-bold">R{payment.amount.toLocaleString()}</div>
                    </div>
                    {payment.status === "upcoming" && (
                      <div className="mt-3">
                        <Button size="sm" className="w-full">
                          Pay Now
                        </Button>
                      </div>
                    )}
                    {payment.status === "overdue" && (
                      <div className="mt-3">
                        <Button size="sm" variant="destructive" className="w-full">
                          Pay Immediately
                        </Button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

