"use client"

import { LandingNavbar } from "@/components/landing/navbar"
import { LandingFooter } from "@/components/landing/footer"
import { Card, CardContent } from "@/components/ui/card"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

export default function FAQPage() {
  return (
    <div className="min-h-screen bg-background">
      <LandingNavbar />
      <div className="container mx-auto px-4 py-32">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-3xl md:text-4xl font-bold mb-8">Frequently Asked Questions</h1>

          <Card className="mb-8">
            <CardContent className="p-6">
              <Accordion type="single" collapsible className="w-full">
                <AccordionItem value="item-1">
                  <AccordionTrigger className="text-lg font-medium">
                    What is the interest rate on GreenLoan loans?
                  </AccordionTrigger>
                  <AccordionContent className="text-foreground/80">
                    All GreenLoan loans come with a fixed interest rate of 39.99%. This rate is applied to the principal
                    amount and is clearly stated in all loan agreements.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-2">
                  <AccordionTrigger className="text-lg font-medium">
                    How long do I have to repay my loan?
                  </AccordionTrigger>
                  <AccordionContent className="text-foreground/80">
                    All loans must be repaid within one month (30 days) from the date of disbursement. The exact due
                    date will be specified in your loan agreement.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-3">
                  <AccordionTrigger className="text-lg font-medium">What happens if I miss a payment?</AccordionTrigger>
                  <AccordionContent className="text-foreground/80">
                    If you miss a payment, a late payment penalty will be applied. This penalty is calculated as 39.99%
                    of the total amount due for the previous month (principal plus interest). This additional amount
                    will be added to your outstanding balance. We strongly recommend contacting us immediately if you
                    anticipate difficulty making a payment.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-4">
                  <AccordionTrigger className="text-lg font-medium">
                    How many loans can I have at once?
                  </AccordionTrigger>
                  <AccordionContent className="text-foreground/80">
                    Clients may not take more than three loans if they have any outstanding debt with GreenLoan. All
                    previous loans must be fully repaid before a fourth loan can be considered.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-5">
                  <AccordionTrigger className="text-lg font-medium">Can I repay my loan early?</AccordionTrigger>
                  <AccordionContent className="text-foreground/80">
                    Yes, you can repay your loan before the due date without any early repayment penalties. We encourage
                    early repayment if you have the means to do so.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-6">
                  <AccordionTrigger className="text-lg font-medium">How do I apply for a loan?</AccordionTrigger>
                  <AccordionContent className="text-foreground/80">
                    You can apply for a loan by clicking on the "Apply Now" button on our website and completing the
                    application form. You'll need to provide personal information, employment details, and banking
                    information. Our team will review your application and typically provide a decision within 24-48
                    hours.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-7">
                  <AccordionTrigger className="text-lg font-medium">
                    What documents do I need to apply?
                  </AccordionTrigger>
                  <AccordionContent className="text-foreground/80">
                    To apply for a loan, you'll need to provide:
                    <ul className="list-disc pl-6 mt-2">
                      <li>Valid South African ID or passport</li>
                      <li>Proof of income (payslips or bank statements)</li>
                      <li>Proof of residence (utility bill or lease agreement)</li>
                      <li>Bank account details</li>
                    </ul>
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-8">
                  <AccordionTrigger className="text-lg font-medium">
                    How quickly will I receive the funds?
                  </AccordionTrigger>
                  <AccordionContent className="text-foreground/80">
                    Once your loan is approved, funds are typically disbursed within 24-48 hours directly to your bank
                    account.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-9">
                  <AccordionTrigger className="text-lg font-medium">How do I make repayments?</AccordionTrigger>
                  <AccordionContent className="text-foreground/80">
                    Repayments can be made through direct bank transfer to GreenLoan's account, debit order (if
                    authorized during application), or other payment methods as specified in your loan agreement. The
                    full amount is due within one month of receiving the loan.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-10">
                  <AccordionTrigger className="text-lg font-medium">
                    What happens if my loan application is rejected?
                  </AccordionTrigger>
                  <AccordionContent className="text-foreground/80">
                    If your loan application is rejected, you will receive notification explaining the reason. You may
                    reapply after addressing the issues that led to the rejection, typically after a 30-day waiting
                    period.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-11">
                  <AccordionTrigger className="text-lg font-medium">
                    Is my personal information secure?
                  </AccordionTrigger>
                  <AccordionContent className="text-foreground/80">
                    Yes, we take data security very seriously. We use industry-standard encryption and security measures
                    to protect your personal and financial information. For more details, please review our Privacy
                    Policy.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-12">
                  <AccordionTrigger className="text-lg font-medium">
                    How can I contact customer support?
                  </AccordionTrigger>
                  <AccordionContent className="text-foreground/80">
                    You can contact our customer support team via email at greenfinance.loan@gmail.com or by phone at
                    +2764 0519593. Our support hours are Monday to Friday, 8am to 5pm.
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </CardContent>
          </Card>
        </div>
      </div>
      <LandingFooter />
    </div>
  )
}

