import { cookies } from "next/headers"
import { NextResponse } from "next/server"
import { createClient } from "@/lib/supabase-server"

export async function GET() {
  try {
    const cookieStore = cookies()
    const supabase = createClient(cookieStore)

    // Check if we can connect to Supabase
    const { data: connectionTest, error: connectionError } = await supabase
      .from("profiles")
      .select("count(*)", { count: "exact", head: true })

    if (connectionError) {
      return NextResponse.json(
        {
          status: "error",
          message: "Failed to connect to database",
          error: connectionError,
        },
        { status: 500 },
      )
    }

    // Check if tables exist
    const { data: tables, error: tablesError } = await supabase.rpc("get_tables")

    // Check profiles table structure
    const { data: profilesColumns, error: profilesError } = await supabase
      .from("information_schema.columns")
      .select("column_name, data_type")
      .eq("table_schema", "public")
      .eq("table_name", "profiles")

    // Check RLS policies
    const { data: policies, error: policiesError } = await supabase.rpc("get_policies")

    return NextResponse.json({
      status: "success",
      connection: "Connected successfully",
      tables: tables || [],
      profilesColumns: profilesColumns || [],
      policies: policies || [],
      environment: {
        supabaseUrl: process.env.NEXT_PUBLIC_SUPABASE_URL ? "Set" : "Not set",
        supabaseAnonKey: process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ? "Set" : "Not set",
      },
    })
  } catch (error: any) {
    return NextResponse.json(
      {
        status: "error",
        message: "Failed to run diagnostics",
        error: error.message,
      },
      { status: 500 },
    )
  }
}

