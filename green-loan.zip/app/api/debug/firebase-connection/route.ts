import { NextResponse } from "next/server"
import { testFirestoreConnection, testRealtimeDBConnection } from "@/lib/firebase-utils"

export async function GET() {
  try {
    const firestoreTest = await testFirestoreConnection()
    const realtimeDBTest = await testRealtimeDBConnection()

    return NextResponse.json({
      timestamp: new Date().toISOString(),
      firestore: firestoreTest,
      realtimeDB: realtimeDBTest,
      message: "Firebase connection test completed",
    })
  } catch (error) {
    console.error("Firebase connection test error:", error)
    return NextResponse.json(
      {
        error: error instanceof Error ? error.message : "Unknown error",
        timestamp: new Date().toISOString(),
      },
      { status: 500 },
    )
  }
}

