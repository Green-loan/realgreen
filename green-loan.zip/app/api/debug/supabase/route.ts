import { NextResponse } from "next/server"

export async function GET() {
  // Only enable in development
  if (process.env.NODE_ENV !== "development") {
    return NextResponse.json({ error: "Not available in production" }, { status: 403 })
  }

  // Check if Supabase environment variables are set
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
  const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

  // Check if Supabase is reachable
  let supabaseReachable = false
  try {
    const response = await fetch(`${supabaseUrl}/auth/v1/health`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        apikey: supabaseAnonKey || "",
      },
    })
    supabaseReachable = response.ok
  } catch (error) {
    console.error("Error checking Supabase health:", error)
  }

  return NextResponse.json({
    supabaseUrl: supabaseUrl ? "Set" : "Not set",
    supabaseAnonKey: supabaseAnonKey ? "Set" : "Not set",
    supabaseReachable,
  })
}

