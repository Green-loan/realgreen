import { createRouteHandlerClient } from "@supabase/auth-helpers-nextjs"
import { cookies } from "next/headers"
import { NextResponse } from "next/server"

export async function GET() {
  try {
    // Create a Supabase client
    const supabase = createRouteHandlerClient({ cookies })

    // SQL to fix the database
    const sql = `
    -- Check if the profiles table exists and create it if it doesn't
    CREATE TABLE IF NOT EXISTS profiles (
      id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
      full_name TEXT,
      email TEXT,
      phone TEXT,
      avatar_url TEXT,
      updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
      created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
    );

    -- Drop the existing trigger if it exists
    DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;

    -- Create a function to handle new user creation
    CREATE OR REPLACE FUNCTION public.handle_new_user()
    RETURNS TRIGGER AS $$
    BEGIN
      INSERT INTO public.profiles (id, full_name, email, avatar_url, updated_at)
      VALUES (
        NEW.id,
        NEW.raw_user_meta_data->>'full_name',
        NEW.email,
        NEW.raw_user_meta_data->>'avatar_url',
        NOW()
      )
      ON CONFLICT (id) DO NOTHING;
      RETURN NEW;
    EXCEPTION
      WHEN OTHERS THEN
        -- Log the error but don't fail the transaction
        RAISE WARNING 'Error in handle_new_user trigger: %', SQLERRM;
        RETURN NEW;
    END;
    $$ LANGUAGE plpgsql SECURITY DEFINER;

    -- Create the trigger
    CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

    -- Set up Row Level Security (RLS)
    ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

    -- Create policies
    DROP POLICY IF EXISTS "Users can view their own profile" ON profiles;
    CREATE POLICY "Users can view their own profile"
    ON profiles FOR SELECT
    USING (auth.uid() = id OR auth.role() = 'service_role');

    DROP POLICY IF EXISTS "Users can update their own profile" ON profiles;
    CREATE POLICY "Users can update their own profile"
    ON profiles FOR UPDATE
    USING (auth.uid() = id OR auth.role() = 'service_role');

    -- Allow authenticated users to insert their own profile
    DROP POLICY IF EXISTS "Users can insert their own profile" ON profiles;
    CREATE POLICY "Users can insert their own profile"
    ON profiles FOR INSERT
    WITH CHECK (auth.uid() = id OR auth.role() = 'service_role');

    -- Create function to check if trigger exists
    CREATE OR REPLACE FUNCTION check_trigger_exists(trigger_name TEXT)
    RETURNS BOOLEAN AS $$
    DECLARE
      trigger_exists BOOLEAN;
    BEGIN
      SELECT EXISTS (
        SELECT 1 FROM information_schema.triggers
        WHERE trigger_name = $1
      ) INTO trigger_exists;
      
      RETURN trigger_exists;
    END;
    $$ LANGUAGE plpgsql SECURITY DEFINER;
    
    -- Create function to insert profile with service role
    CREATE OR REPLACE FUNCTION insert_profile(
      user_id UUID,
      user_full_name TEXT,
      user_email TEXT,
      user_updated_at TIMESTAMP WITH TIME ZONE
    )
    RETURNS VOID AS $$
    BEGIN
      INSERT INTO public.profiles (id, full_name, email, updated_at)
      VALUES (user_id, user_full_name, user_email, user_updated_at)
      ON CONFLICT (id) 
      DO UPDATE SET
        full_name = user_full_name,
        email = user_email,
        updated_at = user_updated_at;
    END;
    $$ LANGUAGE plpgsql SECURITY DEFINER;
    
    -- Fix existing users without profiles
    INSERT INTO profiles (id, full_name, email, updated_at)
    SELECT 
      au.id, 
      au.raw_user_meta_data->>'full_name', 
      au.email, 
      NOW()
    FROM auth.users au
    LEFT JOIN profiles p ON au.id = p.id
    WHERE p.id IS NULL
    ON CONFLICT (id) DO NOTHING;
    `

    // Execute the SQL
    const { error } = await supabase.rpc("exec_sql", { sql })

    if (error) {
      // If the exec_sql function doesn't exist, try direct SQL
      // Note: This will only work if the service role has permission to execute raw SQL
      try {
        await supabase.sql(sql)
      } catch (sqlError: any) {
        return NextResponse.json(
          { error: `Database fix failed: ${sqlError.message || error.message}` },
          { status: 500 },
        )
      }
    }

    return NextResponse.json({
      success: true,
      message: "Database fixes applied successfully",
    })
  } catch (error: any) {
    console.error("Server error:", error)
    return NextResponse.json({ error: `Internal server error: ${error.message}` }, { status: 500 })
  }
}

