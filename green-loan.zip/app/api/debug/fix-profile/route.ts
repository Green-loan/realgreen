import { createRouteHandlerClient } from "@supabase/auth-helpers-nextjs"
import { cookies } from "next/headers"
import { NextResponse } from "next/server"

export async function POST(request: Request) {
  try {
    const requestData = await request.json()
    const { userId, userData } = requestData

    if (!userId || !userData) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    // Create a Supabase client with admin privileges
    const supabase = createRouteHandlerClient({ cookies })

    // First, check if the profiles table exists
    try {
      const { error: tableCheckError } = await supabase.from("profiles").select("id").limit(1)

      if (tableCheckError) {
        if (tableCheckError.message.includes('relation "profiles" does not exist')) {
          // Create the profiles table
          const { error: createTableError } = await supabase.rpc("create_profiles_table")

          if (createTableError) {
            console.error("Error creating profiles table:", createTableError)
            return NextResponse.json({ error: "Failed to create profiles table" }, { status: 500 })
          }
        } else {
          console.error("Error checking profiles table:", tableCheckError)
          return NextResponse.json({ error: "Error checking profiles table" }, { status: 500 })
        }
      }
    } catch (tableError) {
      console.error("Error checking/creating table:", tableError)
    }

    // Check if profile already exists
    const { data: existingProfile, error: fetchError } = await supabase
      .from("profiles")
      .select("*")
      .eq("id", userId)
      .single()

    if (fetchError && !fetchError.message.includes("No rows found")) {
      console.error("Error checking profile:", fetchError)
      return NextResponse.json({ error: "Error checking profile" }, { status: 500 })
    }

    // If profile exists, update it
    if (existingProfile) {
      const { error: updateError } = await supabase
        .from("profiles")
        .update({
          full_name: userData.full_name,
          email: userData.email,
          updated_at: new Date().toISOString(),
        })
        .eq("id", userId)

      if (updateError) {
        console.error("Error updating profile:", updateError)
        return NextResponse.json({ error: "Error updating profile" }, { status: 500 })
      }

      return NextResponse.json({ success: true, message: "Profile updated" })
    }

    // Try direct SQL insertion with service role (bypassing RLS)
    try {
      const { error: insertError } = await supabase.rpc("insert_profile", {
        user_id: userId,
        user_full_name: userData.full_name,
        user_email: userData.email,
        user_updated_at: new Date().toISOString(),
      })

      if (insertError) {
        console.error("Error with RPC insert_profile:", insertError)
        // Fall back to regular insert
      } else {
        return NextResponse.json({ success: true, message: "Profile created via RPC" })
      }
    } catch (rpcError) {
      console.error("RPC error:", rpcError)
      // Continue to fallback
    }

    // If RPC fails, try regular insert
    const { error: insertError } = await supabase.from("profiles").insert([
      {
        id: userId,
        full_name: userData.full_name,
        email: userData.email,
        updated_at: new Date().toISOString(),
      },
    ])

    if (insertError) {
      console.error("Error creating profile:", insertError)
      return NextResponse.json({ error: `Error creating profile: ${insertError.message}` }, { status: 500 })
    }

    return NextResponse.json({ success: true, message: "Profile created" })
  } catch (error: any) {
    console.error("Server error:", error)
    return NextResponse.json({ error: `Internal server error: ${error.message}` }, { status: 500 })
  }
}

