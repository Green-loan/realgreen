import { createRouteHandlerClient } from "@supabase/auth-helpers-nextjs"
import { cookies } from "next/headers"
import { NextResponse } from "next/server"

export async function GET() {
  try {
    const supabase = createRouteHandlerClient({ cookies })

    // Check tables
    const tables = ["users", "profiles", "user_settings", "roles"]
    const tableResults = {}

    for (const table of tables) {
      const { data, error } = await supabase.from(table).select("count(*)").single()

      tableResults[table] = {
        exists: !error,
        count: data?.count || 0,
        error: error ? error.message : null,
      }
    }

    // Check triggers
    const { data: triggers, error: triggerError } = await supabase.rpc("get_triggers", { schema_name: "public" })

    return NextResponse.json({
      tables: tableResults,
      triggers: triggers || [],
      triggerError: triggerError ? triggerError.message : null,
    })
  } catch (error) {
    console.error("Error checking database structure:", error)
    return NextResponse.json({ error: "Failed to check database structure" }, { status: 500 })
  }
}

