import { createRouteHandlerClient } from "@supabase/auth-helpers-nextjs"
import { cookies } from "next/headers"
import { NextResponse } from "next/server"

export async function GET() {
  try {
    const supabase = createRouteHandlerClient({ cookies })

    // Check if profiles table exists
    const { data: profilesExists, error: profilesError } = await supabase
      .from("profiles")
      .select("count(*)", { count: "exact", head: true })

    // Check if user_settings table exists
    const { data: settingsExists, error: settingsError } = await supabase
      .from("user_settings")
      .select("count(*)", { count: "exact", head: true })

    // Check if roles table exists
    const { data: rolesExists, error: rolesError } = await supabase
      .from("roles")
      .select("count(*)", { count: "exact", head: true })

    return NextResponse.json({
      tables: {
        profiles: {
          exists: !profilesError,
          error: profilesError ? profilesError.message : null,
        },
        user_settings: {
          exists: !settingsError,
          error: settingsError ? settingsError.message : null,
        },
        roles: {
          exists: !rolesError,
          error: rolesError ? rolesError.message : null,
        },
      },
    })
  } catch (error) {
    console.error("Error checking tables:", error)
    return NextResponse.json({ error: "Failed to check tables" }, { status: 500 })
  }
}

