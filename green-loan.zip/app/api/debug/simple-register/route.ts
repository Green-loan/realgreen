import { createRouteHandlerClient } from "@supabase/auth-helpers-nextjs"
import { cookies } from "next/headers"
import { NextResponse } from "next/server"

export async function POST(request: Request) {
  try {
    const { email, password, fullName } = await request.json()

    if (!email || !password || !fullName) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    // Create a Supabase client
    const supabase = createRouteHandlerClient({ cookies })

    // Register the user
    const { data, error: signUpError } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          full_name: fullName,
        },
      },
    })

    if (signUpError) {
      return NextResponse.json({ error: signUpError.message }, { status: 400 })
    }

    if (!data.user) {
      return NextResponse.json({ error: "User creation failed" }, { status: 500 })
    }

    // Try to manually create the profile
    try {
      const { error: profileError } = await supabase.from("profiles").insert([
        {
          id: data.user.id,
          full_name: fullName,
          email: email,
          updated_at: new Date().toISOString(),
        },
      ])

      if (profileError) {
        console.error("Profile creation error:", profileError)

        // Try the fix-profile API as a fallback
        const fixResponse = await fetch(new URL("/api/debug/fix-profile", request.url), {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            userId: data.user.id,
            userData: {
              full_name: fullName,
              email: email,
            },
          }),
        })

        const fixResult = await fixResponse.json()

        if (!fixResponse.ok) {
          return NextResponse.json({
            success: true,
            user: data.user,
            warning: "User created but profile creation failed. Please use the fix-profile API.",
          })
        }

        return NextResponse.json({
          success: true,
          user: data.user,
          profile: "Created via fallback API",
        })
      }
    } catch (profileErr) {
      console.error("Profile creation exception:", profileErr)
    }

    return NextResponse.json({
      success: true,
      user: data.user,
      profile: "Created successfully",
    })
  } catch (error: any) {
    console.error("Server error:", error)
    return NextResponse.json({ error: `Internal server error: ${error.message}` }, { status: 500 })
  }
}

