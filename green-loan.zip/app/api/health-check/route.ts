import { createClient } from "@/utils/supabase/server"
import { cookies } from "next/headers"
import { NextResponse } from "next/server"

export async function GET() {
  try {
    const cookieStore = cookies()
    const supabase = createClient(cookieStore)

    // Simple query to check database connection
    const { data, error, status } = await supabase.from("profiles").select("count", { count: "exact", head: true })

    if (error) {
      console.error("Database connection error:", error)
      return NextResponse.json(
        {
          status: "error",
          message: "Database connection failed",
          error: error.message,
          code: status,
        },
        { status: 500 },
      )
    }

    return NextResponse.json({
      status: "ok",
      message: "Database connection successful",
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    console.error("Health check error:", error)
    return NextResponse.json(
      {
        status: "error",
        message: "Health check failed",
        error: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}

