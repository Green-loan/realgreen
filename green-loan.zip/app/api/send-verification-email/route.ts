import { cookies } from "next/headers"
import { NextResponse } from "next/server"
import { createClient } from "@/lib/supabase-server"

export async function POST(request: Request) {
  try {
    const { userId, email } = await request.json()

    if (!userId || !email) {
      return NextResponse.json({ error: "User ID and email are required" }, { status: 400 })
    }

    const cookieStore = cookies()
    const supabase = createClient(cookieStore)

    // Generate a verification token
    const token = Math.random().toString(36).substring(2, 15)
    const expiresAt = new Date()
    expiresAt.setHours(expiresAt.getHours() + 24) // Token expires in 24 hours

    // Store the token in the database
    const { error: tokenError } = await supabase.from("verification_tokens").insert([
      {
        user_id: userId,
        token,
        expires_at: expiresAt.toISOString(),
        verified: false,
      },
    ])

    if (tokenError) {
      console.error("Error creating verification token:", tokenError)
      return NextResponse.json({ error: "Failed to create verification token" }, { status: 500 })
    }

    // Send the verification email
    // In a real application, you would use an email service like SendGrid, Mailgun, etc.
    console.log(`Sending verification email to ${email} with token ${token}`)

    // For demo purposes, we'll just return the token
    return NextResponse.json({ success: true, token })
  } catch (error: any) {
    console.error("Error sending verification email:", error)
    return NextResponse.json({ error: error.message || "An unexpected error occurred" }, { status: 500 })
  }
}

