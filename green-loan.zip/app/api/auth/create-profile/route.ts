import { createRouteHandlerClient } from "@supabase/auth-helpers-nextjs"
import { cookies } from "next/headers"
import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const requestData = await request.json()
    const { userId, fullName } = requestData

    if (!userId || !fullName) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    const supabase = createRouteHandlerClient({ cookies })

    // Check if profile already exists
    const { data: existingProfile } = await supabase.from("profiles").select("*").eq("id", userId).single()

    if (existingProfile) {
      return NextResponse.json({ message: "Profile already exists", profile: existingProfile }, { status: 200 })
    }

    // Create profile
    const { data: profile, error: profileError } = await supabase
      .from("profiles")
      .insert({
        id: userId,
        user_id: userId,
        full_name: fullName,
        role_id: 1,
        credit_score: 720,
        total_loans: 0,
        active_loans: 0,
        total_invested: "R 0",
        stokvel_contribution: "R 0",
      })
      .select()

    if (profileError) {
      console.error("Error creating profile:", profileError)
      return NextResponse.json({ error: "Failed to create profile", details: profileError }, { status: 500 })
    }

    // Create user settings
    const { data: settings, error: settingsError } = await supabase
      .from("user_settings")
      .insert({
        user_id: userId,
        notification_preferences: {
          email: true,
          push: true,
          sms: false,
        },
        theme: "system",
        language: "en",
      })
      .select()

    if (settingsError) {
      console.error("Error creating settings:", settingsError)
      // Continue anyway, profile is more important
    }

    return NextResponse.json(
      {
        message: "Profile created successfully",
        profile,
        settings,
      },
      { status: 201 },
    )
  } catch (error) {
    console.error("Server error creating profile:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

