import { type NextRequest, NextResponse } from "next/server"
import { adminDb } from "@/lib/firebase-admin"
import { createRouteHandlerClient } from "@supabase/auth-helpers-nextjs"
import { cookies } from "next/headers"

export async function POST(request: NextRequest) {
  try {
    // Get user data from request body
    const { userId, email } = await request.json()

    if (!userId || !email) {
      return NextResponse.json({ error: "User ID and email are required" }, { status: 400 })
    }

    // Get Supabase client
    const supabase = createRouteHandlerClient({ cookies })

    // Get user from Supabase
    const { data: userData, error: userError } = await supabase.from("profiles").select("*").eq("id", userId).single()

    if (userError) {
      console.error("Error fetching user from Supabase:", userError)
    }

    // Create or update user in Firebase
    const userRef = adminDb.collection("users").doc(userId)

    await userRef.set(
      {
        id: userId,
        email,
        firstName: userData?.first_name || "",
        lastName: userData?.last_name || "",
        phoneNumber: userData?.phone_number || "",
        createdAt: new Date(),
        updatedAt: new Date(),
        role: userData?.role || "user",
        isVerified: userData?.is_verified || false,
      },
      { merge: true },
    )

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error syncing user:", error)
    return NextResponse.json({ error: "Failed to sync user data" }, { status: 500 })
  }
}

