import { createRouteHandlerClient } from "@supabase/auth-helpers-nextjs"
import { cookies } from "next/headers"
import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const requestData = await request.json()
    const { userId, email, fullName, roleId = 1 } = requestData

    if (!userId || !email) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    const supabase = createRouteHandlerClient({ cookies })

    // Check if user already exists in users table
    const { data: existingUser, error: checkError } = await supabase
      .from("users")
      .select("id")
      .eq("id", userId)
      .single()

    if (!checkError && existingUser) {
      return NextResponse.json({ message: "User already exists", user: existingUser }, { status: 200 })
    }

    // Insert into users table
    const { data: user, error: userError } = await supabase
      .from("users")
      .insert({
        id: userId,
        email: email,
        full_name: fullName || "New User",
        role_id: roleId,
        is_verified: false,
        is_active: true,
      })
      .select()

    if (userError) {
      console.error("Error creating user:", userError)
      return NextResponse.json({ error: "Failed to create user", details: userError }, { status: 500 })
    }

    // Insert into profiles table
    const { data: profile, error: profileError } = await supabase
      .from("profiles")
      .insert({
        id: userId,
        user_id: userId,
        full_name: fullName || "New User",
        credit_score: 720,
        total_loans: 0,
        active_loans: 0,
        total_invested: "R 0",
        stokvel_contribution: "R 0",
      })
      .select()

    if (profileError) {
      console.error("Error creating profile:", profileError)
      // Continue anyway
    }

    // Insert into user_settings table
    const { data: settings, error: settingsError } = await supabase
      .from("user_settings")
      .insert({
        user_id: userId,
        notification_preferences: {
          email: true,
          push: true,
          sms: false,
        },
        theme: "system",
        language: "en",
      })
      .select()

    if (settingsError) {
      console.error("Error creating settings:", settingsError)
      // Continue anyway
    }

    return NextResponse.json(
      {
        message: "User created successfully",
        user,
        profile,
        settings,
      },
      { status: 201 },
    )
  } catch (error) {
    console.error("Server error creating user:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

