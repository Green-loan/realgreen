import { createRouteHandlerClient } from "@supabase/auth-helpers-nextjs"
import { cookies } from "next/headers"
import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const requestData = await request.json()
    const { userId, email, fullNames, cellphone, role = 1 } = requestData

    if (!userId || !email) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    const supabase = createRouteHandlerClient({ cookies })

    // Check if user already exists in users_account table
    const { data: existingUser, error: checkError } = await supabase
      .from("users_account")
      .select("id")
      .eq("id", userId)
      .single()

    if (!checkError && existingUser) {
      return NextResponse.json({ message: "User account already exists", user: existingUser }, { status: 200 })
    }

    // Insert into users_account table
    const { data: userAccount, error: userAccountError } = await supabase
      .from("users_account")
      .insert({
        id: userId,
        email: email,
        full_names: fullNames || "New User",
        cellphone: cellphone || null,
        role: role,
        confirmed: false,
        created_at: new Date().toISOString(),
      })
      .select()

    if (userAccountError) {
      console.error("Error creating user account:", userAccountError)

      // Try with minimal fields
      const { data: minimalAccount, error: minimalError } = await supabase
        .from("users_account")
        .insert({
          id: userId,
          email: email,
          full_names: fullNames || "New User",
          role: role,
        })
        .select()

      if (minimalError) {
        return NextResponse.json({ error: "Failed to create user account", details: minimalError }, { status: 500 })
      }

      return NextResponse.json(
        { message: "User account created with minimal fields", user: minimalAccount },
        { status: 201 },
      )
    }

    return NextResponse.json({ message: "User account created successfully", user: userAccount }, { status: 201 })
  } catch (error) {
    console.error("Server error creating user account:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

