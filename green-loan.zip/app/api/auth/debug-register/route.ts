import { createRouteHandlerClient } from "@supabase/auth-helpers-nextjs"
import { cookies } from "next/headers"
import { NextResponse } from "next/server"

export async function POST(request: Request) {
  try {
    // Clone the request to read it twice
    const clonedRequest = request.clone()

    // Read the raw request body
    const rawBody = await clonedRequest.text()
    console.log("Raw request body:", rawBody)

    // Parse the JSON
    let requestBody
    try {
      requestBody = JSON.parse(rawBody)
    } catch (e) {
      console.error("Error parsing JSON:", e)
      return NextResponse.json({ error: "Invalid JSON", rawBody }, { status: 400 })
    }

    const { email, password, fullName } = requestBody

    if (!email || !password) {
      return NextResponse.json({ error: "Email and password are required", requestBody }, { status: 400 })
    }

    const cookieStore = cookies()
    const supabase = createRouteHandlerClient({ cookies: () => cookieStore })

    // Check if user already exists
    const { data: existingUser, error: existingUserError } = await supabase
      .from("profiles")
      .select("id")
      .eq("email", email)
      .maybeSingle()

    // Return debug info
    return NextResponse.json({
      message: "Debug info",
      requestReceived: true,
      parsedBody: {
        email,
        password: password ? "********" : undefined,
        fullName,
      },
      existingUser: existingUser || null,
      existingUserError: existingUserError || null,
      cookies: {
        count: cookieStore.getAll().length,
      },
      supabaseInitialized: !!supabase,
    })
  } catch (error: any) {
    console.error("Debug API error:", error)
    return NextResponse.json(
      {
        error: "An unexpected error occurred",
        errorMessage: error.message,
        errorStack: error.stack,
      },
      { status: 500 },
    )
  }
}

