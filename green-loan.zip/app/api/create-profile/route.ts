import { createRouteHandlerClient } from "@supabase/auth-helpers-nextjs"
import { cookies } from "next/headers"
import { NextResponse } from "next/server"

export async function POST(request: Request) {
  try {
    const requestData = await request.json()
    const { userId, userData } = requestData

    if (!userId || !userData) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    // Create a Supabase client
    const supabase = createRouteHandlerClient({ cookies })

    // Check if profile already exists
    const { data: existingProfile, error: fetchError } = await supabase
      .from("profiles")
      .select("*")
      .eq("id", userId)
      .single()

    if (fetchError && !fetchError.message.includes("No rows found")) {
      console.error("Error checking profile:", fetchError)
      return NextResponse.json({ error: "Error checking profile" }, { status: 500 })
    }

    // If profile exists, update it
    if (existingProfile) {
      const { error: updateError } = await supabase
        .from("profiles")
        .update({
          full_name: userData.full_name,
          email: userData.email,
          phone: userData.phone,
          updated_at: new Date().toISOString(),
        })
        .eq("id", userId)

      if (updateError) {
        console.error("Error updating profile:", updateError)
        return NextResponse.json({ error: "Error updating profile" }, { status: 500 })
      }

      return NextResponse.json({ success: true, message: "Profile updated" })
    }

    // If profile doesn't exist, create it
    const { error: insertError } = await supabase.from("profiles").insert([
      {
        id: userId,
        full_name: userData.full_name,
        email: userData.email,
        phone: userData.phone || null,
        updated_at: new Date().toISOString(),
      },
    ])

    if (insertError) {
      console.error("Error creating profile:", insertError)
      return NextResponse.json({ error: "Error creating profile" }, { status: 500 })
    }

    return NextResponse.json({ success: true, message: "Profile created" })
  } catch (error) {
    console.error("Server error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

