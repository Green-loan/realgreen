-- Function to insert a profile with service role privileges
CREATE OR REPLACE FUNCTION public.insert_profile(
  user_id UUID,
  user_full_name TEXT,
  user_email TEXT,
  user_phone TEXT DEFAULT '',
  user_updated_at TIMESTAMPTZ DEFAULT now()
) RETURNS VOID AS $$
BEGIN
  -- First check if the profiles table exists
  IF NOT EXISTS (
    SELECT FROM information_schema.tables 
    WHERE table_schema = 'public' 
    AND table_name = 'profiles'
  ) THEN
    -- Create the profiles table if it doesn't exist
    CREATE TABLE public.profiles (
      id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
      full_name TEXT,
      email TEXT,
      phone TEXT DEFAULT '',
      avatar_url TEXT DEFAULT '',
      updated_at TIMESTAMPTZ DEFAULT now(),
      created_at TIMESTAMPTZ DEFAULT now()
    );
    
    -- Add RLS policies
    ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
    
    CREATE POLICY "Users can view their own profile"
      ON public.profiles
      FOR SELECT
      USING (auth.uid() = id);
      
    CREATE POLICY "Users can update their own profile"
      ON public.profiles
      FOR UPDATE
      USING (auth.uid() = id);
      
    -- Allow service role to manage all profiles
    CREATE POLICY "Service role can manage all profiles"
      ON public.profiles
      USING (true)
      WITH CHECK (true);
  END IF;
  
  -- Insert or update the profile
  INSERT INTO public.profiles (id, full_name, email, phone, updated_at)
  VALUES (user_id, user_full_name, user_email, user_phone, user_updated_at)
  ON CONFLICT (id) 
  DO UPDATE SET 
    full_name = user_full_name,
    email = user_email,
    phone = user_phone,
    updated_at = user_updated_at;
    
  EXCEPTION WHEN OTHERS THEN
    -- Log the error
    RAISE NOTICE 'Error in insert_profile: %', SQLERRM;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

