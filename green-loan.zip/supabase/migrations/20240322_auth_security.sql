-- Create roles table if it doesn't exist
CREATE TABLE IF NOT EXISTS roles (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  description TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Insert default roles if they don't exist
INSERT INTO roles (id, name, description)
VALUES 
  (1, 'user', 'Regular user with standard permissions'),
  (2, 'admin', 'Administrator with full access')
ON CONFLICT (id) DO NOTHING;

-- Create email verification tokens table
CREATE TABLE IF NOT EXISTS verification_tokens (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL,
  token VARCHAR(6) NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  expires_at TIMESTAMP WITH TIME ZONE DEFAULT (NOW() + INTERVAL '1 hour'),
  verified BOOLEAN DEFAULT FALSE
);

-- Create index on token for faster lookups
CREATE INDEX IF NOT EXISTS idx_verification_tokens_token ON verification_tokens(token);

-- Create index on user_id for faster lookups
CREATE INDEX IF NOT EXISTS idx_verification_tokens_user_id ON verification_tokens(user_id);

-- Modify profiles table to include role_id if it doesn't already have it
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT FROM information_schema.columns 
    WHERE table_name = 'profiles' AND column_name = 'role_id'
  ) THEN
    ALTER TABLE profiles ADD COLUMN role_id INTEGER DEFAULT 1 REFERENCES roles(id);
  END IF;
END $$;

-- Create function to generate random 6-digit token
CREATE OR REPLACE FUNCTION generate_verification_token() 
RETURNS VARCHAR(6) AS $$
DECLARE
  token VARCHAR(6);
BEGIN
  -- Generate a random 6-digit number
  token := lpad(floor(random() * 1000000)::text, 6, '0');
  RETURN token;
END;
$$ LANGUAGE plpgsql;

-- Create function to create verification token on user signup
CREATE OR REPLACE FUNCTION create_verification_token()
RETURNS TRIGGER AS $$
DECLARE
  new_token VARCHAR(6);
BEGIN
  -- Generate a new token
  new_token := generate_verification_token();
  
  -- Insert the token into verification_tokens table
  INSERT INTO verification_tokens (user_id, email, token)
  VALUES (NEW.id, NEW.email, new_token);
  
  -- Here you would typically trigger an email sending process
  -- This would be handled by your application code or a webhook
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to automatically create verification token when a user signs up
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION create_verification_token();

-- Create function to verify a token
CREATE OR REPLACE FUNCTION verify_email_token(user_email TEXT, verification_token VARCHAR(6))
RETURNS BOOLEAN AS $$
DECLARE
  token_valid BOOLEAN;
  user_id UUID;
BEGIN
  -- Check if token exists, is not expired, and matches the email
  SELECT EXISTS (
    SELECT 1 FROM verification_tokens 
    WHERE email = user_email 
    AND token = verification_token 
    AND expires_at > NOW()
    AND verified = FALSE
  ) INTO token_valid;
  
  -- If token is valid, mark it as verified
  IF token_valid THEN
    -- Get the user_id
    SELECT vt.user_id INTO user_id
    FROM verification_tokens vt
    WHERE vt.email = user_email 
    AND vt.token = verification_token;
    
    -- Update the token as verified
    UPDATE verification_tokens
    SET verified = TRUE
    WHERE email = user_email AND token = verification_token;
    
    -- Update the user's email_confirmed_at in auth.users
    UPDATE auth.users
    SET email_confirmed_at = NOW()
    WHERE id = user_id;
    
    -- Ensure the user has the correct role in profiles
    UPDATE profiles
    SET role_id = 1  -- Default to user role
    WHERE id = user_id AND role_id IS NULL;
    
    RETURN TRUE;
  ELSE
    RETURN FALSE;
  END IF;
END;
$$ LANGUAGE plpgsql;

-- Create function to set a user as admin
CREATE OR REPLACE FUNCTION set_user_as_admin(user_email TEXT)
RETURNS BOOLEAN AS $$
DECLARE
  user_exists BOOLEAN;
BEGIN
  -- Check if user exists
  SELECT EXISTS (
    SELECT 1 FROM auth.users WHERE email = user_email
  ) INTO user_exists;
  
  -- If user exists, update their role to admin
  IF user_exists THEN
    UPDATE profiles
    SET role_id = 2  -- Admin role
    WHERE email = user_email;
    
    RETURN TRUE;
  ELSE
    RETURN FALSE;
  END IF;
END;
$$ LANGUAGE plpgsql;

-- Create function to generate a new verification token for an existing user
CREATE OR REPLACE FUNCTION regenerate_verification_token(user_email TEXT)
RETURNS VARCHAR(6) AS $$
DECLARE
  new_token VARCHAR(6);
  user_id UUID;
BEGIN
  -- Get user_id from email
  SELECT id INTO user_id FROM auth.users WHERE email = user_email;
  
  -- If user exists
  IF user_id IS NOT NULL THEN
    -- Generate a new token
    new_token := generate_verification_token();
    
    -- Delete any existing unverified tokens for this user
    DELETE FROM verification_tokens
    WHERE user_id = user_id AND verified = FALSE;
    
    -- Insert the new token
    INSERT INTO verification_tokens (user_id, email, token)
    VALUES (user_id, user_email, new_token);
    
    -- Return the new token (in a real system, you'd email this instead)
    RETURN new_token;
  ELSE
    RETURN NULL;
  END IF;
END;
$$ LANGUAGE plpgsql;

-- Set up Row Level Security (RLS) for verification_tokens
ALTER TABLE verification_tokens ENABLE ROW LEVEL SECURITY;

-- Create policy for verification_tokens
CREATE POLICY "Users can only view their own verification tokens"
ON verification_tokens
FOR SELECT
USING (auth.uid() = user_id);

-- Create policy for admins to view all verification tokens
CREATE POLICY "Admins can view all verification tokens"
ON verification_tokens
FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM profiles
    WHERE id = auth.uid() AND role_id = 2
  )
);

-- Create policy for verification_tokens to be inserted by the system
CREATE POLICY "System can insert verification tokens"
ON verification_tokens
FOR INSERT
WITH CHECK (true);

-- Create policy for verification_tokens to be updated by the system
CREATE POLICY "System can update verification tokens"
ON verification_tokens
FOR UPDATE
USING (true);

-- Create policy for roles to be viewed by all authenticated users
ALTER TABLE roles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "All users can view roles"
ON roles
FOR SELECT
USING (true);

