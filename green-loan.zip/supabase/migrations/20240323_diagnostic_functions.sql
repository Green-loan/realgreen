-- Function to get all tables in the public schema
CREATE OR REPLACE FUNCTION get_tables()
RETURNS TABLE (table_name text) LANGUAGE sql SECURITY DEFINER AS $$
  SELECT table_name::text 
  FROM information_schema.tables 
  WHERE table_schema = 'public';
$$;

-- Function to get all RLS policies
CREATE OR REPLACE FUNCTION get_policies()
RETURNS TABLE (
  table_name text,
  policy_name text,
  action text,
  roles text,
  using_expression text,
  with_check_expression text
) LANGUAGE sql SECURITY DEFINER AS $$
  SELECT 
    tablename::text as table_name,
    policyname::text as policy_name,
    cmd::text as action,
    roles::text,
    using_expr::text as using_expression,
    with_check::text as with_check_expression
  FROM pg_policies
  WHERE schemaname = 'public';
$$;

-- Grant access to these functions for anon and authenticated roles
GRANT EXECUTE ON FUNCTION get_tables TO anon, authenticated;
GRANT EXECUTE ON FUNCTION get_policies TO anon, authenticated;

