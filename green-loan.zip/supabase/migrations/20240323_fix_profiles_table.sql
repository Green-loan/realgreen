-- Check if profiles table exists and create it if it doesn't
DO $$
BEGIN
  IF NOT EXISTS (SELECT FROM pg_tables WHERE schemaname = 'public' AND tablename = 'profiles') THEN
    CREATE TABLE profiles (
      id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
      full_name TEXT NOT NULL,
      email TEXT NOT NULL,
      phone TEXT NOT NULL,
      avatar_url TEXT,
      role TEXT NOT NULL DEFAULT 'user',
      created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
      updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
    );
  END IF;
END
$$;

-- Make sure RLS is enabled on profiles table
ALTER TABLE IF EXISTS profiles ENABLE ROW LEVEL SECURITY;

-- Drop existing policies to avoid conflicts
DROP POLICY IF EXISTS "Users can view their own profile" ON profiles;
DROP POLICY IF EXISTS "Users can update their own profile" ON profiles;
DROP POLICY IF EXISTS "Admins can view all profiles" ON profiles;
DROP POLICY IF EXISTS "Admins can update all profiles" ON profiles;
DROP POLICY IF EXISTS "Anyone can insert profiles" ON profiles;

-- Create more permissive policies for now (for testing)
CREATE POLICY "Anyone can insert profiles"
  ON profiles FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Users can view their own profile"
  ON profiles FOR SELECT
  USING (auth.uid() = id OR auth.uid() IS NULL);

CREATE POLICY "Users can update their own profile"
  ON profiles FOR UPDATE
  USING (auth.uid() = id OR auth.uid() IS NULL);

-- Create a function to test user creation
CREATE OR REPLACE FUNCTION test_user_creation(test_email TEXT, test_password TEXT)
RETURNS TEXT AS $$
DECLARE
  user_id UUID;
  error_message TEXT;
BEGIN
  BEGIN
    -- Attempt to create a user directly in auth.users
    INSERT INTO auth.users (email, encrypted_password, email_confirmed_at, created_at, updated_at)
    VALUES (
      test_email,
      crypt(test_password, gen_salt('bf')),
      NOW(),
      NOW(),
      NOW()
    )
    RETURNING id INTO user_id;
    
    -- Insert into profiles
    INSERT INTO profiles (id, full_name, email, phone, role)
    VALUES (user_id, 'Test User', test_email, '1234567890', 'user');
    
    RETURN 'User created successfully with ID: ' || user_id;
  EXCEPTION WHEN OTHERS THEN
    error_message := SQLERRM;
    RETURN 'Error creating user: ' || error_message;
  END;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create a function to diagnose registration issues
CREATE OR REPLACE FUNCTION diagnose_registration_issues()
RETURNS TEXT AS $$
DECLARE
  result TEXT;
BEGIN
  result := 'Registration Diagnostics:
';
  
  -- Check if auth.users table exists and is accessible
  BEGIN
    PERFORM count(*) FROM auth.users LIMIT 1;
    result := result || '✓ auth.users table is accessible
';
  EXCEPTION WHEN OTHERS THEN
    result := result || '✗ Error accessing auth.users table: ' || SQLERRM || '
';
  END;
  
  -- Check if profiles table exists and is accessible
  BEGIN
    PERFORM count(*) FROM profiles LIMIT 1;
    result := result || '✓ profiles table is accessible
';
  EXCEPTION WHEN OTHERS THEN
    result := result || '✗ Error accessing profiles table: ' || SQLERRM || '
';
  END;
  
  -- Check RLS policies
  IF EXISTS (
    SELECT 1 FROM pg_policies
    WHERE schemaname = 'public' AND tablename = 'profiles'
  ) THEN
    result := result || '✓ RLS policies exist for profiles table
';
  ELSE
    result := result || '✗ No RLS policies found for profiles table
';
  END IF;
  
  RETURN result;
END;
$$ LANGUAGE plpgsql;

-- Grant execute permissions
GRANT EXECUTE ON FUNCTION test_user_creation TO anon, authenticated;
GRANT EXECUTE ON FUNCTION diagnose_registration_issues TO anon, authenticated;

