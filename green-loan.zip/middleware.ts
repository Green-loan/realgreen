import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"
import { createMiddlewareClient } from "@supabase/auth-helpers-nextjs"

export async function middleware(request: NextRequest) {
  const res = NextResponse.next()
  const supabase = createMiddlewareClient({ req: request, res })

  // Get the current path
  const path = request.nextUrl.pathname

  // Check if user is logged in
  const {
    data: { session },
  } = await supabase.auth.getSession()

  // If user is logged in and trying to access login page, redirect to dashboard
  if (session && (path === "/login" || path === "/signin" || path === "/register" || path === "/signup")) {
    return NextResponse.redirect(new URL("/dashboard", request.url))
  }

  // For all other cases, just continue
  return res
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)"],
}

