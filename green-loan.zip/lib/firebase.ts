// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app"
import { getFirestore } from "firebase/firestore"
import { getDatabase } from "firebase/database"
import { getAuth } from "firebase/auth"
import { getStorage } from "firebase/storage"
import { getAnalytics } from "firebase/analytics"
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyD0bugpay378Gl3PIeTyfRFhrSnKHs6_f4",
  authDomain: "greenfinance-134d9.firebaseapp.com",
  databaseURL: "https://greenfinance-134d9-default-rtdb.firebaseio.com",
  projectId: "greenfinance-134d9",
  storageBucket: "greenfinance-134d9.firebasestorage.app",
  messagingSenderId: "825392200889",
  appId: "1:825392200889:web:b01ef575d380bfb7202f68",
  measurementId: "G-4NLBM55P79",
}

// Initialize Firebase with SSR safety
const app = typeof window !== "undefined" ? initializeApp(firebaseConfig) : null

// Initialize Firebase services with SSR safety
export const db = typeof window !== "undefined" && app ? getFirestore(app) : null
export const rtdb = typeof window !== "undefined" && app ? getDatabase(app) : null
export const auth = typeof window !== "undefined" && app ? getAuth(app) : null
export const storage = typeof window !== "undefined" && app ? getStorage(app) : null
export const analytics = typeof window !== "undefined" && app ? getAnalytics(app) : null

export default app

