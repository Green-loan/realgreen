import { createServerClient } from "@supabase/ssr"
import { cookies } from "next/headers"
import type { Database } from "./database.types"

export const createClient = () => {
  const cookieStore = cookies()

  return createServerClient<Database>(
    "https://xoyowuxrolooejyaukrx.supabase.co",
    "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InhveW93dXhyb2xvb2VqeWF1a3J4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDI2NDcyMjEsImV4cCI6MjA1ODIyMzIyMX0.LBXBGwd-qOKo_539xrZMpzRaUkKGdGTx4IXN2OvXnYw",
    {
      cookies: {
        get(name) {
          return cookieStore.get(name)?.value
        },
        set(name, value, options) {
          cookieStore.set({ name, value, ...options })
        },
        remove(name, options) {
          cookieStore.set({ name, value: "", ...options })
        },
      },
    },
  )
}

