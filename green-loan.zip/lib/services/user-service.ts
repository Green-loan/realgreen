import { db } from "../firebase"
import { doc, setDoc, getDoc, updateDoc, serverTimestamp, collection, query, where, getDocs } from "firebase/firestore"

export interface UserProfile {
  id: string
  email: string
  firstName?: string
  lastName?: string
  phoneNumber?: string
  createdAt?: any
  updatedAt?: any
  role?: string
  isVerified?: boolean
}

export class UserService {
  // Create or update a user profile
  static async saveUser(user: UserProfile): Promise<void> {
    const userRef = doc(db, "users", user.id)
    const userDoc = await getDoc(userRef)

    if (!userDoc.exists()) {
      // Create new user
      await setDoc(userRef, {
        ...user,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
        role: user.role || "user",
        isVerified: user.isVerified || false,
      })
    } else {
      // Update existing user
      await updateDoc(userRef, {
        ...user,
        updatedAt: serverTimestamp(),
      })
    }
  }

  // Get a user profile by ID
  static async getUserById(userId: string): Promise<UserProfile | null> {
    const userRef = doc(db, "users", userId)
    const userDoc = await getDoc(userRef)

    if (userDoc.exists()) {
      return { id: userDoc.id, ...userDoc.data() } as UserProfile
    }

    return null
  }

  // Get a user profile by email
  static async getUserByEmail(email: string): Promise<UserProfile | null> {
    const usersRef = collection(db, "users")
    const q = query(usersRef, where("email", "==", email))
    const querySnapshot = await getDocs(q)

    if (!querySnapshot.empty) {
      const userDoc = querySnapshot.docs[0]
      return { id: userDoc.id, ...userDoc.data() } as UserProfile
    }

    return null
  }

  // Update user verification status
  static async updateVerificationStatus(userId: string, isVerified: boolean): Promise<void> {
    const userRef = doc(db, "users", userId)
    await updateDoc(userRef, {
      isVerified,
      updatedAt: serverTimestamp(),
    })
  }
}

