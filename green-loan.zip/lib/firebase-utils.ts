import { db, rtdb } from "./firebase"
import { collection, getDocs, limit, query } from "firebase/firestore"
import { ref, get } from "firebase/database"

export async function testFirestoreConnection() {
  if (!db) return { success: false, error: "Firestore not initialized" }

  try {
    // Try to fetch a single document from any collection
    const testQuery = query(collection(db, "test_collection"), limit(1))
    await getDocs(testQuery)
    return { success: true }
  } catch (error) {
    console.error("Firestore connection test failed:", error)
    return {
      success: false,
      error: error instanceof Error ? error.message : "Unknown error",
    }
  }
}

export async function testRealtimeDBConnection() {
  if (!rtdb) return { success: false, error: "Realtime Database not initialized" }

  try {
    // Try to read from a test location
    const testRef = ref(rtdb, "connection_test")
    await get(testRef)
    return { success: true }
  } catch (error) {
    console.error("Realtime Database connection test failed:", error)
    return {
      success: false,
      error: error instanceof Error ? error.message : "Unknown error",
    }
  }
}

