import { createClient } from "@/lib/supabase-browser"

/**
 * Sends a verification email with the 6-digit token
 * @param email The user's email address
 * @param token The 6-digit verification token
 */
export async function sendVerificationEmail(email: string, token: string): Promise<boolean> {
  try {
    // In a real application, you would use an email service like SendGrid, Mailgun, etc.
    // For this example, we'll just log the token
    console.log(`Sending verification email to ${email} with token: ${token}`)

    // Here's how you might implement this with a real email service:
    // const response = await fetch('/api/send-verification-email', {
    //   method: 'POST',
    //   headers: { 'Content-Type': 'application/json' },
    //   body: JSON.stringify({ email, token }),
    // });
    // return response.ok;

    return true
  } catch (error) {
    console.error("Error sending verification email:", error)
    return false
  }
}

// Update the registerUser function to use Supabase directly
export async function registerUser(
  email: string,
  password: string,
  fullName: string,
  phone: string,
): Promise<{ success: boolean; message: string; token?: string }> {
  const supabase = createClient()

  try {
    // Register the user with Supabase Auth
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          full_name: fullName,
          phone,
        },
        emailRedirectTo: `${window.location.origin}/auth/callback`,
      },
    })

    if (error) {
      throw error
    }

    // Create a profile in the profiles table
    if (data.user) {
      const { error: profileError } = await supabase.from("profiles").insert([
        {
          id: data.user.id,
          full_name: fullName,
          email,
          phone,
          role: "user",
        },
      ])

      if (profileError) {
        throw profileError
      }
    }

    return {
      success: true,
      message: "Registration successful! Please check your email to verify your account.",
    }
  } catch (error: any) {
    return {
      success: false,
      message: error.message || "An error occurred during registration.",
    }
  }
}

/**
 * Verifies a user's email with the provided token
 * @param email User's email
 * @param token Verification token
 */
export async function verifyEmail(email: string, token: string): Promise<{ success: boolean; message: string }> {
  const supabase = createClient()

  try {
    // Call the verify_email_token function
    const { data, error } = await supabase.rpc("verify_email_token", {
      user_email: email,
      verification_token: token,
    })

    if (error) {
      throw error
    }

    if (data) {
      return {
        success: true,
        message: "Email verified successfully! You can now log in.",
      }
    } else {
      return {
        success: false,
        message: "Invalid or expired verification token.",
      }
    }
  } catch (error: any) {
    return {
      success: false,
      message: error.message || "An error occurred during verification.",
    }
  }
}

/**
 * Resends a verification token to the user's email
 * @param email User's email
 */
export async function resendVerificationToken(email: string): Promise<{ success: boolean; message: string }> {
  const supabase = createClient()

  try {
    // Call the regenerate_verification_token function
    const { data, error } = await supabase.rpc("regenerate_verification_token", {
      user_email: email,
    })

    if (error) {
      throw error
    }

    if (data) {
      // Send the new verification email
      await sendVerificationEmail(email, data)

      return {
        success: true,
        message: "A new verification code has been sent to your email.",
      }
    } else {
      return {
        success: false,
        message: "User not found.",
      }
    }
  } catch (error: any) {
    return {
      success: false,
      message: error.message || "An error occurred while resending the verification code.",
    }
  }
}

/**
 * Checks if a user has admin privileges
 * @param userId User's ID
 */
export async function isUserAdmin(userId: string): Promise<boolean> {
  const supabase = createClient()

  try {
    const { data, error } = await supabase.from("profiles").select("role_id").eq("id", userId).single()

    if (error) {
      throw error
    }

    return data?.role_id === 2 // 2 is the admin role
  } catch (error) {
    console.error("Error checking admin status:", error)
    return false
  }
}

