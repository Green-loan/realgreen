// Make sure the Supabase client is properly initialized
import { createClient } from "@supabase/supabase-js"
import type { Database } from "./supabase-types"

const supabaseUrl = "https://xoyowuxrolooejyaukrx.supabase.co"
const supabaseAnonKey =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InhveW93dXhyb2xvb2VqeWF1a3J4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDI2NDcyMjEsImV4cCI6MjA1ODIyMzIyMX0.LBXBGwd-qOKo_539xrZMpzRaUkKGdGTx4IXN2OvXnYw"

// Create a single supabase client for interacting with your database
export const supabase = createClient<Database>(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
  },
})

