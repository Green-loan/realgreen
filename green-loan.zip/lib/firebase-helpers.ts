import { db, rtdb } from "@/lib/firebase"
import { collection, doc, getDoc, setDoc, updateDoc, deleteDoc, query, where, getDocs } from "firebase/firestore"
import { ref, get, set, update, remove } from "firebase/database"

// Firestore helpers
export const getDocument = async (collectionName: string, docId: string) => {
  if (!db) throw new Error("Firestore is not initialized")

  const docRef = doc(db, collectionName, docId)
  const docSnap = await getDoc(docRef)

  if (docSnap.exists()) {
    return { id: docSnap.id, ...docSnap.data() }
  } else {
    return null
  }
}

export const createDocument = async (collectionName: string, docId: string | null, data: any) => {
  if (!db) throw new Error("Firestore is not initialized")

  if (docId) {
    const docRef = doc(db, collectionName, docId)
    await setDoc(docRef, { ...data, createdAt: new Date() })
    return docId
  } else {
    const collectionRef = collection(db, collectionName)
    const docRef = doc(collectionRef)
    await setDoc(docRef, { ...data, createdAt: new Date() })
    return docRef.id
  }
}

export const updateDocument = async (collectionName: string, docId: string, data: any) => {
  if (!db) throw new Error("Firestore is not initialized")

  const docRef = doc(db, collectionName, docId)
  await updateDoc(docRef, { ...data, updatedAt: new Date() })
  return docId
}

export const deleteDocument = async (collectionName: string, docId: string) => {
  if (!db) throw new Error("Firestore is not initialized")

  const docRef = doc(db, collectionName, docId)
  await deleteDoc(docRef)
  return docId
}

export const queryDocuments = async (collectionName: string, field: string, operator: any, value: any) => {
  if (!db) throw new Error("Firestore is not initialized")

  const q = query(collection(db, collectionName), where(field, operator, value))
  const querySnapshot = await getDocs(q)

  const results: any[] = []
  querySnapshot.forEach((doc) => {
    results.push({ id: doc.id, ...doc.data() })
  })

  return results
}

// Realtime Database helpers
export const getRtdbData = async (path: string) => {
  if (!rtdb) throw new Error("Realtime Database is not initialized")

  const dataRef = ref(rtdb, path)
  const snapshot = await get(dataRef)

  if (snapshot.exists()) {
    return snapshot.val()
  } else {
    return null
  }
}

export const setRtdbData = async (path: string, data: any) => {
  if (!rtdb) throw new Error("Realtime Database is not initialized")

  const dataRef = ref(rtdb, path)
  await set(dataRef, { ...data, timestamp: Date.now() })
  return path
}

export const updateRtdbData = async (path: string, data: any) => {
  if (!rtdb) throw new Error("Realtime Database is not initialized")

  const dataRef = ref(rtdb, path)
  await update(dataRef, { ...data, updatedAt: Date.now() })
  return path
}

export const deleteRtdbData = async (path: string) => {
  if (!rtdb) throw new Error("Realtime Database is not initialized")

  const dataRef = ref(rtdb, path)
  await remove(dataRef)
  return path
}

