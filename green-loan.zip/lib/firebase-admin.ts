import { initializeApp, getApps, cert } from "firebase-admin/app"
import { getFirestore } from "firebase-admin/firestore"
import { getAuth } from "firebase-admin/auth"

// Initialize Firebase Admin
const serviceAccount = {
  type: "service_account",
  project_id: "greenfinance-134d9",
  private_key_id: process.env.FIREBASE_PRIVATE_KEY_ID || "fc702c7066afffb9df1aa1619ca74b480633f9e4",
  private_key: process.env.FIREBASE_PRIVATE_KEY
    ? process.env.FIREBASE_PRIVATE_KEY.replace(/\\n/g, "\n")
    : "-----BEGIN PRIVATE KEY-----\nMIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQDQq/QqGYdJ6BTC\noEeO1GYsbIq193o1THZ4I5aA0qwDU4RQgvZxAV9AsrkzVYMX5geS5XBODPFZi50B\n3iVGAlYywlbls8v4anq8X4Nj7YlwCZYpir7gXNGMBpQXYlqzDj5I5ynAQGz6ijiW\nu9zyteY73f6cRPDAwJN6TcniHnsjsQwEULEIBlhOJXCwoa58QqU0gjLD6SVU0aoK\nhtbWflVaa0imdz5HOOBMepvz5LXyvey5z0+fapEJFea1+oltdx6kSY3XUio7i8BB\nC/GLMBvU+pMt8cmDN5wWD6C+jIK2jYjYfDk9b2tGWiWw31llQD5QlsNt/vfsRyR6\nTK38godTAgMBAAECggEAMd/ni+huHYwK6jnE4K6DfTq0LKnp27Na3XwkDMZNtr3P\nci7bGEdrrNsKyOo3Ww7v4HxWS1FsnipwbHHcFs+YKqmoe15t8gIBM+TgUpIDt3OT\nIHq5BIcqzn0ECFLJuuI8oNAfeoPriDZhMCXWuWwgi06T/GW95VQh66mMBy+h3vWT\nM+fKPwV1EuWt30lEMlU0hrgFZR9zldXqVpStVhn75n+XxezZ8m4+kQr5l4qSkYCy\n2kYv5nzT7USbK5mMYxn/UwzLWqZ3E4D91cKisLqDLF+57AqtOyL0tmvNRCm/y3hI\nn8OehasQwa4LTZLLWjnwlYNr5ATMtDSLfuqPV/t6gQKBgQD7+kpkYJzEjyevZgz4\nw/SYCKiSDDzJLDOmD1AubWUSrF0uYOv/MFnY3hR5Pkt+BaW1XaaxLtatp72cTHyy\nb5NchzSGHWV1C/Y05R7jsulhbhGtwAyNQx6x58Pe6yEptdk0wiHmyOByspFQK4vW\notDVKnAjYmuKhvo1SoyAFpOmNQKBgQDUALFYT0twTuWvbcP7nCvyCvVozhUTYK6/\nhyCg6aH82pUPddggga/xvTahwMZKjmGfxvX8G6V/2TrdoNnBFMvsQw/TkV0e7UuF\nPAQwToQdZQgsGeGvNihYYH5tGm4ozZTh8hEh7XjmlmtE/NvdBdA/UcEkwt65mp/U\n+xeLu2UIZwKBgCCN1pyfSsGuSQ9FHPnqvygBPl4YDKZk+otCwTYuVfeSoztBtFu0\n0HbPQk/jt3chnaYP4mBTz9KBsGKIEzguaBh1M1j8ZUY49GcjDtmWHMbEpK4Q+M4r\nVMThT5H2SMONxfEl/6FEZJMM9O8poRhq0pYntHMt3Pz5sUu/ROWrhQndAoGBAI7K\nLKirN8dcDI2c48ybQmoTAXnmnAFiNDDiJZLb6XPyEUXJfJlgYA31AE/wFF5xCcXg\n7xsvz8eNm31c8m1+wV7PSGCaXtsOvrftVXDn4UofG2MAx6YIVyI3U8/OZnXrCaUp\nMmrklHLSy0s6+Cck3D9ZpDpLWlIumAqOWCyQOhtvAoGBALgIG0xXP3N3V6gX62Gb\nFT2QnpN3hqtwE5OgmaVIiAAA9NHth63aMnEPdyYfeVu73HH+9KCoJ752m2TUVCiV\nnih3DGAUBoS03heMKZ4p5SKLhpobVl3ovGqMt5Iw/2C6gLXFlUa9+j454oZYPCHh\n7pOzrE5fuWWE8qt3N4lm3Gc6\n-----END PRIVATE KEY-----\n",
  client_email:
    process.env.FIREBASE_CLIENT_EMAIL || "firebase-adminsdk-fbsvc@greenfinance-134d9.iam.gserviceaccount.com",
  client_id: process.env.FIREBASE_CLIENT_ID || "116587051643629416727",
  auth_uri: "https://accounts.google.com/o/oauth2/auth",
  token_uri: "https://oauth2.googleapis.com/token",
  auth_provider_x509_cert_url: "https://www.googleapis.com/oauth2/v1/certs",
  client_x509_cert_url:
    process.env.FIREBASE_CLIENT_CERT_URL ||
    "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-fbsvc%40greenfinance-134d9.iam.gserviceaccount.com",
  universe_domain: "googleapis.com",
}

// Initialize the app only if it hasn't been initialized already
const apps = getApps()
const firebaseAdmin =
  apps.length === 0
    ? initializeApp({
        credential: cert(serviceAccount as any),
        databaseURL: "https://greenfinance-134d9-default-rtdb.firebaseio.com",
      })
    : apps[0]

// Export Firestore and Auth instances
export const adminDb = getFirestore()
export const adminAuth = getAuth()

export default firebaseAdmin

