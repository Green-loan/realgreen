export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[]

export interface Database {
  public: {
    Tables: {
      loan_applications: {
        Row: {
          id: string
          user_id: string
          full_name: string
          email: string
          phone: string
          loan_amount: number
          loan_purpose: string
          loan_type: string
          due_date: string
          employment_status: string
          monthly_income: number
          project_description: string
          ai_verification_result: string
          ai_verification_score: number
          ai_verification_notes: string
          status: string
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          full_name: string
          email: string
          phone: string
          loan_amount: number
          loan_purpose: string
          loan_type: string
          due_date: string
          employment_status: string
          monthly_income: number
          project_description: string
          ai_verification_result: string
          ai_verification_score: number
          ai_verification_notes: string
          status: string
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          full_name?: string
          email?: string
          phone?: string
          loan_amount?: number
          loan_purpose?: string
          loan_type?: string
          due_date?: string
          employment_status?: string
          monthly_income?: number
          project_description?: string
          ai_verification_result?: string
          ai_verification_score?: number
          ai_verification_notes?: string
          status?: string
          created_at?: string
          updated_at?: string
        }
      }
      notifications: {
        Row: {
          id: string
          user_id: string
          title: string
          message: string
          type: string
          read: boolean
          created_at: string
        }
        Insert: {
          id?: string
          user_id: string
          title: string
          message: string
          type: string
          read?: boolean
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          title?: string
          message?: string
          type?: string
          read?: boolean
          created_at?: string
        }
      }
      payments: {
        Row: {
          id: string
          user_id: string
          loan_id: string
          amount: number
          payment_date: string
          status: string
          created_at: string
        }
        Insert: {
          id?: string
          user_id: string
          loan_id: string
          amount: number
          payment_date: string
          status: string
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          loan_id?: string
          amount?: number
          payment_date?: string
          status?: string
          created_at?: string
        }
      }
      profiles: {
        Row: {
          id: string
          full_name: string
          email: string
          phone: string
          avatar_url: string | null
          role: string
          created_at: string
          updated_at: string
        }
        Insert: {
          id: string
          full_name: string
          email: string
          phone: string
          avatar_url?: string | null
          role?: string
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          full_name?: string
          email?: string
          phone?: string
          avatar_url?: string | null
          role?: string
          created_at?: string
          updated_at?: string
        }
      }
      temp_users: {
        Row: {
          id: string
          full_name: string
          email: string
          phone: string
          created_at: string
        }
        Insert: {
          id?: string
          full_name: string
          email: string
          phone: string
          created_at?: string
        }
        Update: {
          id?: string
          full_name?: string
          email?: string
          phone?: string
          created_at?: string
        }
      }
    }
  }
}

